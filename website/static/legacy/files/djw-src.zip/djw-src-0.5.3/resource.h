/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 19-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#ifndef ResourceH
#define ResourceH
//---------------------------------------------------------------------------
//MainWindow
//MainMenu
#define ID_MN_NEWPLAYER		101
#define ID_MN_CHECK		    102
#define ID_MN_ID3EDITOR	    104
#define ID_MN_PRINT   		105
#define ID_MN_PRINTERSETUP 	106
#define ID_MN_EXIT         	107
#define ID_MN_WCSEARCH  	108
//Playlist
#define ID_MN_PLNEW       	111
#define ID_MN_PLLOAD       	112
//Options
#define ID_MN_DEVICES  	    121
#define ID_MN_LANGUAGE	    122
#define ID_MN_COM_SELECT    123
//View
#define ID_MN_MIXERSECTION 	131
#define ID_MN_SAVEPOSITIONS	132
//Help
#define ID_MN_CONTENT 	   	141
#define ID_MN_INDEX  	   	142
#define ID_MN_INFO     	   	143

//Edit-Controls
#define ID_ED_ARTIST 	   	191
#define ID_ED_SONG  	   	192
#define ID_ED_GENRE   	   	193
#define ID_ED_YEAR   	   	194
#define ID_FSEARCH_ARTIST  	195
#define ID_FSEARCH_SONG    	196
#define ID_FSEARCH_GENRE   	197
#define ID_FSEARCH_YEAR    	198
#define ID_BT_STARTSEARCH  	199

//Device-Dialog
#define IDRB_ONLYONE        201
#define IDRB_AUX_HEAD       202
#define IDRB_PER_PLAYER     203
#define IDSS_DEVICECOUNT    204

//Player Window
#define ID_BTLOAD           301
#define ID_BTPLAY           302
#define ID_BTCUE            303
#define ID_BTZERO           304
#define ID_BTPLUS           305
#define ID_BTMINUS          306
#define ID_BTHEAD           307
#define ID_BTTIME           308
#define ID_CBAUTOCUE        309
#define ID_SBARPITCH        310
#define ID_SBARSEEK         311
#define ID_SBARVOLUME       312
#define ID_STEXTTIME        313
#define ID_STEXTSTATUS      314
#define ID_STEXTPITCH       315
#define ID_STEXTPITCHPER    316
#define ID_STEXTHEAD        317
#define ID_STEXTVOLUME      318

//Player PopUpMenu
//#define ID_MN_ALLWAYSONTOP	319
#define ID_MN_PROPORTIONAL	320
#define ID_MN_ORGINAL		321
#define ID_MN_PLAY	    	322
#define ID_MN_CUE    		323
#define ID_MN_LOAD  		324
#define ID_MN_MASTERTEMPO	325

//Language Dialog
#define IDCB_LANGUAGE       401

//Playlist Window
#define ID_BTSTART          501
#define ID_BTSAVE           502
//Playerlist PopUpMenu
#define ID_MN_DELETE		510

//Print Dialog
#define ID_BTPRINT          601
#define ID_BTPREVIEW        602
#define IDRB_ARTIST         603
#define IDRB_SONG           604
#define IDRB_GENRE          605
#define IDRB_YEAR           606
#define ID_PRINT_STATUSBAR  620

//Scan Dialog
#define ID_LBDIR            701
#define ID_BTSCAN           702
#define ID_BTCHECK          703
#define ID_BTSCANCHECK      704
#define ID_CBVBR            705
#define ID_SSDIR            706
#define ID_SSFILE           707
#define ID_CBMP3            708
#define ID_CBOGG            709
#define ID_CBWAV            710

//Mixer Dialog
#define ID_CB_PLAYERLEFT    801
#define ID_MIXBTZERO        802
#define ID_CB_PLAYERRIGHT   803
#define ID_BTLEFT           804
#define ID_TB_CROSSFADER    805
#define ID_BTRIGHT          806
#define ID_BTFADE           807
#define ID_ED_PLAYSTART     808
#define ID_UD_PLAYSTART     809
#define ID_CBOX_AUTOPLAY    810
#define ID_ED_FADETIME      811
#define ID_UD_FADETIME      812
#define ID_CBOX_AUTOFADE    813

//Messageboxes Warning
#define IDS_MAIN_CAPTION    900
#define IDS_RESTART         901
#define IDS_WARNING         902
#define IDS_FILE_NOT_EXIST 	903
#define IDS_ARTIST      	910
#define IDS_SONGNAME    	911
#define IDS_GENRE       	912
#define IDS_YEAR        	913
#define IDS_LOAD        	914
#define IDS_CHOOSE_DEVICE   915
#define IDS_DEVICE_AUX      916
#define IDS_DEVICE_HEAD     917
#define IDS_OK              918
#define IDS_CANCEL          919
#define IDS_HELP            920
#define IDS_HELPPATH        921
#define IDS_SAVE            922
#define IDS_FASTSEARCH      923
#define IDS_WCSEARCH        924
#define IDS_RESULT          925
#define IDS_DURATION        926

//#define MyListbox 1000
//Accelerator
#define ID_ACCEL_ENTER     1001
#define ID_ACCEL_LEFTLOAD  1002
#define ID_ACCEL_LEFTPLAY  1003
#define ID_ACCEL_LEFTCUE   1004
#define ID_ACCEL_RIGHTLOAD 1005
#define ID_ACCEL_RIGHTPLAY 1006
#define ID_ACCEL_RIGHTCUE  1007

//Device-Dialog
#define ID_EDIT_LV         1101

//Comport-Dialog
#define ID_SELECT_COM      1201
#define ID_CB_SELECT_COM   1202


//---------------------------------------------------------------------------
#endif


# Microsoft Developer Studio Project File - Name="DJW" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** NICHT BEARBEITEN **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=DJW - WIN32 RELEASE
!MESSAGE Dies ist kein g�ltiges Makefile. Zum Erstellen dieses Projekts mit NMAKE
!MESSAGE verwenden Sie den Befehl "Makefile exportieren" und f�hren Sie den Befehl
!MESSAGE 
!MESSAGE NMAKE /f "DJW.mak".
!MESSAGE 
!MESSAGE Sie k�nnen beim Ausf�hren von NMAKE eine Konfiguration angeben
!MESSAGE durch Definieren des Makros CFG in der Befehlszeile. Zum Beispiel:
!MESSAGE 
!MESSAGE NMAKE /f "DJW.mak" CFG="DJW - WIN32 RELEASE"
!MESSAGE 
!MESSAGE F�r die Konfiguration stehen zur Auswahl:
!MESSAGE 
!MESSAGE "DJW - Win32 Release" (basierend auf  "Win32 (x86) Application")
!MESSAGE "DJW - Win32 Debug" (basierend auf  "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "DJW - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /G5 /MT /W4 /GX /O1 /I "..\STL\stlport" /I "..\xaudio\include" /I "..\oggvorbis\include" /I "..\Soundtouch\include" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /FD /c
# SUBTRACT CPP /YX /Yc /Yu
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /I "D:\DJ-Workstation\XAUDIO\xasdk307\include" /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "NDEBUG"
# ADD RSC /l 0x407 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /machine:I386
# ADD LINK32 xaudiomt.lib kernel32.lib user32.lib gdi32.lib ole32.lib winspool.lib comctl32.lib comdlg32.lib shell32.lib winmm.lib version.lib dsound.lib vorbis_static.lib vorbisfile_static.lib ogg_static.lib LibSoundTouch.lib /nologo /subsystem:windows /machine:I386 /libpath:"..\STL\lib" /libpath:"..\xaudio\Lib" /libpath:"..\oggvorbis\lib" /libpath:"..\soundtouch\lib"
# SUBTRACT LINK32 /pdb:none

!ELSEIF  "$(CFG)" == "DJW - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /G5 /MTd /W4 /Gm /Gi /GX /ZI /Od /I "..\STL\stlport" /I "..\xaudio\include" /I "..\oggvorbis\include" /I "..\Soundtouch\include" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /U "LIBCMTD.LIB" /FD /GZ /c
# SUBTRACT CPP /YX /Yc /Yu
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /I "D:\DJ-Workstation\XAUDIO\xasdk307\include" /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "_DEBUG"
# ADD RSC /l 0x407 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 xaudiomtd.lib kernel32.lib user32.lib gdi32.lib ole32.lib winspool.lib comctl32.lib comdlg32.lib shell32.lib winmm.lib version.lib dsound.lib vorbis_static.lib vorbisfile_static.lib ogg_static.lib LibSoundTouch.lib /nologo /subsystem:windows /debug /machine:I386 /nodefaultlib:"LIBCMT" /libpath:"..\STL\lib" /libpath:"..\xaudio\Lib" /libpath:"..\oggvorbis\lib" /libpath:"..\soundtouch\lib"
# SUBTRACT LINK32 /profile /nodefaultlib

!ENDIF 

# Begin Target

# Name "DJW - Win32 Release"
# Name "DJW - Win32 Debug"
# Begin Group "Quellcodedateien"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\comdlg.cpp
# End Source File
# Begin Source File

SOURCE=.\database.cpp
# End Source File
# Begin Source File

SOURCE=.\devicedlg.cpp
# End Source File
# Begin Source File

SOURCE=.\djw.cpp
# End Source File
# Begin Source File

SOURCE=.\DSUtil.cpp
# End Source File
# Begin Source File

SOURCE=.\Formate.cpp
# End Source File
# Begin Source File

SOURCE=.\ideditwnd.cpp
# End Source File
# Begin Source File

SOURCE=.\Infobox.cpp
# End Source File
# Begin Source File

SOURCE=.\LangDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\mainwindow.cpp
# End Source File
# Begin Source File

SOURCE=.\mixerdlg.cpp
# End Source File
# Begin Source File

SOURCE=.\playerwnd.cpp
# End Source File
# Begin Source File

SOURCE=.\playlistw.cpp
# End Source File
# Begin Source File

SOURCE=.\printdlg.cpp
# End Source File
# Begin Source File

SOURCE=.\PrintPreview.cpp
# End Source File
# Begin Source File

SOURCE=.\scandlg.cpp
# End Source File
# Begin Source File

SOURCE=.\vcedit.c
# End Source File
# End Group
# Begin Group "Header-Dateien"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\comdlg.h
# End Source File
# Begin Source File

SOURCE=.\database.h
# End Source File
# Begin Source File

SOURCE=.\devicedlg.h
# End Source File
# Begin Source File

SOURCE=.\DSUtil.h
# End Source File
# Begin Source File

SOURCE=.\Formate.h
# End Source File
# Begin Source File

SOURCE=.\ideditwnd.h
# End Source File
# Begin Source File

SOURCE=.\Infobox.h
# End Source File
# Begin Source File

SOURCE=.\LangDlg.h
# End Source File
# Begin Source File

SOURCE=.\mainwindow.h
# End Source File
# Begin Source File

SOURCE=.\mixerdlg.h
# End Source File
# Begin Source File

SOURCE=.\playerwnd.h
# End Source File
# Begin Source File

SOURCE=.\playlistw.h
# End Source File
# Begin Source File

SOURCE=.\printdlg.h
# End Source File
# Begin Source File

SOURCE=.\PrintPreview.h
# End Source File
# Begin Source File

SOURCE=.\resource.h
# End Source File
# Begin Source File

SOURCE=.\scandlg.h
# End Source File
# Begin Source File

SOURCE=.\vcedit.h
# End Source File
# End Group
# Begin Group "Texte"

# PROP Default_Filter "txt"
# Begin Source File

SOURCE=.\changes.txt
# End Source File
# Begin Source File

SOURCE=.\gpl.txt
# End Source File
# End Group
# End Target
# End Project

/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "playerwnd.h"

PlayerWnd::PlayerWnd(HINSTANCE hCopyLibrary)
{
  Prim_Aux  = NULL;
  Prim_Head = NULL;
  hFontLoad = NULL;
  hFontPM   = NULL;
  hFontCue  = NULL;
  hFontTime = NULL;
  hFontZero = NULL;
  hFontText = NULL;
  hBrush    = NULL;
  _hwnd     = NULL;
  elapse    = FALSE;
  hLibrary  = hCopyLibrary;
  hGreenBrush = CreateSolidBrush(RGB(0,255,0));
  hRedBrush   = CreateSolidBrush(RGB(255,0,0));
  LoadString(hLibrary, IDS_HELPPATH, HelpPath,10);
  FILE *Test = fopen(HelpPath,"r");
  if (Test == NULL) strcpy(HelpPath, "djw_e.hlp");
  else fclose(Test);
}

PlayerWnd::~PlayerWnd()
{
//  DestroyWindow(_hwnd); 
  DeleteObject(hGreenBrush);
  DeleteObject(hRedBrush);
}

void PlayerWnd::Init(HWND Mixer, ndw_DataBase* DataBaseCopy)
{
  // Load Language-dll
  DataBase = DataBaseCopy;
  GetCurrentDirectory(MAX_PATH, IniPath);
  strcat(IniPath, "\\djw.ini");
  char szLanguage[MAX_PATH];
  GetPrivateProfileString("MainWnd","Language", "leng.dll", szLanguage, MAX_PATH,IniPath);
  hDlgMixer = Mixer;
}


void PlayerWnd::DestroyItems()
{
 // Delete Player from Mixer Comboboxes
  char   chGetText[13] = "";
  SendDlgItemMessage(hDlgMixer, ID_CB_PLAYERLEFT, CB_DELETESTRING,
                       SendDlgItemMessage(hDlgMixer, ID_CB_PLAYERLEFT, CB_FINDSTRINGEXACT, 0, (LPARAM) (LPCTSTR) Name), 0);
  SendDlgItemMessage(hDlgMixer, ID_CB_PLAYERRIGHT, CB_DELETESTRING,
                       SendDlgItemMessage(hDlgMixer, ID_CB_PLAYERRIGHT, CB_FINDSTRINGEXACT, 0, (LPARAM) (LPCTSTR) Name),0);
  SendDlgItemMessage(hDlgMixer, ID_CB_PLAYERLEFT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetText);

  if (strcmp(chGetText, Name) == 0) SendDlgItemMessage(hDlgMixer, ID_CB_PLAYERLEFT, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) "");

  SendDlgItemMessage(hDlgMixer, ID_CB_PLAYERRIGHT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetText);
  if (strcmp(chGetText, Name) == 0) SendDlgItemMessage(hDlgMixer, ID_CB_PLAYERRIGHT, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) "");
  SendMessage(_hwnd, WM_GETTEXT,13, (LPARAM) chGetText);

// Destroy Items
  DestroyWindow(hCbAutoCue);
  DestroyWindow(hBtPlay);
  DestroyWindow(hBtCue);
  DestroyWindow(hBtHeadCue);
  DestroyWindow(hSBarVolume);
  DestroyWindow(hSBarHeadVolume);
  DestroyWindow(hSTextStatus);
  DestroyWindow(hBtLoad);
  DestroyWindow(hBtZero);
  DestroyWindow(hBtPlus);
  DestroyWindow(hBtMinus);
  DestroyWindow(hBtTime);
  DestroyWindow(hSBarPitch);
  DestroyWindow(hSBarSeek);
  DestroyWindow(hFrameTime);
  DestroyWindow(hSplitter);
  DestroyWindow(hFrameInfo);
  DestroyWindow(hSTextTime);
  DestroyWindow(hSTextPitch);
  DestroyWindow(hSTextPitchPer);
  DestroyWindow(hSTextHead);
  DestroyWindow(hSTextVolume);
  DestroyWindow(hSTextArtist);
  DestroyWindow(hSTextSong);

  DeleteObject(hFontLoad);
  DeleteObject(hFontPM);
  DeleteObject(hFontTime);
  DeleteObject(hFontCue);
  DeleteObject(hFontZero);
  DeleteObject(hFontText);
  DeleteObject(hBrush);
  DestroyMenu(hMenu);
  DestroyMenu(hFirstMenu); 
//  UnregisterClass(_class.lpszClassName, _class.hInstance);
  // Unregister WindowsClass is not needed

  return;
}

BOOL PlayerWnd::Show(HWND hParent, HINSTANCE hInstance,	LPDIRECTSOUND _Prim_Aux, LPDIRECTSOUND _Prim_Head, int ixPos, int iyPos,
                     int iWidth, int iHeight, char *lpzCaption, BOOL bo_checked, BOOL bo_elapsed, BOOL Mastertempo)
{
  Prim_Aux  = _Prim_Aux;
  Prim_Head = _Prim_Head;
  if (Prim_Head == NULL)
  {
     DSPlayer.Init(Prim_Aux,NULL);
  }
  else
  {
    DSPlayer.Init(Prim_Aux,Prim_Head);
  }
  elapse    =  bo_elapsed;
  strcpy(szClassCaption, lpzCaption);
  memset(&_class,0,sizeof(WNDCLASSEX));
  _class.cbSize        = sizeof(WNDCLASSEX);
  _class.style         = CS_HREDRAW | CS_VREDRAW;
  _class.lpfnWndProc   = (WNDPROC) PlayerWndProc;
  _class.cbClsExtra    = 0;
  _class.cbWndExtra    = sizeof(PlayerWnd*);
  _class.hInstance     = hInstance;
  _class.hIcon         = NULL;
  _class.hCursor       = NULL;
  _class.hbrBackground = (HBRUSH) (COLOR_WINDOW);
  _class.lpszClassName = szClassCaption;
  _class.hIconSm       = NULL;
   RegisterClassEx(&_class); // Fails if WindowClass exists Only one Class is needed
  _hwnd = ::CreateWindowEx(WS_EX_ACCEPTFILES, szClassCaption,szClassCaption,WS_OVERLAPPEDWINDOW,ixPos,
                          iyPos, iWidth, iHeight, hParent, NULL, hInstance,(void FAR*)this);
  if (_hwnd == NULL)
  { return FALSE;}
  else
  {
    ::ShowWindow (_hwnd, SW_SHOWNORMAL);
    ::UpdateWindow (_hwnd);
    SendMessage(hCbAutoCue, BM_SETCHECK, bo_checked,0);
    if (Mastertempo == TRUE)
    {
       CheckMenuItem(hMenu, ID_MN_MASTERTEMPO, MF_BYCOMMAND | MF_CHECKED);
       DSPlayer.Mastertempo = TRUE;
    }
    else
    {
        CheckMenuItem(hMenu, ID_MN_MASTERTEMPO, MF_BYCOMMAND | MF_UNCHECKED);
        DSPlayer.Mastertempo = FALSE;
    }  
    strcpy(Name,lpzCaption);
    timeGetDevCaps(&ptc, sizeof(TIMECAPS));
    return TRUE;
  }
}


void PlayerWnd::SetControls()
{
  char pzsBuffer[260];
  LoadString(hLibrary,IDS_LOAD, pzsBuffer, sizeof(pzsBuffer));
  // First raw Frames, although te other elements will be overdrawn
  hFrameTime  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "", SS_SUNKEN | WS_CHILD | WS_VISIBLE,
                               4, 36, 161, 60, _hwnd, NULL, NULL,NULL);
  hFrameInfo  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "", SS_SUNKEN | WS_CHILD | WS_VISIBLE,
                               66, 168, 174, 37, _hwnd, NULL, NULL,NULL);

  
  hBtLoad     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),pzsBuffer, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               4, 4, 65, 25, _hwnd, (HMENU)ID_BTLOAD,NULL,NULL);

  hBtMinus    = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"), "-", BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               144, 4, 30, 30, _hwnd, (HMENU)ID_BTMINUS, NULL,NULL);

  hBtPlus     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"), "+", BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               176, 4, 30, 30, _hwnd, (HMENU)ID_BTPLUS, NULL,NULL);

  hSBarPitch  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("SCROLLBAR"), "", SBS_VERT | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               214, 4, 25, 150, _hwnd, (HMENU)ID_SBARPITCH, NULL,NULL);
  SendMessage(hSBarPitch, SBM_SETRANGE,0, 255);
  SendMessage(hSBarPitch, SBM_SETPOS,127,TRUE);

  hBtTime     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"), "Time",  BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE,
                               8, 40, 45, 20, _hwnd, (HMENU)ID_BTTIME, NULL,NULL); 
  hSTextTime  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "No Song",  SS_LEFT | WS_CHILD | WS_VISIBLE,
                                8, 64, 155, 30, _hwnd, NULL, NULL,NULL);
  hSBarSeek   = CreateWindowEx (WS_EX_NOPARENTNOTIFY, TEXT("SCROLLBAR"), "", SBS_HORZ | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                                4, 96, 161, 17, _hwnd, (HMENU)ID_SBARSEEK, NULL,NULL);
  hBtZero     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"), "Zero",  BS_PUSHBUTTON| WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               170, 72, 40, 20, _hwnd, (HMENU)ID_BTZERO, NULL,NULL);
  hSTextStatus  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "Status",  SS_LEFT | WS_CHILD | WS_VISIBLE,
                                  4, 136, 36, 14, _hwnd, NULL, NULL,NULL);
  hBtCue      = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),"CUE", BS_OWNERDRAW | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               120, 115, 40, 40, _hwnd, (HMENU)ID_BTCUE,NULL,NULL);
  hBtPlay     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),"",BS_OWNERDRAW | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               168, 115, 40, 40, _hwnd, (HMENU)ID_BTPLAY, NULL,NULL);
  hSplitter   = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "", SS_ETCHEDHORZ | WS_CHILD | WS_VISIBLE,
                                0, 160, 242, 10, _hwnd, NULL, NULL,NULL);
  hSBarVolume = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("SCROLLBAR"), "", SBS_VERT | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                                4, 168, 25, 89, _hwnd, (HMENU)ID_SBARVOLUME, NULL,NULL);
  SendMessage(hSBarVolume, SBM_SETRANGE,0, 3000);
  SendMessage(hSBarVolume, SBM_SETPOS,0, TRUE);

  hBtHeadCue  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"), "",BS_BITMAP | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               36, 168, 25, 25, _hwnd, (HMENU)ID_BTHEAD, NULL,NULL);

  hSBarHeadVolume = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("SCROLLBAR"), "", SBS_VERT | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                                36, 193, 25, 63, _hwnd, (HMENU)ID_SBARVOLUME, NULL,NULL);
  SendMessage(hSBarHeadVolume, SBM_SETRANGE,0, 3000);
  SendMessage(hSBarHeadVolume, SBM_SETPOS,0, TRUE);
  
  
  hCbAutoCue  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"), "Cue-Load", BS_AUTOCHECKBOX | WS_CHILD | WS_VISIBLE,
                               68, 212, 65, 17, _hwnd, (HMENU)ID_CBAUTOCUE, NULL,NULL);

  hSTextVolume  = CreateWindowEx (WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "Aux",  SS_LEFT | WS_CHILD | WS_VISIBLE,
                                  4, 260, 30, 14, _hwnd, NULL, NULL,NULL);

  hSTextHead  = CreateWindowEx (WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "Head",  SS_LEFT | WS_CHILD | WS_VISIBLE,
                                  30, 260, 35, 14, _hwnd, NULL, NULL,NULL);

  hSTextArtist  = CreateWindowEx (WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "",  SS_LEFT | WS_CHILD | WS_VISIBLE,
                                  70, 172, 166, 14, _hwnd, NULL, NULL,NULL);

  hSTextSong  = CreateWindowEx (WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "",  SS_LEFT | WS_CHILD | WS_VISIBLE,
                                  70, 188, 166, 14, _hwnd, NULL, NULL,NULL);

  hSTextPitch = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "Pitch:",SS_LEFT | WS_CHILD | WS_VISIBLE,
                               99, 40, 26, 14, _hwnd, NULL, NULL,NULL);
  hSTextPitchPer = CreateWindowEx (WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), "0", SS_RIGHT | WS_CHILD | WS_VISIBLE,
                              125, 40, 37, 14, _hwnd, NULL, NULL,NULL);

  HeadCue = FALSE;
  if (Prim_Head == NULL)
  {
    EnableWindow(hBtHeadCue, FALSE);
    EnableWindow(hSTextHead, FALSE);
    EnableWindow(hSBarHeadVolume, FALSE);
  }
}

void PlayerWnd::MoveControls(int iWidth, int iHeight)
{

  if (GetMenuState(hMenu, ID_MN_PROPORTIONAL, MF_BYCOMMAND) == MF_CHECKED)
  {
    iWidth = static_cast<int>(iHeight/1.2); //Nur Poportional Vergr�ssern
    SetWindowPos(_hwnd, HWND_NOTOPMOST	, 0, 0, iWidth, iHeight, SWP_NOMOVE);
  }
  double Hoehe  = iHeight;
  double Breite = iWidth;

  if (hFontLoad != NULL) DeleteObject(hFontLoad);
  if (hFontPM != NULL) DeleteObject(hFontPM);
  if (hFontCue != NULL) DeleteObject(hFontCue);
  if (hFontTime != NULL) DeleteObject(hFontTime);
  if (hFontZero != NULL) DeleteObject(hFontZero);
  if (hFontText != NULL) DeleteObject(hFontText);

  //Do The Text first although it will be overdrawn from the Frames
  hFontText  = CreateFont(static_cast<int>(-Hoehe/27.27272), 0, 0, 0, FW_NORMAL, FALSE, FALSE,	FALSE, ANSI_CHARSET,
               OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
               DEFAULT_PITCH | FF_DONTCARE, "Arial" );


  MoveWindow(hSTextArtist, static_cast<int>(Breite/3.5714), static_cast<int>(Hoehe/1.7442), static_cast<int>(Breite/1.50602),  static_cast<int>(Hoehe/21.4286), TRUE);
  SendMessage(hSTextArtist, WM_SETFONT, (WPARAM)hFontText, TRUE);
  MoveWindow(hSTextSong, static_cast<int>(Breite/3.5714), static_cast<int>(Hoehe/1.5957), static_cast<int>(Breite/1.50602),  static_cast<int>(Hoehe/21.4286), TRUE);
  SendMessage(hSTextSong, WM_SETFONT, (WPARAM)hFontText, TRUE);
  MoveWindow(hCbAutoCue, static_cast<int>(Breite/3.676), static_cast<int>(Hoehe/1.415), static_cast<int>(Breite/1.50602),  static_cast<int>(Hoehe/17.647), TRUE);
  SendMessage(hCbAutoCue, WM_SETFONT, (WPARAM)hFontText, TRUE);
  MoveWindow(hSTextVolume, static_cast<int>((Breite/31.25)), static_cast<int>(Hoehe/1.1538), static_cast<int>(Breite/10),  static_cast<int>(Hoehe/21.4286), TRUE);
  SendMessage(hSTextVolume, WM_SETFONT, (WPARAM)hFontText, TRUE);
  MoveWindow(hSTextHead, static_cast<int>(Breite/6.944), static_cast<int>(Hoehe/1.1538), static_cast<int>(Breite/10),  static_cast<int>(Hoehe/21.4286), TRUE);
  SendMessage(hSTextHead, WM_SETFONT, (WPARAM)hFontText, TRUE);
  MoveWindow(hBtTime, static_cast<int>(Breite/31.25), static_cast<int>(Hoehe/7.5), static_cast<int>(Breite/5.5556),  static_cast<int>(Hoehe/15), TRUE);
  SendMessage(hBtTime, WM_SETFONT, (WPARAM)hFontText, TRUE);

  SendMessage(hSTextPitch, WM_SETFONT, (WPARAM)hFontText, TRUE);
  SendMessage(hSTextPitchPer, WM_SETFONT, (WPARAM)hFontText, TRUE);
  MoveWindow(hSTextPitch, static_cast<int>(Breite/2.52525), static_cast<int>(Hoehe/7.5), static_cast<int>(Breite/9.6154),  static_cast<int>(Hoehe/21.4286), TRUE);
  MoveWindow(hSTextPitchPer, static_cast<int>(Breite/2), static_cast<int>(Hoehe/7.5), static_cast<int>(Breite/6.7568),  static_cast<int>(Hoehe/21.4286), TRUE);


  hFontLoad  = CreateFont(static_cast<int>(-Hoehe/25), 0, 0, 0, FW_BOLD, FALSE, FALSE,	FALSE, ANSI_CHARSET,
                      OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                      DEFAULT_PITCH | FF_DONTCARE, "Arial" );
  MoveWindow(hBtLoad, static_cast<int>(Breite/62.5), static_cast<int>(Hoehe/75), static_cast<int>(Breite/3.84615), static_cast<int>(Hoehe/12), TRUE);
  SendMessage(hBtLoad, WM_SETFONT, (WPARAM)hFontLoad, TRUE);


  hFontPM    = CreateFont(static_cast<int>(-Hoehe/18.75), 0, 0, 0, FW_BOLD, FALSE, FALSE,	FALSE, ANSI_CHARSET,
               OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
               DEFAULT_PITCH | FF_DONTCARE, "Arial" );
  MoveWindow(hBtMinus, static_cast<int>(Breite/1.736), static_cast<int>(Hoehe/75), static_cast<int>(Breite/8.333),  static_cast<int>(Hoehe/10), TRUE);
  SendMessage(hBtMinus, WM_SETFONT, (WPARAM)hFontPM, TRUE);
  MoveWindow(hBtPlus, static_cast<int>(Breite/1.420), static_cast<int>(Hoehe/75), static_cast<int>(Breite/8.333),  static_cast<int>(Hoehe/10), TRUE);
  SendMessage(hBtPlus, WM_SETFONT, (WPARAM)hFontPM, TRUE);


  hFontTime  = CreateFont(static_cast<int>(-Hoehe/12), 0, 0, 0, FW_BOLD, FALSE, FALSE,	FALSE, ANSI_CHARSET,
               OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
               DEFAULT_PITCH | FF_DONTCARE, "Arial" );
  MoveWindow(hSTextTime, static_cast<int>(Breite/31.25), static_cast<int>(Hoehe/4.6875), static_cast<int>(Breite/1.6129),  static_cast<int>(Hoehe/10), TRUE);
  SendMessage(hSTextTime, WM_SETFONT, (WPARAM)hFontTime, TRUE);

  hFontZero  = CreateFont(static_cast<int>(-Hoehe/27.27272), 0, 0, 0, FW_BOLD, FALSE, FALSE,	FALSE, ANSI_CHARSET,
               OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                DEFAULT_PITCH | FF_DONTCARE, "Arial" );
  MoveWindow(hBtZero, static_cast<int>(Breite/1.471), static_cast<int>(Hoehe/4.167), static_cast<int>(Breite/6.25),  static_cast<int>(Hoehe/15), TRUE);
  SendMessage(hBtZero, WM_SETFONT, (WPARAM)hFontZero, TRUE);
  MoveWindow(hSTextStatus, static_cast<int>(Breite/62.5), static_cast<int>(Hoehe/2.206), static_cast<int>(Breite/5),  static_cast<int>(Hoehe/15), TRUE);
  SendMessage(hSTextStatus, WM_SETFONT, (WPARAM)hFontZero, TRUE);


  hFontCue   = CreateFont(static_cast<int>(-Hoehe/23.0769), 0, 0, 0, FW_BOLD, FALSE, FALSE,	FALSE, ANSI_CHARSET,
               OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
               DEFAULT_PITCH | FF_DONTCARE, "Arial" );
  MoveWindow(hBtCue, static_cast<int>(Breite/2.083), static_cast<int>(Hoehe/2.609), static_cast<int>(Breite/6.25),  static_cast<int>(Hoehe/7.5), TRUE);
  SendMessage(hBtCue, WM_SETFONT, (WPARAM)hFontCue, TRUE);

  //Without Fonts
  MoveWindow(hSBarSeek, static_cast<int>(Breite/62.5), static_cast<int>(Hoehe/3.125), static_cast<int>(Breite/1.5528),  static_cast<int>(Hoehe/17.6471), TRUE);
  MoveWindow(hSBarPitch, static_cast<int>(Breite/1.168), static_cast<int>(Hoehe/75), static_cast<int>(Breite/10),  static_cast<int>(Hoehe/2), TRUE);
  MoveWindow(hFrameTime, static_cast<int>(Breite/62.5), static_cast<int>(Hoehe/8.33333), static_cast<int>(Breite/1.5528),  static_cast<int>(Hoehe/5), TRUE);
  MoveWindow(hBtPlay, static_cast<int>(Breite/1.488), static_cast<int>(Hoehe/2.609), static_cast<int>(Breite/6.25),  static_cast<int>(Hoehe/7.5), TRUE);
  MoveWindow(hSplitter, 0, static_cast<int>(Hoehe/1.875), static_cast<int>(Breite),  2, TRUE);
  MoveWindow(hSBarVolume, static_cast<int>(Breite/62.5), static_cast<int>(Hoehe/1.785), static_cast<int>(Breite/10),  static_cast<int>(Hoehe/3.371), TRUE);

  MoveWindow(hSBarHeadVolume, static_cast<int>(Breite/6.944), static_cast<int>(Hoehe/1.5544), static_cast<int>(Breite/10),  static_cast<int>(Hoehe/4.762), TRUE);

  
  
  MoveWindow(hBtHeadCue, static_cast<int>(Breite/6.944), static_cast<int>(Hoehe/1.785), static_cast<int>(Breite/10),  static_cast<int>(Hoehe/12), TRUE);
  MoveWindow(hFrameInfo, static_cast<int>(Breite/3.788), static_cast<int>(Hoehe/1.785), static_cast<int>(Breite/1.437),  static_cast<int>(Hoehe/8.108), TRUE);





  ::UpdateWindow (_hwnd);

}

void PlayerWnd::btLoadClick()
{
 char   pzsBuffer[50]  = "";
 char   pzsBufferW[10] = "";
 char   lbStatus[10]   = "";
  
  int i = SendMessage(hSTextStatus, WM_GETTEXTLENGTH,0,0);
  SendMessage(hSTextStatus, WM_GETTEXT,(WPARAM)i+1, (LPARAM) lbStatus);
  if ((strcmp(lbStatus, "playing")== 0) | (strcmp(lbStatus, "seeking")== 0))
  {return;}
  else
  {
    DataSet = DataBase->GetActualDataSet();
    FILE *hFile = fopen(DataSet.szPath, "r");;
    if ( hFile != NULL)
    {
      fclose(hFile);

      if (DSPlayer.loaded == true)
      { // Zerst�ren des Vorhergehenden DSPlayers
        DSPlayer.UnLoad();
      }

      char *ext = strrchr(DataSet.szPath,'.');
      ext[1] = (char) toupper(ext[1]);
      ext[2] = (char) toupper(ext[2]);
      ext[3] = (char) toupper(ext[3]);
      DSPlayer.Load(DataSet.szPath, SendDlgItemMessage(hDlgMixer, ID_UD_PLAYSTART, UDM_GETPOS, 0, 0), ext);

      //Set Range of Seekbar
      SendMessage(hSBarSeek, SBM_SETRANGE,0, (LPARAM) DSPlayer.GetDuration());

      int StartTime = 0;
      //Look if AutoCue checked
      if (SendMessage(hCbAutoCue,BM_GETCHECK, 0,0) == BST_CHECKED){StartTime = DataSet.StartTime;}
      //Set Scrollbar Position
      SendMessage(hSBarSeek, SBM_SETPOS,(WPARAM) StartTime ,TRUE);
      //Seek to Scrollbar Position
      DSPlayer.Seek(StartTime);

      DSPlayer.Aux_Volume(-(SendMessage(hSBarVolume, SBM_GETPOS,0,0)));
      DSPlayer.Pitch(SendMessage(hSBarPitch, SBM_GETPOS,0,0)-127);
      if (HeadCue==TRUE){DSPlayer.Head_Volume(-SendMessage(hSBarHeadVolume, SBM_GETPOS,0,0));}
      else {DSPlayer.Head_Volume(-10000);}

      SendMessage(hSTextStatus, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) "loaded");
      SendMessage(hSTextArtist, WM_SETTEXT, 0, (LPARAM) DataSet.szArtist);

      SendMessage(hSTextSong, WM_SETTEXT, 0,(LPARAM) DataSet.szSongname);


      SendMessage(hBtPlay, BM_SETSTATE, FALSE, 0);
      SendMessage(hBtCue, BM_SETSTATE, TRUE, 0);
      DSPlayer.FastEnde = FALSE;
      DisplayTime();

    }// If FileExists...
    else
    {
       LoadString(hLibrary,IDS_FILE_NOT_EXIST, pzsBuffer, sizeof(pzsBuffer));
       LoadString(hLibrary,IDS_WARNING, pzsBufferW, sizeof(pzsBuffer));
       MessageBox(_hwnd,(LPCTSTR) pzsBuffer,
                  (LPCTSTR) pzsBufferW, MB_ICONWARNING );
    }
  } // if Playing ...

}

void PlayerWnd::btTimeClick()
{
 if (DSPlayer.loaded == true)
 {
   if (elapse == TRUE) {elapse = FALSE;}
   else {elapse = TRUE;}
   DisplayTime();
 }
}

void PlayerWnd::DisplayTime()
{
  int i = GetScrollPos(hSBarSeek, SB_CTL);
  SendMessage(hSTextTime, WM_SETTEXT,0, (LPARAM) (LPCTSTR) DSPlayer.GetTime(i, elapse));
}

void PlayerWnd::SBarSeekScroll(int iScrollCode, int iScrollPos, int iScrollPosMouse)
{
   if (DSPlayer.loaded == true)
   {
      int i = SendMessage(hSTextStatus, WM_GETTEXTLENGTH,0,0);
      char   lbStatus[10]   = "";
      SendMessage(hSTextStatus, WM_GETTEXT,(WPARAM)i+1, (LPARAM) lbStatus);
      if (strcmp(lbStatus, "playing") == 0)
      {
        timeKillEvent(idTimer);
        timeEndPeriod(uPeriod);
		DSPlayer.Pause();
      }
      if (strcmp(lbStatus, "seeking") != 0)
	  {
		  DSPlayer.CuePlay();
          SendMessage(hSTextStatus, WM_SETTEXT,0, (LPARAM) "seeking");
          SendMessage(hBtPlay, BM_SETSTATE, FALSE, 0);
          SendMessage(hBtCue, BM_SETSTATE, FALSE, 0);
	  }

      switch (iScrollCode)
      {
      case  SB_PAGERIGHT:
            SetScrollPos(hSBarSeek, SB_CTL, iScrollPos+10, TRUE);
            DSPlayer.Seek(iScrollPos+10);
            DisplayTime();
            break;
      case  SB_LINERIGHT:
            SetScrollPos(hSBarSeek, SB_CTL, iScrollPos+1, TRUE);
            DSPlayer.Seek(iScrollPos+1);
            DisplayTime();
            break;
      case  SB_PAGELEFT:
            SetScrollPos(hSBarSeek, SB_CTL, iScrollPos-10, TRUE);
            DSPlayer.Seek(iScrollPos-10);
            DisplayTime();
            break;
      case  SB_LINELEFT:
            SetScrollPos(hSBarSeek, SB_CTL, iScrollPos-1, TRUE);
            DSPlayer.Seek(iScrollPos-1);
            DisplayTime();
            break;
      case  SB_TOP:
            SetScrollPos(hSBarSeek, SB_CTL, 0, TRUE);
            DSPlayer.Seek(0);
            DisplayTime();
            break;
      case  SB_BOTTOM:
            SetScrollPos(hSBarSeek, SB_CTL, DSPlayer.GetDuration(), TRUE);
            DSPlayer.Seek(200);
            DisplayTime();
            break;
      case  SB_THUMBPOSITION:
            SetScrollPos(hSBarSeek, SB_CTL, iScrollPosMouse, TRUE);
            DSPlayer.Seek(iScrollPosMouse);
            DisplayTime();
      case  SB_THUMBTRACK:
            SendMessage(hSTextTime, WM_SETTEXT,0, (LPARAM) DSPlayer.GetTime(iScrollPosMouse, elapse));
            break;
      case  SB_ENDSCROLL:
            break;
      default:
            break;
      } //switch ...
 }
}

void PlayerWnd::SBarPitchScroll(int iScrollCode, int iScrollPos, int iScrollPosMouse)
{
// �ndern des Pitches
  double fPitch;
  int ndec = 3;
  char  lpzPitch[7] = "00.00%";

  if (DSPlayer.loaded == true)
  {
   if ((iScrollPos < 256) & (iScrollPos > -1))
   {
      switch (iScrollCode)
      {
      case  SB_PAGEDOWN:
            SetScrollPos(hSBarPitch, SB_CTL, iScrollPos+10, TRUE);
            DSPlayer.Pitch(iScrollPos-127+10);
            fPitch = iScrollPos-127+10;
            fPitch = fPitch/10;
            gcvt(fPitch, ndec, lpzPitch);
            SendMessage(hSTextPitchPer, WM_SETTEXT,0, (LPARAM) lpzPitch);
            break;
      case  SB_LINEDOWN:
            SetScrollPos(hSBarPitch, SB_CTL, iScrollPos+1, TRUE);
            DSPlayer.Pitch(iScrollPos-127+1);
            fPitch = iScrollPos-127+1;
            fPitch = fPitch/10;
            gcvt(fPitch, ndec, lpzPitch);
            SendMessage(hSTextPitchPer, WM_SETTEXT,0, (LPARAM) lpzPitch);
            break;
      case  SB_PAGEUP:
            SetScrollPos(hSBarPitch, SB_CTL, iScrollPos-10, TRUE);
            DSPlayer.Pitch(iScrollPos-127-10);
            fPitch = iScrollPos-127-10;
            fPitch = fPitch/10;
            gcvt(fPitch, ndec, lpzPitch);
            SendMessage(hSTextPitchPer, WM_SETTEXT,0, (LPARAM) lpzPitch);
            break;
      case  SB_LINEUP:
            SetScrollPos(hSBarPitch, SB_CTL, iScrollPos-1, TRUE);
            DSPlayer.Pitch(iScrollPos-127-1);
            fPitch = iScrollPos-127-1;
            fPitch = fPitch/10;
            gcvt(fPitch, ndec, lpzPitch);
            SendMessage(hSTextPitchPer, WM_SETTEXT,0, (LPARAM) lpzPitch);
            break;
      case  SB_TOP:
            SetScrollPos(hSBarPitch, SB_CTL, 0, TRUE);
            DSPlayer.Pitch(-127);
            fPitch = -12.7;
            gcvt(fPitch, ndec, lpzPitch);
            SendMessage(hSTextPitchPer, WM_SETTEXT,0, (LPARAM) lpzPitch);
            break;
      case  SB_BOTTOM:
            SetScrollPos(hSBarPitch, SB_CTL, 255, TRUE);
            DSPlayer.Pitch(127);
            fPitch = +12.7;
            gcvt(fPitch, ndec, lpzPitch);
            SendMessage(hSTextPitchPer, WM_SETTEXT,0, (LPARAM) lpzPitch);
            break;
      case  SB_THUMBPOSITION:
            SetScrollPos(hSBarPitch, SB_CTL, iScrollPosMouse, TRUE);
            break;
      case  SB_THUMBTRACK:
            DSPlayer.Pitch(iScrollPosMouse-127);
            fPitch = iScrollPosMouse-127;
            fPitch = fPitch/10;
            gcvt(fPitch, ndec, lpzPitch);
            SendMessage(hSTextPitchPer, WM_SETTEXT,0, (LPARAM) lpzPitch);
            break;
      case  SB_ENDSCROLL:
            break;
      default:
            break;
      } //switch ...
   }

  }
}

void PlayerWnd::SBarVolumeScroll(int iScrollCode, int iScrollPos, int iScrollPosMouse)
{
 if (DSPlayer.loaded == true)
 {
      switch (iScrollCode)
      {
      case  SB_PAGEDOWN:
            SetScrollPos(hSBarVolume, SB_CTL, iScrollPos+100, TRUE);
            DSPlayer.Aux_Volume(-(iScrollPos+100));
			if (iScrollPos > 2900) DSPlayer.Aux_Volume(-10000);
            break;
      case  SB_LINEDOWN:
            SetScrollPos(hSBarVolume, SB_CTL, iScrollPos+10, TRUE);
            DSPlayer.Aux_Volume(-(iScrollPos+10));
			if (iScrollPos > 2900) DSPlayer.Aux_Volume(-10000);
            break;
      case  SB_PAGEUP:
            SetScrollPos(hSBarVolume, SB_CTL, iScrollPos-100, TRUE);
            DSPlayer.Aux_Volume(-(iScrollPos-100));
            break;
      case  SB_LINEUP:
            SetScrollPos(hSBarVolume, SB_CTL, iScrollPos-10, TRUE);
            DSPlayer.Aux_Volume(-(iScrollPos-10));
            break;
      case  SB_TOP:
            SetScrollPos(hSBarVolume, SB_CTL, 0, TRUE);
            DSPlayer.Aux_Volume(0);
            break;
      case  SB_BOTTOM:
            SetScrollPos(hSBarVolume, SB_CTL, 3000, TRUE);
            DSPlayer.Aux_Volume(-10000);
            break;
      case  SB_THUMBPOSITION:
            SetScrollPos(hSBarVolume, SB_CTL, iScrollPosMouse, TRUE);
            DSPlayer.Aux_Volume(-iScrollPosMouse);
			if (iScrollPosMouse > 2900) DSPlayer.Aux_Volume(-10000);
            break;
      case  SB_THUMBTRACK:
			if (iScrollPosMouse > 2900) DSPlayer.Aux_Volume(-10000);
            DSPlayer.Aux_Volume(-iScrollPosMouse);
            break;
      } //switch ...
 }
}

void PlayerWnd::SBarHeadVolumeScroll(int iScrollCode, int iScrollPos, int iScrollPosMouse)
{
 if (HeadCue==TRUE)if (DSPlayer.loaded == true)
 {
      switch (iScrollCode)
      {
      case  SB_PAGEDOWN:
            SetScrollPos(hSBarHeadVolume, SB_CTL, iScrollPos+100, TRUE);
            DSPlayer.Head_Volume(-(iScrollPos+100));
			if (iScrollPos > 2900) DSPlayer.Head_Volume(-10000);
            break;
      case  SB_LINEDOWN:
            SetScrollPos(hSBarHeadVolume, SB_CTL, iScrollPos+10, TRUE);
            DSPlayer.Head_Volume(-(iScrollPos+10));
			if (iScrollPos > 2900) DSPlayer.Head_Volume(-10000);
            break;
      case  SB_PAGEUP:
            SetScrollPos(hSBarHeadVolume, SB_CTL, iScrollPos-100, TRUE);
            DSPlayer.Head_Volume(-(iScrollPos-100));
            break;
      case  SB_LINEUP:
            SetScrollPos(hSBarHeadVolume, SB_CTL, iScrollPos-10, TRUE);
            DSPlayer.Head_Volume(-(iScrollPos-10));
            break;
      case  SB_TOP:
            SetScrollPos(hSBarHeadVolume, SB_CTL, 0, TRUE);
            DSPlayer.Head_Volume(0);
            break;
      case  SB_BOTTOM:
            SetScrollPos(hSBarHeadVolume, SB_CTL, 3000, TRUE);
            DSPlayer.Head_Volume(-10000);
            break;
      case  SB_THUMBPOSITION:
            SetScrollPos(hSBarHeadVolume, SB_CTL, iScrollPosMouse, TRUE);
            DSPlayer.Head_Volume(-iScrollPosMouse);
			if (iScrollPosMouse > 2900) DSPlayer.Head_Volume(-10000);
            break;
      case  SB_THUMBTRACK:
            DSPlayer.Head_Volume(-iScrollPosMouse);
			if (iScrollPosMouse > 2900) DSPlayer.Head_Volume(-10000);
            break;
      } //switch ...
 }
}


void PlayerWnd::OnDropFile(HDROP hDropFile)
{

// Aufruf beim Drag'n Drop

  char caFileName[MAX_PATH];
  char   lbStatus[10]   = "";

    // L�nge des Dateinamens bestimmen:
    int ilStrLength=DragQueryFile(hDropFile,0,NULL,0);
    // Dateinamen in char-Array caFileName �bernehmen:
    DragQueryFile(hDropFile, 0, caFileName, ilStrLength+1);
    // ...und ab in den DSPlayer - Falls es ein mp3 ist:
    char *ext = strrchr(caFileName,'.');
    if (ext != NULL)
    {
      ext[1] = (char) toupper(ext[1]);
      ext[2] = (char) toupper(ext[2]);
      ext[3] = (char) toupper(ext[3]);
      if ((strcmp(ext, ".MP3")==0) | (strcmp(ext, ".OGG")==0)| (strcmp(ext, ".WAV")==0))
      {
        int i = SendMessage(hSTextStatus, WM_GETTEXTLENGTH,0,0);
        SendMessage(hSTextStatus, WM_GETTEXT,(WPARAM)i+1, (LPARAM) lbStatus);
        if ((strcmp(lbStatus, "playing")== 0) | (strcmp(lbStatus, "seeking")== 0))
        {return;}
        else
        {
         // evtl noch Hole mp3 id3-Tag

          if (DSPlayer.loaded == true)
          { // Zerst�ren des Vorhergehenden DSPlayers
            DSPlayer.UnLoad();
          }

          DSPlayer.Load((char *) caFileName, SendDlgItemMessage(hDlgMixer, ID_UD_PLAYSTART, UDM_GETPOS, 0, 0), ext);

          SendMessage(hSBarSeek, SBM_SETRANGE,0, (LPARAM) DSPlayer.GetDuration());
          SendMessage(hSBarSeek, SBM_SETPOS,(WPARAM) 0,TRUE);

          DSPlayer.Seek(SendMessage(hSBarSeek, SBM_GETPOS,0,0));
          DSPlayer.Aux_Volume(-(SendMessage(hSBarVolume, SBM_GETPOS,0,0)));
          DSPlayer.Pitch(SendMessage(hSBarPitch, SBM_GETPOS,0,0)-200);

          if (HeadCue==TRUE){DSPlayer.Head_Volume(-SendMessage(hSBarHeadVolume, SBM_GETPOS,0,0));}
          else {DSPlayer.Head_Volume(-10000);}

          SendMessage(hSTextStatus, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) "loaded");

          SendMessage(hSTextArtist, WM_SETTEXT, 0, (LPARAM) strrchr(caFileName,'\\'));
          SendMessage(hSTextSong, WM_SETTEXT, 0,(LPARAM)"");
          SendMessage(hBtPlay, BM_SETSTATE, FALSE, 0);
          SendMessage(hBtCue, BM_SETSTATE, TRUE, 0);
          DSPlayer.FastEnde = FALSE;
          DisplayTime();
        }// if (ext == "mp3")
     } // if (ext != NULL)
   }
  DragFinish(hDropFile);
}

void PlayerWnd::DrawBtPlay(LPDRAWITEMSTRUCT lpdis)
{
  POINT pt1;
  HPEN hPen, hPenLeft, hPenRight;

  SetBkColor(lpdis->hDC,RGB(0,255,0));
  SetTextColor(lpdis->hDC,RGB(0,0,0));
  FillRect(lpdis->hDC, &lpdis->rcItem, hGreenBrush);

  if (SendMessage(hBtPlay, BM_GETSTATE, FALSE, 0) == BST_PUSHED	)
  {
     hPenRight = CreatePen(PS_SOLID, 1, RGB(0, 0,0));
     hPenLeft = CreatePen(PS_SOLID, 2, RGB(255, 255,255));
  }
  else
  {
     hPenRight = CreatePen(PS_SOLID, 1, RGB(255, 255,255));
     hPenLeft = CreatePen(PS_SOLID, 2, RGB(0, 0,0));
  }
  //Temporary GDI-Oject due to a win32-Resource-Leak Bug
  HGDIOBJ tmp = SelectObject(lpdis->hDC, hPenRight);
  MoveToEx(lpdis->hDC, lpdis->rcItem.left, lpdis->rcItem.bottom, &pt1);
  LineTo(lpdis->hDC, lpdis->rcItem.left, lpdis->rcItem.top);
  LineTo(lpdis->hDC, lpdis->rcItem.right, lpdis->rcItem.top);

  // restore old value to prevent Resource Leak
  SelectObject(lpdis->hDC, tmp);
  tmp = SelectObject(lpdis->hDC, hPenLeft);
  LineTo(lpdis->hDC, lpdis->rcItem.right, lpdis->rcItem.bottom);
  LineTo(lpdis->hDC, lpdis->rcItem.left, lpdis->rcItem.bottom);
  // restore old value to prevent Resource Leak
  SelectObject(lpdis->hDC, tmp);
  DeleteObject(hPenRight);
  DeleteObject(hPenLeft);

  POINT pt[3];

  hPen = CreatePen(PS_SOLID, 0, RGB(0, 0,0));
  tmp = SelectObject(lpdis->hDC, hPen);
  int cx = lpdis->rcItem.right - lpdis->rcItem.left;
  int cy = lpdis->rcItem.bottom - lpdis->rcItem.top;
  pt[0].x = 3 * cx / 16; pt[0].y = 5 * cy / 16;
  pt[1].x = 9 * cx / 16; pt[1].y = 8 * cy / 16;
  pt[2].x = 3 * cx / 16; pt[2].y = 11 * cy / 16;

  // restore old value to prevent Resource Leak
  SelectObject(lpdis->hDC, tmp);
  DeleteObject(hPen);
 
  HGDIOBJ BlackBrush = GetStockObject(BLACK_BRUSH);
  tmp = SelectObject(lpdis->hDC, BlackBrush);
  hPen = CreatePen(PS_SOLID, 2, RGB(0, 0,0));
  
  MoveToEx(lpdis->hDC, 11 * cx / 16,  pt[0].y, &pt1);
  LineTo(lpdis->hDC, 11 * cx / 16, pt[2].y);
  MoveToEx(lpdis->hDC, 13 * cx / 16,  pt[0].y, &pt1);
  LineTo(lpdis->hDC, 13 * cx / 16, pt[2].y);
  
  Polygon(lpdis->hDC,pt, 3);

  // restore old value to prevent Resource Leak
  SelectObject(lpdis->hDC, tmp);
  DeleteObject(hPen);
  DeleteObject(BlackBrush);
  return;

}

void PlayerWnd::DrawBtCue(LPDRAWITEMSTRUCT lpdis)
{
  POINT pt;
  HPEN hPenLeft, hPenRight;

  SetBkColor(lpdis->hDC,RGB(255,0,0));
  SetTextColor(lpdis->hDC,RGB(0,0,0));
  FillRect(lpdis->hDC, &lpdis->rcItem, hRedBrush);
  DrawText(lpdis->hDC,"CUE", 3,&lpdis->rcItem ,DT_VCENTER | DT_CENTER | DT_SINGLELINE);
  if (SendMessage(hBtCue, BM_GETSTATE, FALSE, 0) == BST_PUSHED	)
  {
	  hPenLeft  = CreatePen(PS_SOLID, 1, RGB(0, 0,0));
	  hPenRight = CreatePen(PS_SOLID, 2, RGB(255, 255,255));
  }
  else
  {
	  hPenLeft  = CreatePen(PS_SOLID, 1, RGB(255, 255,255));
	  hPenRight = CreatePen(PS_SOLID, 2, RGB(0, 0,0));
  }
  //Temporary GDI-Oject due to a win32-Resource-Leak Bug
  HGDIOBJ tmp = SelectObject(lpdis->hDC, hPenLeft);
  MoveToEx(lpdis->hDC, lpdis->rcItem.left, lpdis->rcItem.bottom, &pt);
  LineTo(lpdis->hDC, lpdis->rcItem.left, lpdis->rcItem.top);
  LineTo(lpdis->hDC, lpdis->rcItem.right, lpdis->rcItem.top);

  // restore old value to prevent Resource Leak
  SelectObject(lpdis->hDC, tmp);

  tmp = SelectObject(lpdis->hDC, hPenRight);
  LineTo(lpdis->hDC, lpdis->rcItem.right, lpdis->rcItem.bottom);
  LineTo(lpdis->hDC, lpdis->rcItem.left, lpdis->rcItem.bottom);

  // restore old value to prevent Resource Leak
  SelectObject(lpdis->hDC, tmp);
  DeleteObject(hPenLeft);
  DeleteObject(hPenRight);
}

LRESULT PlayerWnd::Events(UINT message, WPARAM wParam, LPARAM lParam)
{
  RECT             rect;
  POINT            point;
  char lbStatus[10]   = "";
  int  i;

  switch (message)
  {
      case WM_COMMAND:
           switch (LOWORD(wParam))
           {
           case ID_BTLOAD:
                btLoadClick();
                return 0;
           case ID_BTTIME:
                btTimeClick();
                return 0;
           case ID_MN_PROPORTIONAL:
                if (GetMenuState(hMenu, ID_MN_PROPORTIONAL, MF_BYCOMMAND) == MFS_CHECKED)
                {
                  CheckMenuItem(hMenu, ID_MN_PROPORTIONAL, MF_BYCOMMAND | MF_UNCHECKED);
                }
                else
                {
                  CheckMenuItem(hMenu, ID_MN_PROPORTIONAL, MF_BYCOMMAND | MF_CHECKED);
                  GetWindowRect(_hwnd, &rect);
                  MoveControls(-(rect.left-rect.right), -(rect.top-rect.bottom));
                }
                return 0;
           case ID_MN_ORGINAL:
                  MoveControls(250, 300);
                return 0;
           case ID_MN_MASTERTEMPO:
                if (GetMenuState(hMenu, ID_MN_MASTERTEMPO, MF_BYCOMMAND) == MFS_CHECKED)
                {
                  CheckMenuItem(hMenu, ID_MN_MASTERTEMPO, MF_BYCOMMAND | MF_UNCHECKED);
                  DSPlayer.UnSetMastertempo();
                  DSPlayer.Mastertempo = FALSE;
                  DSPlayer.Pitch(SendMessage(hSBarPitch, SBM_GETPOS,0,0)-127);
				}
                else
                {
                  CheckMenuItem(hMenu, ID_MN_MASTERTEMPO, MF_BYCOMMAND | MF_CHECKED);
                  DSPlayer.SetMastertempo();
                  DSPlayer.Mastertempo = TRUE;
                  DSPlayer.Pitch(0);
                }
                return 0;
           case ID_MN_PLAY:
                SendMessage(hBtPlay, WM_LBUTTONDOWN, 0,0);
                return 0;
           case ID_MN_CUE:
                SendMessage(hBtCue, WM_LBUTTONDOWN, 0,0);
                return 0;
           case ID_MN_LOAD:
                btLoadClick();
                return 0;
           case ID_BTHEAD:
                if (DSPlayer.loaded == true)
                {
                    if (HeadCue == false)
                    {
                        DSPlayer.Head_Volume(-SendMessage(hSBarHeadVolume, SBM_GETPOS,0,0));
                        SendMessage(hBtHeadCue, BM_SETIMAGE, IMAGE_BITMAP, (LPARAM) hLED_ON);
                        HeadCue = true;
                    }
                    else
                    {
                        DSPlayer.Head_Volume(DSBVOLUME_MIN);
                        SendMessage(hBtHeadCue, BM_SETIMAGE, IMAGE_BITMAP, (LPARAM) hLED_OFF);
                        HeadCue = false;
                    }
                }
                return 0;
           case ID_BTZERO:
                if (DSPlayer.loaded == true)
                {
                  double fPitch;
                  int ndec = 3;
                  char  lpzPitch[7] = "00.00%";
                  SetScrollPos(hSBarPitch, SB_CTL, 127, TRUE);
                  DSPlayer.Pitch(0);
                  fPitch = 0;
                  gcvt(fPitch, ndec, lpzPitch);
                  SendMessage(hSTextPitchPer, WM_SETTEXT,0, (LPARAM) lpzPitch);
                }
                return 0;
           }
           return 0;
      case WM_CHAR:
           if (((TCHAR) wParam == 'L') | ((TCHAR) wParam == 'l')) { btLoadClick();}
           if (((TCHAR) wParam == 'P') | ((TCHAR) wParam == 'p')) {SendMessage(hBtPlay, WM_LBUTTONDOWN, 0,0);}
           if (((TCHAR) wParam == 'C') | ((TCHAR) wParam == 'c')) {SendMessage(hBtCue, WM_LBUTTONDOWN, 0,0);}
           return 0;
      case WM_CREATE:
           SetControls();
           hFirstMenu = LoadMenu(hLibrary, TEXT("PLAYERPOPUP"));
           hMenu      = GetSubMenu(hFirstMenu,0);
           hLED_ON    = LoadBitmap(hLibrary, TEXT("LED_ON"));
           hLED_OFF   = LoadBitmap(hLibrary, TEXT("LED_OFF"));
           pfnOldbtMinusProc = (FARPROC)::SetWindowLong(hBtMinus, GWL_WNDPROC, (LONG)btMinusProc) ;
           pfnOldbtPlusProc  = (FARPROC)::SetWindowLong(hBtPlus, GWL_WNDPROC, (LONG)btPlusProc) ;
           pfnOldbtPlayProc  = (FARPROC)::SetWindowLong(hBtPlay, GWL_WNDPROC, (LONG)btPlayProc) ;
           pfnOldbtCueProc   = (FARPROC)::SetWindowLong(hBtCue, GWL_WNDPROC, (LONG)btCueProc) ;
           SendMessage(hBtHeadCue, BM_SETIMAGE, IMAGE_BITMAP, (LPARAM) hLED_OFF);
           DragAcceptFiles(_hwnd, TRUE);
	   
           return 0;

      case WM_HSCROLL:
           if  (hSBarSeek == (HWND)lParam)
           {
             SCROLLINFO info;
             memset(&info,0,sizeof(SCROLLINFO));
             info.cbSize = sizeof(SCROLLINFO);
             info.fMask = SIF_ALL;
             ::GetScrollInfo(hSBarSeek, SB_CTL, &info);
             SBarSeekScroll((int) LOWORD(wParam), (int)::GetScrollPos(hSBarSeek, SB_CTL), info.nTrackPos);
           }
           return 0;

      case WM_VSCROLL:
           if  (hSBarPitch == (HWND)lParam)
           {
             SBarPitchScroll((int) LOWORD(wParam), (int)GetScrollPos(hSBarPitch, SB_CTL), (int) HIWORD(wParam));
           }
           if  (hSBarVolume == (HWND)lParam)
           {
             SBarVolumeScroll((int) LOWORD(wParam), (int)GetScrollPos(hSBarVolume, SB_CTL), (int) HIWORD(wParam));
           }
           if  (hSBarHeadVolume == (HWND)lParam)
           {
             SBarHeadVolumeScroll((int) LOWORD(wParam), (int)GetScrollPos(hSBarHeadVolume, SB_CTL), (int) HIWORD(wParam));
           }
           return 0;

      case WM_PARENTNOTIFY:
           return 0;


      case WM_DROPFILES:
           OnDropFile((HDROP)wParam);
           return 0;

      case WM_RBUTTONUP:
           point.x = LOWORD (lParam);
           point.y = HIWORD (lParam);
           ClientToScreen(_hwnd, &point);
           TrackPopupMenu(hMenu, TPM_RIGHTBUTTON, point.x, point.y, 0, _hwnd, NULL);
          return 0;

      case WM_DRAWITEM:
           if ((UINT)wParam == ID_BTPLAY)
           {
             DrawBtPlay((LPDRAWITEMSTRUCT) lParam);   
           }
           if ((UINT)wParam == ID_BTCUE)
           {
             DrawBtCue((LPDRAWITEMSTRUCT) lParam);   
           }
           return 0;
      case WM_CTLCOLORSTATIC:
           if ((hSTextTime == (HWND)lParam) | (hSTextPitch == (HWND)lParam) |
			   (hSTextPitchPer == (HWND)lParam) |(hSTextArtist == (HWND)lParam) |
			   (hSTextSong == (HWND)lParam) )
           {
              if (hBrush != NULL)DeleteObject(hBrush); // Delete Old Object
              hBrush = CreateSolidBrush(RGB(0, 0,0));
              SetTextColor((HDC)wParam,RGB(255,255,0));
              SetBkColor((HDC)wParam,RGB(0,0,0));
              return (LRESULT)hBrush;
           }
           if ((hFrameTime == (HWND)lParam)| (hFrameInfo == (HWND)lParam))
           {
              if (hBrush != NULL)DeleteObject(hBrush); // Delete Old Object
              hBrush = CreateSolidBrush(RGB(0, 0,0));
              return (LRESULT)hBrush;
           }
           return 0;

      case WM_SIZE:
           GetWindowRect(_hwnd, &rect);
           MoveControls(-(rect.left-rect.right), -(rect.top-rect.bottom));
           return 0;

	  case WM_HELP:
            WinHelp(_hwnd, HelpPath,HELP_CONTEXT, 20);
            return 0;

	   case WM_TIMER:
		   TimerCount++;
           if (wParam == PressPlus)
		   {
			 if (TimerCount < 31) DSPlayer.Pitch((GetScrollPos(hSBarPitch, SB_CTL)-200)+(TimerCount*10));// -200 Orginal and -100 = +10%
           }
           if (wParam == PressMinus)
		   {
             if (TimerCount < 31) DSPlayer.Pitch((GetScrollPos(hSBarPitch, SB_CTL))-200-(TimerCount*10)); //-200 Orginal and -300 = -10%
           }
           break ;

      case WM_CLOSE:
           i = SendMessage(hSTextStatus, WM_GETTEXTLENGTH,0,0);
           SendMessage(hSTextStatus, WM_GETTEXT,(WPARAM)i+1, (LPARAM) lbStatus);
           if (strcmp(lbStatus, "playing") != 0)
           {
             DestroyWindow(_hwnd);
           }
           return 0;

      case WM_DESTROY:
           DragAcceptFiles(_hwnd, FALSE);
		   
           DeleteObject(hLED_ON);
           DeleteObject(hLED_OFF);
           ::SetWindowLong(hBtMinus,GWL_WNDPROC,(LONG)pfnOldbtMinusProc);
           ::SetWindowLong(hBtPlus,GWL_WNDPROC,(LONG)pfnOldbtPlusProc);
           ::SetWindowLong(hBtPlay,GWL_WNDPROC,(LONG)pfnOldbtPlayProc);
           ::SetWindowLong(hBtCue,GWL_WNDPROC,(LONG)pfnOldbtCueProc);
           DestroyItems();
          return 0;

	  case WM_NCDESTROY:
           delete this;
           return 0;

  }
  return ::DefWindowProc (_hwnd, message, wParam, lParam );
}

VOID PlayerWnd::TimerEvents(UINT , UINT , DWORD , DWORD )
{
   SendMessage(hSBarSeek, SBM_SETPOS,(WPARAM) DSPlayer.Execute(),TRUE);
   DisplayTime();
   if (DSPlayer.iEOFCount > 2)
   {
      DSPlayer.Pause();
      if (SendMessage(hCbAutoCue,BM_GETCHECK, 0,0) == BST_CHECKED)
      { //Set Scrollbar Position
        int iPos = 0;
        SendMessage(hSBarSeek, SBM_SETPOS,(WPARAM) iPos ,TRUE);
      }
      else
      {
        SendMessage(hSBarSeek, SBM_SETPOS, 0 ,TRUE);
      }
      SendMessage(hBtPlay, BM_SETSTATE, FALSE, 0);
      SendMessage(hBtCue, BM_SETSTATE, TRUE, 0);
      DSPlayer.iEOFCount = 0;
      DSPlayer.Seek(SendMessage(hSBarSeek, SBM_GETPOS,0,0));
      SendMessage(hSTextStatus, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) "ended");
      DisplayTime();
      timeKillEvent(idTimer);
      timeEndPeriod(uPeriod);

    }
}

LRESULT PlayerWnd::btMinusEvents(UINT message, WPARAM wParam, LPARAM lParam)
{
  if (DSPlayer.loaded == true)
  {
     switch (message)
     {
       case WM_LBUTTONDOWN:
		    TimerCount = 0;
            SetTimer(_hwnd, PressMinus, 100, NULL);
            return ::CallWindowProc((WNDPROC)pfnOldbtMinusProc, hBtMinus, message, wParam, lParam);
       case WM_LBUTTONUP:
            KillTimer(_hwnd, PressMinus);
            DSPlayer.Pitch(GetScrollPos(hSBarPitch, SB_CTL)-127);
            return ::CallWindowProc((WNDPROC)pfnOldbtMinusProc, hBtMinus, message, wParam, lParam);
     }
   }
   return ::CallWindowProc((WNDPROC)pfnOldbtMinusProc, hBtMinus, message, wParam, lParam);
}

LRESULT PlayerWnd::btPlusEvents(UINT message, WPARAM wParam, LPARAM lParam)
{
  if (DSPlayer.loaded == true)
  {
     switch (message)
     {
       case WM_LBUTTONDOWN:
		    TimerCount = 0;
            SetTimer(_hwnd, PressPlus, 100, NULL);
            return ::CallWindowProc((WNDPROC)pfnOldbtPlusProc, hBtPlus, message, wParam, lParam);
       case WM_LBUTTONUP:
            KillTimer(_hwnd, PressPlus);
            DSPlayer.Pitch(GetScrollPos(hSBarPitch, SB_CTL)-127);
            return ::CallWindowProc((WNDPROC)pfnOldbtPlusProc, hBtPlus, message, wParam, lParam);
     }
  }
  return ::CallWindowProc((WNDPROC)pfnOldbtPlusProc, hBtPlus, message, wParam, lParam);
}

LRESULT PlayerWnd::btPlayEvents(UINT message, WPARAM wParam, LPARAM lParam)
{
  char lbStatus[10]   = "";
  int  i;

  if (DSPlayer.loaded == true)
  {
    switch (message)
    {
      case WM_CREATE:
           return 0;
      case WM_LBUTTONDOWN:
           i = SendMessage(hSTextStatus, WM_GETTEXTLENGTH,0,0);
           SendMessage(hSTextStatus, WM_GETTEXT,(WPARAM)i+1, (LPARAM) lbStatus);
           if (strcmp(lbStatus, "playing") == 0)
           {
             timeKillEvent(idTimer);
             timeEndPeriod(uPeriod);
             DSPlayer.Pause();
             SendMessage(hSTextStatus, WM_SETTEXT,0, (LPARAM) "paused");
             SendMessage(hBtPlay, BM_SETSTATE, FALSE, 0);
           }
           if ((strcmp(lbStatus, "paused") == 0) | (strcmp(lbStatus, "cued") == 0) | (strcmp(lbStatus, "loaded") == 0) | (strcmp(lbStatus, "ended") == 0))
           {
             uPeriod = 50;
             timeBeginPeriod(uPeriod);
             idTimer = timeSetEvent(100, uPeriod, TimeProc, (DWORD)_hwnd, TIME_PERIODIC);
             if (idTimer != NULL)
             {
               DSPlayer.Play();
               SendMessage(hSTextStatus, WM_SETTEXT,0, (LPARAM) "playing");
               SendMessage(hBtPlay, BM_SETSTATE, TRUE, 0);
               SendMessage(hBtCue, BM_SETSTATE, FALSE, 0);
             }
           }
           if (strcmp(lbStatus, "seeking") == 0)
           {
             DSPlayer.CuePause();
             uPeriod = 50;
             timeBeginPeriod(uPeriod);
             idTimer = timeSetEvent(100, uPeriod, TimeProc, (DWORD)_hwnd, TIME_PERIODIC);
             if (idTimer != NULL)
             {
               DSPlayer.Play();
               SendMessage(hSTextStatus, WM_SETTEXT,0, (LPARAM) "playing");
               SendMessage(hBtPlay, BM_SETSTATE, TRUE, 0);
               SendMessage(hBtCue, BM_SETSTATE, FALSE, 0);
             }
           }
           return 0;
    }
 }
 return ::CallWindowProc((WNDPROC)pfnOldbtPlayProc, hBtPlay, message, wParam, lParam);
}

LRESULT PlayerWnd::btCueEvents(UINT message, WPARAM wParam, LPARAM lParam)
{
  char   lbStatus[10]   = "";
  if (DSPlayer.loaded == true)
  {
     switch (message)
     {
       case WM_LBUTTONDOWN:
            int i = SendMessage(hSTextStatus, WM_GETTEXTLENGTH,0,0);
            SendMessage(hSTextStatus, WM_GETTEXT,(WPARAM)i+1, (LPARAM) lbStatus);
            if (strcmp(lbStatus, "cued") != 0)
            {
               if (strcmp(lbStatus, "playing") == 0)
               {
                 timeKillEvent(idTimer);
                 timeEndPeriod(uPeriod);
                 DSPlayer.Pause();
               }

               if (strcmp(lbStatus, "seeking") == 0)
               {
                  DSPlayer.CuePause();
				  DataSet.StartTime = SendMessage(hSBarSeek, SBM_GETPOS,0 ,0);
                  DataBase->WriteStartTime(DataSet.StartTime);
               }
               else
               {
                 SendMessage(hSBarSeek, SBM_SETPOS,(WPARAM) DataSet.StartTime ,TRUE);
               }
               DSPlayer.Seek(SendMessage(hSBarSeek, SBM_GETPOS,0 ,0));
               SendMessage(hSTextStatus, WM_SETTEXT,(WPARAM)i+1, (LPARAM) "cued");
               SendMessage(hBtPlay, BM_SETSTATE, FALSE, 0);
               SendMessage(hBtCue, BM_SETSTATE, TRUE, 0);
               DisplayTime();
            } // if != Cued;
            return 0;
     }
   }
   return ::CallWindowProc((WNDPROC)pfnOldbtCueProc, hBtCue, message, wParam, lParam);
}


//Static Callback WinProc Function

VOID CALLBACK PlayerWnd::TimeProc(UINT uID,UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2)
{
  PlayerWnd * pObject;
  pObject=(PlayerWnd*)GetWindowLong(HWND(dwUser), GWL_USERDATA);
  if (pObject) pObject->TimerEvents(uID, uMsg, dw1, dw2);
  return;
}

LRESULT CALLBACK PlayerWnd::btPlayProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  PlayerWnd * pObject;
  pObject=(PlayerWnd*)GetWindowLong((HWND)GetWindowLong(hwnd,GWL_HWNDPARENT), GWL_USERDATA);

  if (pObject) // sicherheitshalber nachfragen....
    return pObject->btPlayEvents(message,wParam,lParam);
  else
   return(::CallWindowProc((WNDPROC)pObject->pfnOldbtPlayProc, hwnd, message, wParam, lParam));
}

LRESULT CALLBACK PlayerWnd::btCueProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  PlayerWnd * pObject;
  pObject=(PlayerWnd*)GetWindowLong((HWND)GetWindowLong(hwnd,GWL_HWNDPARENT), GWL_USERDATA);

  if (pObject) // sicherheitshalber nachfragen....
    return pObject->btCueEvents(message,wParam,lParam);
  else
   return(::CallWindowProc((WNDPROC)pObject->pfnOldbtCueProc, hwnd, message, wParam, lParam));
}

LRESULT CALLBACK PlayerWnd::btMinusProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  PlayerWnd * pObject;
  pObject=(PlayerWnd*)GetWindowLong((HWND)GetWindowLong(hwnd,GWL_HWNDPARENT), GWL_USERDATA);

  if (pObject) // sicherheitshalber nachfragen....
    return pObject->btMinusEvents(message,wParam,lParam);
  else
   return(::CallWindowProc((WNDPROC)pObject->pfnOldbtMinusProc, hwnd, message, wParam, lParam));
}

LRESULT CALLBACK PlayerWnd::btPlusProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  PlayerWnd * pObject;
  pObject=(PlayerWnd*)GetWindowLong((HWND)GetWindowLong(hwnd,GWL_HWNDPARENT), GWL_USERDATA);

  if (pObject) // sicherheitshalber nachfragen....
    return pObject->btPlusEvents(message,wParam,lParam);
  else
   return(::CallWindowProc((WNDPROC)pObject->pfnOldbtPlusProc, hwnd, message, wParam, lParam));
}

LRESULT CALLBACK PlayerWnd::PlayerWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  PlayerWnd * pObject;

  if (message==WM_CREATE)
  {
    pObject = (PlayerWnd*)(((CREATESTRUCT FAR*)lParam)->lpCreateParams);
    SetWindowLong(hwnd,GWL_USERDATA,(LONG)pObject);

   pObject->_hwnd = hwnd;

  } else { // Alle anderen Messages

   pObject=(PlayerWnd*)GetWindowLong(hwnd,GWL_USERDATA);

  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->Events(message,wParam,lParam);
  else
    return DefWindowProc(hwnd,message,wParam,lParam);
}





/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "mainwindow.h"

MainWnd::MainWnd()
{
  _hwnd             = NULL;
  hActiveListView   = NULL;
  GetCurrentDirectory(MAX_PATH, IniPath); 
  strcat(IniPath, "\\djw.ini"); // Set IniPath
  GetCurrentDirectory(MAX_PATH, DataPath); //Lean Data for Playlistpath
  strcat(DataPath, "\\Playlist"); // Set Playlistpath and create if it is not exist 
  if (GetFileAttributes(DataPath) != FILE_ATTRIBUTE_DIRECTORY){CreateDirectory(DataPath, NULL);}
  GetCurrentDirectory(MAX_PATH, DataPath); 
  strcat(DataPath, "\\Data");// Set Datapath and create if not exists
  if (GetFileAttributes(DataPath) != FILE_ATTRIBUTE_DIRECTORY){CreateDirectory(DataPath, NULL);}

  char szLibrary[9] = "";
  FILE *Test = fopen(IniPath, "r+"); // Check if a djw.ini is existing
  if ( Test == NULL)// If not then do som einitialisations
  {
    strcpy(szLibrary, "leng.dll");
    hLibrary = LoadLibrary(szLibrary);
    WritePrivateProfileString("MainWnd","Language", szLibrary, IniPath);
    LanguageDialog = new DlgLanguage(hLibrary);
	DialogBoxParam(hLibrary, TEXT ("LANGUAGEDLG"), _hwnd,(DLGPROC) LanguageDialog->LanguageDlgProc, (LPARAM)LanguageDialog);
    GetPrivateProfileString("MainWnd","Language","leng.dll", szLibrary,9, IniPath);
    delete LanguageDialog;
    FreeLibrary(hLibrary);
    hLibrary = LoadLibrary(szLibrary);
    DeviceDialog = new DlgDevice(hLibrary);
    DialogBoxParam(hLibrary, TEXT ("DEVICEDLG"), NULL,
                  (DLGPROC) DeviceDialog->DeviceDlgProc, (LPARAM)DeviceDialog);
    delete DeviceDialog;
  }
  else // if an djw.ini is present read the language
  {
     fclose(Test);
     GetPrivateProfileString("MainWnd","Language", "leng.dll", szLibrary, MAX_PATH,IniPath);
     hLibrary = LoadLibrary(szLibrary);
   }

  DataBase = new ndw_DataBase();
  MixerDialog = new DlgMixer(hLibrary);
  LoadString(hLibrary, IDS_HELPPATH, HelpPath,10);
  Test = fopen(HelpPath,"r");
  if (Test == NULL) strcpy(HelpPath, "djw_e.hlp");
  else fclose(Test);
}

MainWnd::~MainWnd()
{
  FreeLibrary(hLibrary);
  delete DataBase;
  int iCount = SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETCOUNT,0,0);
  int i;
  for (i = 0; i<iCount; i++)
  {
      PlayerForm = (PlayerWnd *)(void *)SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETITEMDATA, i, 0);
      delete PlayerForm;
  }
  if (Prim_Head.GetDSBuffer() != NULL) {Prim_Head.Delete();}
  for (i = 0; i < (int)Prim_Aux.size(); i++)
  {
    Prim_Aux[i].Delete();
  }

  delete MixerDialog;
}


void MainWnd::Init()
{
  char  szCount[10];
  char szString[260];
  LoadString(hLibrary,IDS_MAIN_CAPTION, szString, sizeof(szString));

  //Init Database-Dir and create if nessesary
  if (DataBase->ReadFiles() != 0)
  {
    DataBase->ReIndex();
  }
    //Create hidden Mixer Dialog
  MixerDialog->OnCreate(DataBase);

  //Create Listview and fill it
  hActiveListView = CreateListView();
  pfnOldListViewProc    = (FARPROC)::SetWindowLong(hActiveListView, GWL_WNDPROC, (LONG)ListViewProc);
  DataBase->SetActiveIndex("Artist");
  ListView_SetItemCount(hActiveListView, DataBase->ndb_Header.iCount);

  // Get count of Items in Listview and display in Window
  itoa(DataBase->ndb_Header.iCount, szCount, 10);
  strcat(szString, szCount);
  strcat(szString, " Songs");
  SendMessage(_hwnd, WM_SETTEXT,0, (LPARAM) szString);
}

void MainWnd::SetSound()
{
  char       sDevName[128]  = "";
  char       sgDevGuid[128] = "";
  CLSID      gDevGuid;
  OLECHAR    lpsz[128];
  DSBasicObject  Prim_AuxTemp;

  int Mode = GetPrivateProfileInt("Devices","Mode", 0, IniPath);
  int i, iDev;
  int iDevice;
  switch (Mode)
  {
          case 0: // if only One Sound-Device is present
                  // Get DeviceGuid from 1. Device
                  GetPrivateProfileString("Devices","Card_0","", sDevName, 49,IniPath);
                  GetPrivateProfileString("present Devices",sDevName,"",sgDevGuid,49,IniPath);
                  for (i=0; i<128; i++){lpsz[i] = sgDevGuid[i];}
                  CLSIDFromString(lpsz, &gDevGuid);
                  Prim_Aux.push_back(Prim_AuxTemp);
                  Prim_Aux[0].Init(_hwnd, &gDevGuid);
                  break;
          case 1: // if Aux/Head
                  // Get Primary Device
                  GetPrivateProfileString("Devices","Card_0","", sDevName, 49,IniPath);
                  GetPrivateProfileString("present Devices",sDevName,"",sgDevGuid,49,IniPath);
                  for ( i=0; i<128; i++){lpsz[i] = sgDevGuid[i];}
                  CLSIDFromString(lpsz, &gDevGuid);
                  Prim_Aux.push_back(Prim_AuxTemp);
                  Prim_Aux[0].Init(_hwnd, &gDevGuid);
                  // Get Second Device
                  GetPrivateProfileString("Devices","Card_1","", sDevName, 49,IniPath);
                  GetPrivateProfileString("present Devices",sDevName,"",sgDevGuid,49,IniPath);
                  for ( i=0; i<128; i++){lpsz[i] = sgDevGuid[i];}
                  CLSIDFromString(lpsz, &gDevGuid);
                  Prim_Head.Init(_hwnd, &gDevGuid);
                  break;
          case 2: // if Per Player
                  // Get Counts
                  iDevice = GetPrivateProfileInt("Devices","Count", 0, IniPath);
                  // Get Primary Devices
                  for ( iDev = 0; iDev < iDevice; iDev++)
				  {
                    char szCard[10] = "Card_";
                    char szZahl[4] = "";
					itoa(iDev, szZahl, 10);
					strcat(szCard, szZahl);
					GetPrivateProfileString("Devices",szCard,"", sDevName, 49,IniPath);
                    GetPrivateProfileString("present Devices",sDevName,"",sgDevGuid,49,IniPath);
                    for ( i=0; i<128; i++){lpsz[i] = sgDevGuid[i];}
                    CLSIDFromString(lpsz, &gDevGuid);
                    Prim_Aux.push_back(Prim_AuxTemp);
                    Prim_Aux[iDev].Init(_hwnd, &gDevGuid);
                  }
                  break;

   }
 //Open at least two Player
  int iCount = GetPrivateProfileInt("Player", "Count", 2, IniPath);
  for (i = 0; i < iCount ; i++)
  {
    CreateNewPlayer();
  }
  if (GetPrivateProfileInt("Mixer", "Visible",MF_UNCHECKED, IniPath) != MF_UNCHECKED)
  {
    MixerDialog->ShowDialog();
    CheckMenuItem(hMenu, ID_MN_MIXERSECTION, MF_BYCOMMAND | MF_CHECKED);
  }
/*    PrintPreview *Preview;
    Preview = new PrintPreview(0, DataBase);
   char  szCommPort[10]="";
   GetPrivateProfileString("Devices","Comport", "COM1", szCommPort, 10,IniPath);
   MixerDialog->InitRemote(szCommPort);
*/}

void MainWnd::Show()
{
   //Fill WNDCLASS, register and open Window
   memset(&_class,0,sizeof(WNDCLASS));
  _class.style         = CS_HREDRAW | CS_VREDRAW;
  _class.lpfnWndProc   = (WNDPROC) MainWndProc;
  _class.cbClsExtra    = 0;
  _class.cbWndExtra    = sizeof(MainWnd*);
  _class.hInstance     = NULL;
  _class.hIcon         = (HICON)LoadImage(hLibrary, "MAINICON", IMAGE_ICON, 32,32, LR_LOADTRANSPARENT);
  _class.hCursor       = NULL;
  _class.hbrBackground = (HBRUSH) (COLOR_WINDOW);
  _class.lpszClassName = "MainWnd";
  ::RegisterClass(&_class);

 
   hMenu    = LoadMenu(hLibrary, TEXT("MAINMENU"));
   hAccel   = LoadAccelerators(hLibrary, TEXT("MAINACCELERATOR"));
   hFont    = CreateFont(-11, 0, 0, 0, FW_NORMAL, FALSE, FALSE,	FALSE, ANSI_CHARSET,
                           OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                           DEFAULT_PITCH | FF_DONTCARE, "MS Sans Serif" );
  _hwnd     = ::CreateWindowEx(WS_EX_ACCEPTFILES ,"MainWnd","Nick's DJ Workstation - ",WS_OVERLAPPEDWINDOW,
                           GetPrivateProfileInt("MainWnd","Left", 0,IniPath),
                           GetPrivateProfileInt("MainWnd","Top", 300,IniPath),
                           GetPrivateProfileInt("MainWnd","Width", 500,IniPath),
                           GetPrivateProfileInt("MainWnd","Height", 155,IniPath),
                           NULL, hMenu, NULL,(void FAR*)this);
  

  Init(); // Init and Fill Controls
  ::ShowWindow (_hwnd, SW_SHOWNORMAL);
  ::UpdateWindow (_hwnd);
  SetSound();
  // Open Scan-Dialog if Database has Zero Counts
  if (DataBase->ndb_Header.iCount < 1) SendMessage(_hwnd, WM_COMMAND, MAKELONG(ID_MN_CHECK, 0),0);
}


void MainWnd::SetControls()
{
   //Create Controls in Main-Window

   hEditArtist  = CreateWindowEx(WS_EX_CLIENTEDGE | WS_EX_NOPARENTNOTIFY, TEXT("EDIT"),"", ES_AUTOHSCROLL | ES_LEFT | WS_TABSTOP | WS_CHILD | WS_VISIBLE,
                               0, 0, 180, 21, _hwnd, (HMENU)ID_ED_ARTIST,NULL,NULL);
   hEditSong    = CreateWindowEx(WS_EX_CLIENTEDGE | WS_EX_NOPARENTNOTIFY, TEXT("EDIT"),"", ES_AUTOHSCROLL | ES_LEFT | WS_TABSTOP | WS_CHILD | WS_VISIBLE,
                               181, 0, 180, 21, _hwnd, (HMENU)ID_ED_SONG,NULL,NULL);
   hEditGenre   = CreateWindowEx(WS_EX_CLIENTEDGE | WS_EX_NOPARENTNOTIFY, TEXT("EDIT"),"", ES_AUTOHSCROLL | ES_LEFT | WS_TABSTOP | WS_CHILD | WS_VISIBLE,
                               362, 0, 71, 21, _hwnd, (HMENU)ID_ED_GENRE,NULL,NULL);
   hEditYear    = CreateWindowEx(WS_EX_CLIENTEDGE |WS_EX_NOPARENTNOTIFY, TEXT("EDIT"),"", ES_AUTOHSCROLL | ES_LEFT | WS_TABSTOP | WS_CHILD | WS_VISIBLE,
                               434, 0, 33, 21, _hwnd,(HMENU)ID_ED_YEAR, NULL,NULL);
   
   SendMessage(hEditArtist,EM_SETLIMITTEXT, 29,0);
   SendMessage(hEditSong,EM_SETLIMITTEXT, 29,0);
   SendMessage(hEditGenre,EM_SETLIMITTEXT, 9,0);
   SendMessage(hEditYear,EM_SETLIMITTEXT,  4,0);
   
   SendMessage(hEditArtist, WM_SETFONT, (WPARAM)hFont, TRUE);
   SendMessage(hEditSong, WM_SETFONT, (WPARAM)hFont, TRUE);
   SendMessage(hEditGenre, WM_SETFONT, (WPARAM)hFont, TRUE);
   SendMessage(hEditYear, WM_SETFONT, (WPARAM)hFont, TRUE);
   return;
}


HWND MainWnd::CreateListView()
{
   // Creates the Listview with Colums and Set the Fonts
   HWND     hListView = NULL;

   //InitCommonControls();
   hListView    = CreateWindowEx(WS_EX_CLIENTEDGE | WS_EX_NOPARENTNOTIFY , WC_LISTVIEW,"", LVS_REPORT | LVS_NOSORTHEADER | LVS_SINGLESEL | WS_VISIBLE | WS_TABSTOP | LVS_OWNERDATA | LVS_SHOWSELALWAYS |WS_CHILD,
                               0, 22, 528, 327, _hwnd, NULL,NULL,NULL);
   SendMessage(hListView, LVM_SETEXTENDEDLISTVIEWSTYLE, LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);
   char pzsBuffer[260];

   SendMessage(hListView, WM_SETFONT, (WPARAM)hFont, TRUE);

   LV_COLUMN lvc;

   LoadString(hLibrary,IDS_ARTIST, pzsBuffer, sizeof(pzsBuffer));
   lvc.mask     = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
   lvc.fmt      = LVCFMT_LEFT;
   lvc.cx       = 180;
   lvc.pszText  = pzsBuffer;
   lvc.iSubItem = 0;
   SendMessage(hListView, LVM_INSERTCOLUMN, 0, (LPARAM)&lvc);

   LoadString(hLibrary,IDS_SONGNAME, pzsBuffer, sizeof(pzsBuffer));
   lvc.cx       = 181;
   lvc.pszText  = pzsBuffer;
   lvc.iSubItem = 1;
   SendMessage(hListView, LVM_INSERTCOLUMN, 1, (LPARAM)&lvc);

   LoadString(hLibrary,IDS_GENRE, pzsBuffer, sizeof(pzsBuffer));
   lvc.cx       = 72;
   lvc.pszText  = pzsBuffer;
   lvc.iSubItem = 2;
   SendMessage(hListView, LVM_INSERTCOLUMN, 2, (LPARAM)&lvc);

   LoadString(hLibrary,IDS_YEAR, pzsBuffer, sizeof(pzsBuffer));
   lvc.cx       = 36;
   lvc.pszText  = pzsBuffer;;
   lvc.iSubItem = 3;
   SendMessage(hListView, LVM_INSERTCOLUMN, 3, (LPARAM)&lvc);
  return hListView;
}

void MainWnd::AutoLoad()
{

 if (DataBase->ndb_Header.iCount > 0)
 {
   if (MixerDialog->WinPlayList->_hwnd == NULL)
   {
      MixerDialog->LoadPlayer();
   }
   else
   {
      int i = DataBase->GetActualDataPos();
	  MixerDialog->WinPlayList->AddStringToListBox(DataBase->vDataBase[i].szArtist, DataBase->vDataBase[i].szSongname, DataBase->vDataBase[i].szPath);
   }
 }
 return;
}

void MainWnd::CreateNewPlayer()
{
  int         ixPos;
  int         iyPos;
  char        Zahl[4]="";
  char        chPlayer[13] = "Player ";
  char        chGetTextLeft[12] = "";
  char        chGetTextRight[12] = "";
  int iDevice = GetPrivateProfileInt("Devices","Count", 0, IniPath);
  if (iDevice > 0) // if at least one Device is present
  {
     // Investigate for correct Player-Name
     int iCount  = SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETCOUNT, 0, 0);
     if (iCount > 0)
     {
       for (int i = 0; i < iCount+2; i++) //Check all CB-Items for existing Names
       {
         if (i < 10)// Add 0 if Playernumber < 10
         {
           strcpy(chPlayer, "Player ");
           strcat(chPlayer, "0");
           strcat(chPlayer, itoa(i, Zahl, 10));
         }
         else
         {
           strcpy(chPlayer, "Player ");
           strcat(chPlayer, itoa(i, Zahl, 10));
         }
         //Check if Name exist
         if (SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_FINDSTRINGEXACT, 0, (LPARAM)chPlayer)== CB_ERR)
         {break;} // If Item non-exists break and get so the checked Playername
       }
     }
     else
     {
      strcat(chPlayer, "0");
      strcat(chPlayer, itoa(iCount, Zahl, 10));
     }
     // For Position
     if (iCount < 2)
     {
       ixPos   = GetPrivateProfileInt(chPlayer,"Left", SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETCOUNT, 0, 0)*250, IniPath);
       iyPos   = GetPrivateProfileInt(chPlayer,"Top", 0, IniPath);
     }
     else
     {
       ixPos   = GetPrivateProfileInt(chPlayer,"Left", SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETCOUNT, 0, 0)*10, IniPath);
       iyPos   = GetPrivateProfileInt(chPlayer,"Top", SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETCOUNT, 0, 0)*10, IniPath);
     }
   int Mode = GetPrivateProfileInt("Devices","Mode", 0, IniPath);
   switch (Mode)
   {
            case 0: // if only One Sound-Device is present
                   if (Prim_Aux[0].GetDSBuffer() != NULL)
                   {
                       PlayerForm = new PlayerWnd(hLibrary);
                       PlayerForm->Init(MixerDialog->GetDlgHandle(), DataBase);
                       if (PlayerForm->Show(_hwnd, (HINSTANCE)GetWindowLong(_hwnd,GWL_HINSTANCE),
                                                     Prim_Aux[0].GetDSBuffer(), NULL, ixPos, iyPos,
                                                     GetPrivateProfileInt(chPlayer,"Width", 250, IniPath),
                                                     GetPrivateProfileInt(chPlayer,"Height", 300, IniPath),
                                                     chPlayer,
                                                     GetPrivateProfileInt(chPlayer,"AutoCue", FALSE, IniPath),
                                                     GetPrivateProfileInt(chPlayer,"elapse", TRUE, IniPath),
							                         GetPrivateProfileInt(chPlayer,"Mastertempo", TRUE, IniPath)) != FALSE)
                       {

                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) chPlayer);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) chPlayer);
                         iCount = SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETCOUNT, 0, 0);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_SETITEMDATA, iCount-1, (LPARAM) (DWORD)PlayerForm);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, CB_SETITEMDATA, iCount-1, (LPARAM)(DWORD)PlayerForm);

                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetTextLeft);
                         if (strcmp(chGetTextLeft, "") == 0)
                         {
                           SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) chPlayer);
                           MixerDialog->SetPlayerLeft(PlayerForm);
                         }
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetTextLeft);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetTextRight);
                         if ((strcmp(chGetTextRight, "") == 0) & (strcmp(chGetTextLeft, chPlayer) != 0))
                         {
                           SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) chPlayer);
                           MixerDialog->SetPlayerRight(PlayerForm);
                         }
                       }
                       else
                       {
                         delete PlayerForm;
                       }
                       
                   }
                   break;
          case 1: // Modus Aux/Head
                   if ((Prim_Aux[0].GetDSBuffer() != NULL) & (Prim_Head.GetDSBuffer != NULL))
                   {
                     PlayerForm = new PlayerWnd(hLibrary);
                     PlayerForm->Init(MixerDialog->GetDlgHandle(), DataBase);
                     PlayerForm->Show(_hwnd, (HINSTANCE)GetWindowLong(_hwnd,GWL_HINSTANCE),
                                                   Prim_Aux[0].GetDSBuffer(), Prim_Head.GetDSBuffer(), ixPos, iyPos,
                                                   GetPrivateProfileInt(chPlayer,"Width", 250, IniPath),
                                                   GetPrivateProfileInt(chPlayer,"Height", 300, IniPath),
                                                   chPlayer,
                                                   GetPrivateProfileInt(chPlayer,"AutoCue", FALSE, IniPath),
                                                   GetPrivateProfileInt(chPlayer,"elapse", TRUE, IniPath),
                                                   GetPrivateProfileInt(chPlayer,"Mastertempo", TRUE, IniPath));

                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) chPlayer);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) chPlayer);
                         iCount = SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETCOUNT, 0, 0);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_SETITEMDATA, iCount-1, (LPARAM) (DWORD)PlayerForm);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, CB_SETITEMDATA, iCount-1, (LPARAM)(DWORD)PlayerForm);

                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetTextLeft);
                         if (strcmp(chGetTextLeft, "") == 0)
                         {
                           SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) chPlayer);
                           MixerDialog->SetPlayerLeft(PlayerForm);
                         }
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetTextLeft);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetTextRight);
                         if ((strcmp(chGetTextRight, "") == 0) & (strcmp(chGetTextLeft, chPlayer) != 0))
                         {
                           SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) chPlayer);
                           MixerDialog->SetPlayerRight(PlayerForm);
                         }
                   }
                   break;


          case 2: // Wenn mehrere Soundkarten vorhanden Modus pro Player
                  //Check how many Player are Open
                  if (iCount < iDevice)
                  {
                    char *szZahl	= strchr(chPlayer, ' ');
                    int iPlayerNumber = atoi(szZahl);
					PlayerForm = new PlayerWnd(hLibrary);
                    PlayerForm->Init(MixerDialog->GetDlgHandle(), DataBase);
                    PlayerForm->Show(_hwnd, (HINSTANCE)GetWindowLong(_hwnd,GWL_HINSTANCE),
                                                   Prim_Aux[iPlayerNumber].GetDSBuffer(), NULL, ixPos, iyPos,
                                                   GetPrivateProfileInt(chPlayer,"Width", 250, IniPath),
                                                   GetPrivateProfileInt(chPlayer,"Height", 300, IniPath),
                                                   chPlayer,
                                                   GetPrivateProfileInt(chPlayer,"AutoCue", FALSE, IniPath),
                                                   GetPrivateProfileInt(chPlayer,"elapse", TRUE, IniPath),
                                                   GetPrivateProfileInt(chPlayer,"Mastertempo", TRUE, IniPath));

                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) chPlayer);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) chPlayer);
                         iCount = SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETCOUNT, 0, 0);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_SETITEMDATA, iCount-1, (LPARAM) (DWORD)PlayerForm);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, CB_SETITEMDATA, iCount-1, (LPARAM)(DWORD)PlayerForm);

                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetTextLeft);
                         if (strcmp(chGetTextLeft, "") == 0)
                         {
                           SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) chPlayer);
                           MixerDialog->SetPlayerLeft(PlayerForm);
                         }
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetTextLeft);
                         SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, WM_GETTEXT, 12, (LPARAM)(LPCTSTR) chGetTextRight);
                         if ((strcmp(chGetTextRight, "") == 0) & (strcmp(chGetTextLeft, chPlayer) != 0))
                         {
                           SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERRIGHT, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) chPlayer);
                           MixerDialog->SetPlayerRight(PlayerForm);
                         }
                  }
                  break;
         }
  } // iCount > 0 means if a sounddevice is present
}

void MainWnd::PrinterSetup()
{
   PRINTDLG pd ;

   pd.lStructSize         = sizeof (PRINTDLG) ;
   pd.hwndOwner           = _hwnd ;
   pd.hDevMode            = NULL ;
   pd.hDevNames           = NULL ;
   pd.hDC                 = NULL ;
   pd.Flags               = PD_ALLPAGES | PD_COLLATE |
                            PD_RETURNDC | PD_NOSELECTION ;
   pd.nFromPage           = 0 ;
   pd.nToPage             = 0 ;
   pd.nMinPage            = 0 ;
   pd.nMaxPage            = 0 ;
   pd.nCopies             = 1 ;
   pd.hInstance           = NULL ;
   pd.lCustData           = 0L ;
   pd.lpfnPrintHook       = NULL ;
   pd.lpfnSetupHook       = NULL ;
   pd.lpPrintTemplateName = NULL ;
   pd.lpSetupTemplateName = NULL ;
   pd.hPrintTemplate      = NULL ;
   pd.hSetupTemplate      = NULL ;
   PrintDlg (&pd);
}


void MainWnd::LoadPlayList()
{
  OPENFILENAME ofn ;
  char pstrFileName[260] = "";
  char szFilter[]            = "DJWorkstation Playlist (*.dwp)\0*.dwp\0" \
                               "Winamp Playlist (*.m3u)\0*.m3u\0";
  char path[260]         ;

   GetCurrentDirectory(MAX_PATH, path);
   strcat(path, "\\PlayList");

   ofn.lStructSize       = sizeof (OPENFILENAME) ;
   ofn.hwndOwner         = _hwnd;
   ofn.hInstance         = NULL ;
   ofn.lpstrFilter       = szFilter ;
   ofn.lpstrCustomFilter = NULL ;
   ofn.nMaxCustFilter    = 0 ;
   ofn.nFilterIndex      = 0 ;
   ofn.lpstrFile         = NULL ;          // Bei �ffnen bzw. Schlie�en gesetzt
   ofn.nMaxFile          = MAX_PATH ;
   ofn.lpstrFileTitle    = NULL ;          // Bei �ffnen bzw. Schlie�en gesetzt
   ofn.nMaxFileTitle     = MAX_PATH ;
   ofn.lpstrInitialDir   = path ;
   ofn.lpstrTitle        = NULL ;
   ofn.Flags             = 0 ;             // Bei �ffnen bzw. Schlie�en gesetzt
   ofn.nFileOffset       = 0 ;
   ofn.nFileExtension    = 0 ;
   ofn.lpstrDefExt       = TEXT ("dwp") ;
   ofn.lCustData         = 0L;
   ofn.lpfnHook          = NULL;
   ofn.lpTemplateName    = NULL;
   ofn.lpstrFile         = pstrFileName;
   ofn.lpstrFileTitle    = NULL;
   ofn.Flags             = OFN_HIDEREADONLY | OFN_CREATEPROMPT ;

   FILE *FileHandle;
   ndw_DataSet DataSet;
  if (GetOpenFileName(&ofn))
  {
    char* ext;
    char drive[3]        = "";
    char lpzString[260]  = "";
    char lpzString1[260] = "";
    strncpy (drive, pstrFileName, 2);

    ext = strrchr(pstrFileName, '.');
    DataBase->SetActiveIndex("Path");

    if (strcmp(ext, ".dwp") == 0)
    {
       FileHandle = fopen(pstrFileName, "rt");
       fseek(FileHandle, 0, SEEK_SET);
       if (MixerDialog->WinPlayList->_hwnd == NULL){MixerDialog->WinPlayList->Show();}
       MixerDialog->WinPlayList->ClearListBox();
       while (fgets(lpzString, 255,FileHandle) != NULL)
       {
		 lpzString[strlen(lpzString)-1] = '\0'; // wegen \n Zeilenvorschub
	     DataBase->FindPath(lpzString);
         int i = DataBase->GetActualDataPos();
         MixerDialog->WinPlayList->AddStringToListBox(DataBase->vDataBase[i].szArtist, DataBase->vDataBase[i].szSongname, DataBase->vDataBase[i].szPath);
       }
       fclose(FileHandle);
    } //end if substring *.dwp

    if (strcmp(ext, ".m3u") == 0)
    {
       FileHandle = fopen(pstrFileName, "rt");
       fseek(FileHandle, 0, SEEK_SET);
       if (MixerDialog->WinPlayList->_hwnd == NULL){MixerDialog->WinPlayList->Show();}
       MixerDialog->WinPlayList->ClearListBox();
       DataBase->SetActiveIndex("Path");
       while (fgets(lpzString, 255,FileHandle) != NULL)
       {
          if (lpzString[0] != '#') // falls # am Anfang
          {
             if (lpzString[0] == '\\') // Workaround fuer Winamp-Bug falls / am Anfang
             {
                strcpy(lpzString1,lpzString);
                strcpy(lpzString,drive);
                strcat(lpzString,lpzString1);
             }
            strcpy(lpzString1,lpzString);
            lpzString[strlen(lpzString) -1] = '\0'; // um Zeilenvorschub \n herauszubekommen
            DataBase->FindPath(lpzString);
            int i = DataBase->GetActualDataPos();
            MixerDialog->WinPlayList->AddStringToListBox(DataBase->vDataBase[i].szArtist, DataBase->vDataBase[i].szSongname, DataBase->vDataBase[i].szPath);
          }
        }
       fclose(FileHandle);
    } //end if ext *.m3u
  } //if Opendialog
}



void MainWnd::SavePositions()
{  //saves Positions for Views in djw.ini

  RECT rect;
  char string[5];

  // Save MainWindow-Position
  GetWindowRect(_hwnd, &rect);
  itoa(rect.left, string, 10);
  WritePrivateProfileString("MainWnd","Left", string,IniPath);
  itoa(rect.top, string, 10);
  WritePrivateProfileString("MainWnd","Top", string,IniPath);
  itoa(rect.right-rect.left, string, 10);
  WritePrivateProfileString("MainWnd","Width", string,IniPath);
  itoa(rect.bottom-rect.top, string, 10);
  WritePrivateProfileString("MainWnd","Height", string,IniPath);

  // Save Mixer-Position
  GetWindowRect(MixerDialog->GetDlgHandle(), &rect);
  itoa(rect.left, string, 10);
  WritePrivateProfileString("Mixer","Left", string,IniPath);
  itoa(rect.top, string, 10);
  WritePrivateProfileString("Mixer","Top", string,IniPath);
  itoa(GetMenuState(hMenu, ID_MN_MIXERSECTION, MF_BYCOMMAND), string, 10);
  WritePrivateProfileString("Mixer","Visible", string, IniPath);
  itoa(LOWORD(SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_UD_FADETIME, UDM_GETPOS, 0, 0)), string, 10);
  WritePrivateProfileString("Mixer","Fadetime", string, IniPath);
  itoa(LOWORD(SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_UD_PLAYSTART, UDM_GETPOS, 0, 0)), string, 10);
  WritePrivateProfileString("Mixer","Playstart", string, IniPath);

  // Save Playlist-Position
  if (MixerDialog->WinPlayList->_hwnd != NULL)
  {
    GetWindowRect(MixerDialog->WinPlayList->_hwnd, &rect);
    itoa(rect.left, string, 10);
    WritePrivateProfileString("Playlist","Left", string,IniPath);
    itoa(rect.top, string, 10);
    WritePrivateProfileString("Playlist","Top", string,IniPath);
    itoa(rect.right-rect.left, string, 10);
    WritePrivateProfileString("Playlist","Width", string,IniPath);
    itoa(rect.bottom-rect.top, string, 10);
    WritePrivateProfileString("Playlist","Height", string,IniPath);
  }

  //Go thru all Player and Save their Positions
  int i;
  for ( i = 0; i < SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETCOUNT, 0, 0); i++)
  {
    PlayerForm = (PlayerWnd *) SendDlgItemMessage(MixerDialog->GetDlgHandle(), ID_CB_PLAYERLEFT, CB_GETITEMDATA, i, 0);
    GetWindowRect(PlayerForm->GetWndHandle(), &rect);

    itoa(rect.left, string, 10);
    WritePrivateProfileString(PlayerForm->szClassCaption, "Left", string,IniPath);
    itoa(rect.top, string, 10);
    WritePrivateProfileString(PlayerForm->szClassCaption, "Top", string,IniPath);
    itoa(rect.right-rect.left, string, 10);
    WritePrivateProfileString(PlayerForm->szClassCaption, "Width", string,IniPath);
    itoa(rect.bottom-rect.top, string, 10);
    WritePrivateProfileString(PlayerForm->szClassCaption, "Height", string,IniPath);
    itoa(PlayerForm->elapse, string, 10);
    WritePrivateProfileString(PlayerForm->szClassCaption, "elapse", string, IniPath);
    itoa(SendMessage(PlayerForm->hCbAutoCue, BM_GETCHECK, 0,0), string, 10);
    WritePrivateProfileString(PlayerForm->szClassCaption, "AutoCue",  string, IniPath);
    itoa(PlayerForm->DSPlayer.Mastertempo, string, 10);
    WritePrivateProfileString(PlayerForm->szClassCaption, "Mastertempo",  string, IniPath);
  }
  itoa(i, string, 10);
  WritePrivateProfileString("Player","Count", string, IniPath); //Speichere PlayerAnzahl

}

LRESULT MainWnd::ListViewNotify(LPARAM lParam)
{ // Fills the Listview
  LPNMHDR  lpnmh = (LPNMHDR) lParam;
  LV_DISPINFO *lpdi = (LV_DISPINFO *)lParam;

  if (lpnmh->code ==LVN_GETDISPINFO)
  {
    if(lpdi->item.mask & LVIF_TEXT)
    {
      int i = DataBase->GetFromActiveIndex(lpdi->item.iItem);
      switch (lpdi->item.iSubItem)
      {
             case 0:
                    strcpy(lpdi->item.pszText, DataBase->vDataBase[i].szArtist);
                    break;
             case 1:
                    strcpy(lpdi->item.pszText, DataBase->vDataBase[i].szSongname);
                    break;
             case 2:
                    strcpy(lpdi->item.pszText, DataBase->vDataBase[i].szGenre);
                    break;
             case 3:
                    strcpy(lpdi->item.pszText, DataBase->vDataBase[i].szYear);
                    break;
      }
    }
  }
  return 0;
}

LRESULT MainWnd::ListViewEvents(UINT message, WPARAM wParam, LPARAM lParam)
{
  LV_HITTESTINFO lv_hit;
  int           iHeight;
  switch (message)
  {
    case WM_LBUTTONDBLCLK:
         AutoLoad();
         return 0;
    case WM_LBUTTONDOWN:
         lv_hit.pt.x = LOWORD(lParam);
         lv_hit.pt.y = HIWORD(lParam);   //get Mouse Position
         lv_hit.flags = LVHT_BELOW;
         ListView_HitTest(hActiveListView,&lv_hit); // Check if there is a Item under Mouse
         ListView_SetItemState (hActiveListView, lv_hit.iItem, LVIS_FOCUSED | LVIS_SELECTED,
                                 LVIS_FOCUSED | LVIS_SELECTED); // Highlight it
         ListView_EnsureVisible(hActiveListView, lv_hit.iItem, TRUE);
         DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(lv_hit.iItem));
         iListViewPos = lv_hit.iItem; // Set Current ListviewPosition
         return 0;
    case WM_LBUTTONUP:
         SetFocus(hActiveListView);
         return 0;
    case WM_KEYDOWN:
         switch(wParam)
         {
           case VK_UP:
                if (iListViewPos > 0){ iListViewPos--;}
                ListView_SetItemState (hActiveListView, iListViewPos, LVIS_FOCUSED | LVIS_SELECTED,
                                       LVIS_FOCUSED | LVIS_SELECTED);
                ListView_EnsureVisible(hActiveListView, iListViewPos, TRUE);
                DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(iListViewPos));
                return 0;
           case VK_DOWN:
                if (iListViewPos < ListView_GetItemCount(hActiveListView)-1)
                {
                  iListViewPos++;
                  ListView_SetItemState (hActiveListView, iListViewPos, LVIS_FOCUSED | LVIS_SELECTED,
                                       LVIS_FOCUSED | LVIS_SELECTED);
                  ListView_EnsureVisible(hActiveListView, iListViewPos, TRUE);
                  DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(iListViewPos));
                }
                return 0;
           case VK_NEXT:
                iHeight = ListView_GetCountPerPage(hActiveListView);
                if (iListViewPos+iHeight < ListView_GetItemCount(hActiveListView))
                {
                  iListViewPos = iListViewPos+iHeight;
                }
                else
                {
                  iListViewPos = ListView_GetItemCount(hActiveListView)-1;
                }
                ListView_SetItemState (hActiveListView, iListViewPos, LVIS_FOCUSED | LVIS_SELECTED,
                                     LVIS_FOCUSED | LVIS_SELECTED);
                ListView_EnsureVisible(hActiveListView, iListViewPos, TRUE);
                DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(iListViewPos));
                return 0;
           case VK_PRIOR:
                iHeight = ListView_GetCountPerPage(hActiveListView);
                if (iListViewPos-iHeight > 0)
                {
                  iListViewPos = iListViewPos-iHeight;
                }
                else
                {
                  iListViewPos = 0;
                }
                ListView_SetItemState (hActiveListView, iListViewPos, LVIS_FOCUSED | LVIS_SELECTED,
                                     LVIS_FOCUSED | LVIS_SELECTED);
                ListView_EnsureVisible(hActiveListView, iListViewPos, TRUE);
                DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(iListViewPos));
                return 0;
           case VK_HOME:
                iListViewPos = 0;
                ListView_SetItemState (hActiveListView, iListViewPos, LVIS_FOCUSED | LVIS_SELECTED,
                                     LVIS_FOCUSED | LVIS_SELECTED);
                ListView_EnsureVisible(hActiveListView, iListViewPos, TRUE);
                DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(iListViewPos));
                return 0;
           case VK_END:
                iListViewPos = ListView_GetItemCount(hActiveListView)-1;
                ListView_SetItemState (hActiveListView, iListViewPos, LVIS_FOCUSED | LVIS_SELECTED,
                                     LVIS_FOCUSED | LVIS_SELECTED);
                ListView_EnsureVisible(hActiveListView, iListViewPos, TRUE);
                DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(iListViewPos));
                return 0;
         }
         return 0;
  }
 return ::CallWindowProc((WNDPROC)pfnOldListViewProc, hActiveListView, message, wParam, lParam);
}

LRESULT MainWnd::Events(UINT message, WPARAM wParam, LPARAM lParam)
{
  RECT  rect;
  char  EditText[255];
  LPNMHDR pnmh;
  char  szCount[10];
  char  szCommPort[10]="";
  char  szString[50] = "Nick's DJ-Workstation - ";

  switch (message)
  {
      case WM_COMMAND:
           switch (LOWORD(wParam))
           {
           case ID_ACCEL_ENTER:
                AutoLoad();
                return 0;
           case ID_ED_ARTIST:
                if (HIWORD(wParam) == EN_SETFOCUS)
                 {
                   DataBase->SetActiveIndex("Artist");
                   ListView_SetItemCount(hActiveListView, DataBase->ndb_Header.iCount);
                 }
                 if (HIWORD(wParam) == EN_CHANGE)
                 {
                    SendMessage(hEditArtist, WM_GETTEXT, 255, (LPARAM) EditText);
                    int y = DataBase->FindArtist(EditText);
                    ListView_SetItemState (hActiveListView, y, LVIS_FOCUSED | LVIS_SELECTED,
                                           LVIS_FOCUSED | LVIS_SELECTED);
                    ListView_EnsureVisible(hActiveListView, y,TRUE);
                    ListView_GetItemRect(hActiveListView, y, &rect, LVIR_BOUNDS);
					int iLVC = (rect.bottom-rect.top) * ListView_GetCountPerPage(hActiveListView);
					if (rect.bottom > iLVC)
					{
					  ListView_Scroll(hActiveListView,0, (iLVC-10));
                    }
				 }
                return 0;
           case ID_ED_SONG:
                 if (HIWORD(wParam) == EN_SETFOCUS)
                 {
                   DataBase->SetActiveIndex("Songname");
                   ListView_SetItemCount(hActiveListView, DataBase->ndb_Header.iCount);
                 }
                 if (HIWORD(wParam) == EN_CHANGE)
                 {
                    SendMessage(hEditSong, WM_GETTEXT, 255, (LPARAM) EditText);
                    int y = DataBase->FindSongname(EditText);
                    ListView_SetItemState (hActiveListView, y, LVIS_FOCUSED | LVIS_SELECTED,
                                           LVIS_FOCUSED | LVIS_SELECTED);
                    ListView_EnsureVisible(hActiveListView, y,TRUE);
                    ListView_GetItemRect(hActiveListView, y, &rect, LVIR_BOUNDS);
					int iLVC = (rect.bottom-rect.top) * ListView_GetCountPerPage(hActiveListView);
					if (rect.bottom > iLVC)
					{
					  ListView_Scroll(hActiveListView,0, (iLVC-10));
                    }
                 }
                return 0;
           case ID_ED_GENRE:
                 if (HIWORD(wParam) == EN_SETFOCUS)
                 {
                   DataBase->SetActiveIndex("Genre");
                   ListView_SetItemCount(hActiveListView, DataBase->ndb_Header.iCount);
                 }
                 if (HIWORD(wParam) == EN_CHANGE)
                 {
                    SendMessage(hEditGenre, WM_GETTEXT, 255, (LPARAM) EditText);
                    int y = DataBase->FindGenre(EditText);
                    ListView_SetItemState (hActiveListView, y, LVIS_FOCUSED | LVIS_SELECTED,
                                           LVIS_FOCUSED | LVIS_SELECTED);
                    ListView_EnsureVisible(hActiveListView, y,TRUE);
                    ListView_GetItemRect(hActiveListView, y, &rect, LVIR_BOUNDS);
					int iLVC = (rect.bottom-rect.top) * ListView_GetCountPerPage(hActiveListView);
					if (rect.bottom > iLVC)
					{
					  ListView_Scroll(hActiveListView,0, (iLVC-10));
                    }
                 }
                return 0;
           case ID_ED_YEAR:
                 if (HIWORD(wParam) == EN_SETFOCUS)
                 {
                   DataBase->SetActiveIndex("Year");
                   ListView_SetItemCount(hActiveListView, DataBase->ndb_Header.iCount);
                 }
                 if (HIWORD(wParam) == EN_CHANGE)
                 {
                    SendMessage(hEditYear, WM_GETTEXT, 255, (LPARAM) EditText);
                    int y = DataBase->FindYear(EditText);
                    ListView_SetItemState (hActiveListView, y, LVIS_FOCUSED | LVIS_SELECTED,
                                           LVIS_FOCUSED | LVIS_SELECTED);
                    ListView_EnsureVisible(hActiveListView, y,TRUE);
                    ListView_GetItemRect(hActiveListView, y, &rect, LVIR_BOUNDS);
					int iLVC = (rect.bottom-rect.top) * ListView_GetCountPerPage(hActiveListView);
					if (rect.bottom > iLVC)
					{
					  ListView_Scroll(hActiveListView,0, (iLVC-10));
                    }
                 }
               return 0;
           case ID_MN_NEWPLAYER:
                CreateNewPlayer();
                return 0;
           case ID_MN_CHECK:
                ScanDialog = new DlgScan(DataBase, hLibrary);
                DialogBoxParam(hLibrary, TEXT ("SCANDLG"), _hwnd,
                              (DLGPROC) ScanDialog->ScanDlgProc, (LPARAM)ScanDialog);
                delete ScanDialog;
                DataBase->SetActiveIndex("Artist");
                ListView_SetItemCount(hActiveListView, DataBase->ndb_Header.iCount);
                itoa(DataBase->ndb_Header.iCount, szCount, 10);
                strcat(szString, szCount);
                strcat(szString, " Songs");
                SendMessage(_hwnd, WM_SETTEXT,0, (LPARAM) szString);
                return 0;

           case ID_MN_ID3EDITOR:
                IdEditor = new IdEdit(DataBase, hLibrary);
                IdEditor->Show(_hwnd, (HINSTANCE)GetWindowLong(_hwnd,GWL_HINSTANCE));
                return 0;
           case ID_MN_PRINT:
/*                PrintDialog = new DlgPrint(DataBase);
                DialogBoxParam(hLibrary, TEXT ("PRINTDLG"), _hwnd,
                              (DLGPROC) PrintDialog->PrintDlgProc, (LPARAM)PrintDialog);
                delete PrintDialog;
*/                return 0;
           case ID_MN_PRINTERSETUP:
                PrinterSetup();
                return 0;
           case ID_MN_EXIT:
                SendMessage(_hwnd, WM_CLOSE, 0,0);
                return 0;

           case ID_MN_PLNEW:
                if (MixerDialog->WinPlayList->_hwnd == NULL){MixerDialog->WinPlayList->Show();}
                return 0;
           case ID_MN_PLLOAD:
                LoadPlayList();
                return 0;

           case ID_MN_DEVICES:
                DeviceDialog = new DlgDevice(hLibrary);
                if (DialogBoxParam(hLibrary, TEXT ("DEVICEDLG"), _hwnd,
					(DLGPROC) DeviceDialog->DeviceDlgProc, (LPARAM)DeviceDialog) == 1)
				{
                  LoadString(hLibrary,IDS_RESTART, EditText, sizeof(EditText));
                  LoadString(hLibrary,IDS_WARNING, szString, sizeof(szString));
                  MessageBox(_hwnd,(LPCTSTR) EditText, (LPCTSTR) szString, MB_ICONWARNING );
				}
                delete DeviceDialog;
                return 0;
           case ID_MN_LANGUAGE:
                LanguageDialog = new DlgLanguage(hLibrary);
				if (DialogBoxParam(hLibrary, TEXT ("LANGUAGEDLG"), _hwnd,
					         (DLGPROC) LanguageDialog->LanguageDlgProc, (LPARAM)LanguageDialog) == 1)
				{
                  LoadString(hLibrary,IDS_RESTART, EditText, sizeof(EditText));
                  LoadString(hLibrary,IDS_WARNING, szString, sizeof(szString));
                  MessageBox(_hwnd,(LPCTSTR) EditText, (LPCTSTR) szString, MB_ICONWARNING );
				}
                delete LanguageDialog;
               return 0;

           case ID_MN_COM_SELECT:
                ComDialog = new DlgCom(hLibrary);
				if (DialogBoxParam(hLibrary, TEXT ("COMDLG"), _hwnd,
					         (DLGPROC) ComDialog->ComDlgProc, (LPARAM)ComDialog) == 1)
				{
                    GetPrivateProfileString("Devices","Comport", "COM1", szCommPort, 10,IniPath);
					MixerDialog->InitRemote(szCommPort);
				}
				else MixerDialog->CloseRemote();

                delete LanguageDialog;
               return 0;


           case ID_MN_MIXERSECTION:
                if (GetMenuState(hMenu, ID_MN_MIXERSECTION, MF_BYCOMMAND) == MFS_CHECKED)
                {
                  CheckMenuItem(hMenu, ID_MN_MIXERSECTION, MF_BYCOMMAND | MF_UNCHECKED);
                  MixerDialog->HideDialog();
                }else {
                  MixerDialog->ShowDialog();
                  CheckMenuItem(hMenu, ID_MN_MIXERSECTION, MF_BYCOMMAND | MF_CHECKED);
                }
                return 0;
           case ID_MN_SAVEPOSITIONS:
                SavePositions();
                return 0;
           case ID_ACCEL_LEFTLOAD:
                MixerDialog->PlayerLeftLoad();
                return 0;
           case ID_ACCEL_LEFTPLAY:
                MixerDialog->PlayerLeftPlay();
                return 0;
           case ID_ACCEL_LEFTCUE:
                MixerDialog->PlayerLeftCue();
                return 0;
           case ID_ACCEL_RIGHTLOAD:
                MixerDialog->PlayerRightLoad();
                return 0;
           case ID_ACCEL_RIGHTPLAY:
                MixerDialog->PlayerRightPlay();
                return 0;
           case ID_ACCEL_RIGHTCUE:
                MixerDialog->PlayerRightCue();
                return 0;
           case ID_MN_CONTENT:
   		        WinHelp(_hwnd, HelpPath,HELP_FINDER, 0);
                return 0;
           case ID_MN_INDEX:
   		        WinHelp(_hwnd, HelpPath,HELP_KEY, 0);
                return 0;
           case ID_MN_INFO:
                DialogBox(hLibrary, TEXT ("AboutBox"), _hwnd, (DLGPROC)AboutDlgProc);
                return 0;
           }
           return 0;

      case WM_NOTIFY:
           pnmh = (LPNMHDR) lParam;
           if (pnmh->hwndFrom == hActiveListView)
           {
             ListViewNotify(lParam);
           }
           return 0;

      case WM_SIZE:
             GetClientRect(_hwnd, &rect);
             if (hActiveListView != NULL) MoveWindow(hActiveListView, 0, 22, rect.right,  rect.bottom-22, TRUE);
            ::UpdateWindow (_hwnd);
           return 0;
       case WM_HELP:
            WinHelp(_hwnd, HelpPath,HELP_CONTEXT, 60);
            return 0;


      case WM_CREATE:
           DragAcceptFiles(_hwnd, FALSE);
           SetMenu(_hwnd, hMenu);
           SetControls();
           return 0;

 	  case WM_DESTROY:
           DestroyMenu(hMenu);
           DeleteObject(hFont);
          ::SetWindowLong(hActiveListView, GWL_WNDPROC, (LONG)pfnOldListViewProc);
           PostQuitMessage(0);
          return 0;

  }
  return ::DefWindowProc (_hwnd, message, wParam, lParam );
}

LRESULT CALLBACK MainWnd::ListViewProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  MainWnd * pObject  = NULL;
  pObject=(MainWnd*)GetWindowLong((HWND)GetWindowLong(hwnd,GWL_HWNDPARENT), NULL);

  if (pObject) // sicherheitshalber nachfragen....
    return pObject->ListViewEvents(message,wParam,lParam);
  else
   return(::CallWindowProc((WNDPROC) pObject->pfnOldListViewProc, hwnd, message, wParam, lParam));
}


LRESULT CALLBACK MainWnd::MainWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  MainWnd * pObject = NULL;

  if (message==WM_CREATE)
  {
    pObject = (MainWnd*)(((CREATESTRUCT FAR*)lParam)->lpCreateParams);
    SetWindowLong(hwnd,0,(LONG)pObject);

   pObject->_hwnd = hwnd;

  } else { // Alle anderen Messages

   pObject=(MainWnd*)GetWindowLong(hwnd,NULL);

  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->Events(message,wParam,lParam);
  else
    return DefWindowProc(hwnd,message,wParam,lParam);
}






/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#ifndef mainwindowH
#define mainwindowH

// API-Dialogboxen
#include "Infobox.h"
#include "scandlg.h"
#include "LangDlg.h"
#include "devicedlg.h"
#include "comdlg.h"
#include "mixerdlg.h"
#include "printdlg.h"
#include "ideditwnd.h"
#include <winver.h>


class MainWnd
{
  public:
                    MainWnd();
                   ~MainWnd();
                    //MainWnd(MainWnd& other){};
              void  Show();

    HWND     _hwnd;
    HACCEL   hAccel;

  private:

              HWND  CreateListView();
              void  SetControls();
              void  SetSound();
           LRESULT  ListViewNotify(LPARAM lParam);
    static LRESULT  CALLBACK MainWndProc(HWND hWnd, UINT Message,WPARAM wParam,LPARAM lParam);
            LRESULT Events(UINT message, WPARAM wParam, LPARAM lParam);

    static LRESULT  CALLBACK ListViewProc(HWND hWnd, UINT Message,WPARAM wParam,LPARAM lParam);
           LRESULT ListViewEvents(UINT message, WPARAM wParam, LPARAM lParam);

              void  Init();
              void  CreateNewPlayer();
              void  AutoLoad();
              void  LoadPlayList();
              void  PrinterSetup();
              void  SavePositions();




    HINSTANCE      hLibrary;
    char           IniPath[MAX_PATH];
    char           DataPath[MAX_PATH];
    WNDCLASS      _class;
    HFONT          hFont;
    HMENU          hMenu;
    HWND           hEditArtist;
    HWND           hEditSong;
    HWND           hEditGenre;
    HWND           hEditYear;
    HWND           hActiveListView;
    FARPROC        pfnOldListViewProc;
    int            iListViewPos;
    ndw_DataBase  *DataBase;
    DlgScan       *ScanDialog;
    DlgLanguage   *LanguageDialog;
    DlgCom        *ComDialog;
    DlgDevice     *DeviceDialog;
    DlgMixer      *MixerDialog;
    IdEdit        *IdEditor;
    DlgPrint      *PrintDialog;
    PlayerWnd     *PlayerForm;
    DSBasicObject         Prim_Head;
    vector<DSBasicObject> Prim_Aux;
    char       HelpPath[10];
};

//---------------------------------------------------------------------------
#endif

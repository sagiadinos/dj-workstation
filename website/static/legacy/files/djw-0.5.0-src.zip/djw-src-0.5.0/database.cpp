/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "database.h"

ndw_DataBase::ndw_DataBase()
{
  char DBPath[MAX_PATH];
  GetCurrentDirectory(MAX_PATH, DBPath);
  strcat(DBPath, "\\Data");
  
  strcpy(DBFile, DBPath);
  strcat(DBFile, "\\Data.ndb");
  strcpy(IDXSongname, DBPath);
  strcat(IDXSongname, "\\s.ndx");
  strcpy(IDXGenre, DBPath);
  strcat(IDXGenre, "\\g.ndx");
  strcpy(IDXYear, DBPath);
  strcat(IDXYear, "\\y.ndx");
  strcpy(IDXArtist, DBPath);
  strcat(IDXArtist, "\\a.ndx");

  strcpy(szActualIndex, "None");

  fDatabase = fopen(DBFile, "rb+");
  if (fDatabase == NULL) // if File not exist create Files
  {
    fDatabase = fopen(DBFile, "wb+");
    ndb_Header.iCount = 0;
    ndb_Header.iVersion = 1;
  }
  else
  { // if File exists read Header
    fread(&ndb_Header, sizeof(ndb_Header), 1, fDatabase);
  }
}

ndw_DataBase::~ndw_DataBase()
{
  fclose(fDatabase);
}

void ndw_DataBase::AppendRecord(ndw_DataSet DataSet)
{
  lDataBase.push_back(DataSet);
  return;
}

ndw_DataSet ndw_DataBase::GetActualDataSet()
{
    if (iActualDataSet > -1) return vDataBase[iActualDataSet];
	else return vDataBase[0];
}

void ndw_DataBase::SetActualDataSet(int i)
{
  iActualDataSet = i;
  return ;
}

void ndw_DataBase::WriteStartTime(int StartTime)
{ //Seek Only to Value befor StartTime
  fseek(fDatabase, (sizeof(ndb_Header))+(sizeof(vDataBase[0])*(iActualDataSet+1))-3*sizeof(StartTime), SEEK_SET);
  fwrite(&StartTime, sizeof(StartTime), 1, fDatabase);
  vDataBase[iActualDataSet].StartTime = StartTime;
  return ;
}

void ndw_DataBase::WriteActualDataSet(ndw_DataSet DataSet)
{
  fseek(fDatabase, (sizeof(ndb_Header))+(sizeof(DataSet)*iActualDataSet), SEEK_SET);
  fwrite(&DataSet, sizeof(DataSet), 1, fDatabase);
  vDataBase[iActualDataSet] = DataSet;
  return ;
}

int ndw_DataBase::FindArtist(char *szText)
{
  vector<idx_Artist>::const_iterator a;
  idx_Artist Value;
  strcpy(Value.szArtist, szText);
  a = lower_bound(idxArtist.begin(), idxArtist.end(), Value);
  if (a != idxArtist.end())
  {
    itArtist = a;
    iActualDataSet = (*itArtist).iIndex;
    return (int) (a - idxArtist.begin());
  }
  else return (int)(itArtist - idxArtist.begin());
}


int ndw_DataBase::FindSongname(char *szText)
{
  vector<idx_Songname>::const_iterator a;
  idx_Songname Value;
  strcpy(Value.szSongname, szText);
  a = lower_bound(idxSongname.begin(), idxSongname.end(), Value);
  if (a != idxSongname.end())
  {
    itSongname = a;
    iActualDataSet = (*itSongname).iIndex;
    return (int) (a - idxSongname.begin());
  }
  else return (int) (itSongname - idxSongname.begin());
}

int ndw_DataBase::FindGenre(char *szText)
{
  vector<idx_Genre>::const_iterator a;
  idx_Genre Value;
  strcpy(Value.szGenre, szText);
  a = lower_bound(idxGenre.begin(), idxGenre.end(), Value);
  if (a != idxGenre.end())
  {
    itGenre = a;
    iActualDataSet = (*itGenre).iIndex;
    return (int) (a - idxGenre.begin());
  }
  else return (int) (itGenre - idxGenre.begin());
}

int ndw_DataBase::FindYear(char *szText)
{
  vector<idx_Year>::const_iterator a;
  idx_Year Value;
  strcpy(Value.szYear, szText);
  a = lower_bound(idxYear.begin(), idxYear.end(), Value);
  if (a != idxYear.end())
  {
    itYear = a;
    iActualDataSet = (*itYear).iIndex;
    return (int) (a - idxYear.begin());
  }
  else return (int) (itYear - idxYear.begin());
}

void ndw_DataBase::FindPath(char *szText)
{
  if (ndb_Header.iCount > 0)
  {
    ndw_DataSet Value;
    vector<ndw_DataSet>::const_iterator a;
	strcpy(Value.szPath, szText);
    a = lower_bound(vDataBase.begin(), vDataBase.end(), Value);
    iActualDataSet = a - vDataBase.begin();
  }
  return;
}

int ndw_DataBase::FindExactPath(char *szText)
{
  if (ndb_Header.iCount > 0)
  {
    ndw_DataSet Value;
    vector<ndw_DataSet>::const_iterator a;
	strcpy(Value.szPath, szText);
    a = lower_bound(vDataBase.begin(), vDataBase.end(), Value);
    if (strcmp((*a).szPath, szText) != 0) return -1;
	else return 0;
  }
  return -1;
}


void ndw_DataBase::SetActiveIndex(char * IndexName)
{
  strcpy(szActualIndex, IndexName);
  return;
}

int ndw_DataBase::GetFromActiveIndex(int iLVCount)
{
  if( iLVCount > -1)
  {
    if (strcmp(szActualIndex, "Artist") == 0)   {return idxArtist[iLVCount].iIndex;}
    if (strcmp(szActualIndex, "Songname") == 0) {return idxSongname[iLVCount].iIndex;}
    if (strcmp(szActualIndex, "Genre") == 0)    {return idxGenre[iLVCount].iIndex;}
    if (strcmp(szActualIndex, "Year") == 0)     {return idxYear[iLVCount].iIndex;}
    if (strcmp(szActualIndex, "Path") == 0)     {return iLVCount;}
  }
  return 0;
}

void ndw_DataBase::ReadOnlyDB()
{
  if (ndb_Header.iCount > 0)
  {
    vDataBase.resize(ndb_Header.iCount);
    for (int i = 0; i < ndb_Header.iCount; i++)
    {
      fread(&vDataBase[i],sizeof(vDataBase[i]), 1, fDatabase);
    }
  }
}

int ndw_DataBase::ReadFiles()
{
    fSongname = fopen(IDXSongname, "rb");
    if (fSongname == NULL)
    {
       ReadOnlyDB();
       return 1;
    }
    fGenre    = fopen(IDXGenre, "rb");
    if (fGenre == NULL)
    {
      fclose(fSongname);
      ReadOnlyDB();
      return 1;
    }
    fArtist     = fopen(IDXArtist, "rb");
    if (fArtist == NULL)
    {
      fclose(fGenre);
      fclose(fSongname);
      ReadOnlyDB();
      return 1;
    }
    fYear     =  fopen(IDXYear, "rb");
    if (fYear == NULL)
    {
      fclose(fArtist);
      fclose(fSongname);
      fclose(fGenre);
      ReadOnlyDB();
      return 1;
    }

    if (ndb_Header.iCount > 0)
    {
	  vDataBase.resize(ndb_Header.iCount);
      idxArtist.resize(ndb_Header.iCount);
      idxSongname.resize(ndb_Header.iCount);
      idxGenre.resize(ndb_Header.iCount);
      idxYear.resize(ndb_Header.iCount);
      for (int i = 0; i < ndb_Header.iCount; i++)
      {

        fread(&vDataBase[i],sizeof(vDataBase[i]), 1, fDatabase);
        fread(&idxArtist[i],sizeof(idxArtist[i]), 1, fArtist);
        fread(&idxSongname[i],sizeof(idxSongname[i]), 1, fSongname);
        fread(&idxGenre[i],sizeof(idxGenre[i]), 1, fGenre);
        fread(&idxYear[i],sizeof(idxYear[i]), 1, fYear);
      }
    }
    fclose(fArtist);
    fclose(fSongname);
    fclose(fGenre);
    fclose(fYear);
  return 0;

}

void ndw_DataBase::CreateIndices()
{
  ndw_DataSet DataSet;

    //Copy List To Vector
    int iSize = lDataBase.size();
    vDataBase.clear();
    vDataBase.resize(iSize);

    idxArtist.clear();
    idxArtist.resize(iSize);
    idxSongname.clear();
    idxSongname.resize(iSize);
    idxGenre.clear();
    idxGenre.resize( iSize);
    idxYear.clear();
    idxYear.resize(iSize);

    list<ndw_DataSet>::const_iterator b = lDataBase.begin();
    int i = 0;
    //write to vector
    while(b != lDataBase.end())
    {
      DataSet = *b;
      vDataBase[i] = DataSet;
      b++;
      i++;
    }
    lDataBase.resize(0);
    sort(vDataBase.begin(),vDataBase.end());

    for (i = 0; i < iSize; i++) // Kopiere alles in vIndexe
    {
      DataSet = vDataBase[i];
      idxArtist[i].iIndex     = i;
      strcpy(idxArtist[i].szArtist, vDataBase[i].szArtist);
      idxSongname[i].iIndex = i;
      strcpy(idxSongname[i].szSongname, vDataBase[i].szSongname);
      idxGenre[i].iIndex    = i;
      strcpy(idxGenre[i].szGenre, vDataBase[i].szGenre);
      idxYear[i].iIndex     = i;
      strcpy(idxYear[i].szYear, vDataBase[i].szYear);
      idxSongname[i].iIndex = i;
      strcpy(idxYear[i].szYear, vDataBase[i].szYear);
    }
  return;
}

void ndw_DataBase::Sort()
{
  sort(idxArtist.begin(), idxArtist.end());
  sort(idxSongname.begin(),idxSongname.end());
  sort(idxGenre.begin(), idxGenre.end());
  sort(idxYear.begin(), idxYear.end());
  return;
}

void ndw_DataBase::WriteID3Tag(ndw_DataSet DataSet)
{
  char          Tag[3];
  char          Songname[30] = "";
  char          Artist[30] = "";
  char          Album[30] = "";
  char          Year[4] = "";
  unsigned int  iGenre = 0;
  char          Comment[30] = "";
  int i;
//  unsigned char Genre = 255;
  strncpy(Tag, "TAG", 3);
  strncpy(Artist, DataSet.szArtist, 30);
  for (i = 29; i > -1; i--)
  {
    if (Artist[i] == '\0') Artist[i] = ' ';
		 else break;
  }

  strncpy(Songname, DataSet.szSongname, 30);
  for (i = 29; i > -1; i--)
  {
    if (Songname[i] == '\0') Songname[i] = ' ';
		 else break;
  }

  strncpy(Year, DataSet.szYear, 4);
  for (i = 3; i > -1; i--)
  {
    if (Year[i] == '\0') Year[i] = ' ';
		 else break;
  }
  
  strncpy(Comment, DataSet.szGenre, 30);
  for (i = 29; i > -1; i--)
  {
    if (Comment[i] == '\0') Comment[i] = ' ';
		 else break;
  }

  DWORD         dwAttr = GetFileAttributes(DataSet.szPath); // SAve File Atribute
  //Set File-Attribute to normal if it is not accessible
  if ((dwAttr & FILE_ATTRIBUTE_READONLY) |
      (dwAttr & FILE_ATTRIBUTE_SYSTEM) |
      (dwAttr & FILE_ATTRIBUTE_ARCHIVE) |
      (dwAttr & FILE_ATTRIBUTE_HIDDEN))
  {
    SetFileAttributes(DataSet.szPath, FILE_ATTRIBUTE_NORMAL);
  }
    //open file and check if there is a ID3-Tag
    FILE *FileHandle = fopen(DataSet.szPath, "rb+");
    fseek(FileHandle, -128, SEEK_END);
    fread(&Tag, 3, 1, FileHandle);
    if ((strncmp(Tag, "TAG", 3)) == 0)
    {
       fseek(FileHandle, -128, SEEK_END);
       fwrite(&Tag, 3, 1, FileHandle);
       fwrite(&Songname, 30, 1, FileHandle);
       fwrite(&Artist, 30, 1, FileHandle);
       fwrite(&Album, 30, 1, FileHandle);
       fwrite(&Year, 4, 1, FileHandle);
       fwrite(&Comment, 30, 1, FileHandle);
       fwrite(&iGenre, 1, 1, FileHandle);
    }
    else // If File has no ID3-Tag
    {
       strncpy(Tag, "TAG", 3); 
       fseek(FileHandle, 0, SEEK_END);
       fwrite(&Tag, 3, 1, FileHandle);
       fwrite(&Songname, 30, 1, FileHandle);
       fwrite(&Artist, 30, 1, FileHandle);
       fwrite(&Album, 30, 1, FileHandle);
       fwrite(&Year, 4, 1, FileHandle);
       fwrite(&Comment, 30, 1, FileHandle);
       fwrite(&iGenre, 1, 1, FileHandle);
    }
    fclose(FileHandle);
    SetFileAttributes(DataSet.szPath, dwAttr);
}


void ndw_DataBase::WriteOGG_Comment(ndw_DataSet DataSet)
{
  vcedit_state state;
  DWORD         dwAttr = GetFileAttributes(DataSet.szPath); // SAve File Atribute
  //Set File-Attribute to normal if it is not accessible
  if ((dwAttr & FILE_ATTRIBUTE_READONLY) |
      (dwAttr & FILE_ATTRIBUTE_SYSTEM) |
      (dwAttr & FILE_ATTRIBUTE_ARCHIVE) |
      (dwAttr & FILE_ATTRIBUTE_HIDDEN))
  {
    SetFileAttributes(DataSet.szPath, FILE_ATTRIBUTE_NORMAL);
  }
  FILE *fin = fopen(DataSet.szPath,"r+b");
  vcedit_open(&state, fin);
  FILE *fout = fopen("C:\\test2.ogg","w+b");
  char            v_comment[20] = "";
  vorbis_comment  vc;
  vorbis_comment_clear(&vc);
  for (int i = 0; i < state.vc->comments; i++)
  {
	strset(v_comment,'\0');
	strncpy(v_comment, state.vc->user_comments[i], strcspn(state.vc->user_comments[i],"="));
    if ((strcmp(v_comment,"ARTIST")!=0) & (strcmp(v_comment,"TITLE")!=0) &
		  (strcmp(v_comment,"GENRE")!=0) & (strcmp(v_comment,"DATE")!=0))
    {
      vorbis_comment_add(&vc, state.vc->user_comments[i]); 
	}
  }
  vorbis_comment_add_tag(&vc,"ARTIST", DataSet.szArtist);
  vorbis_comment_add_tag(&vc,"TITLE", DataSet.szSongname);
  vorbis_comment_add_tag(&vc,"GENRE", DataSet.szGenre);
  vorbis_comment_add_tag(&vc,"DATE", DataSet.szYear);

  state.vc = &vc;
  vcedit_write(&state, (void *)fout);
  fclose(fin);
  fclose(fout);
  CopyFile("C:\\test2.ogg", DataSet.szPath,FALSE);
  DeleteFile("C:\\test2.ogg");

  return;
  
}



void ndw_DataBase::ReIndex()
{
  int iSize = vDataBase.size();
  idxArtist.clear();
  idxArtist.resize(iSize);
  idxSongname.clear();
  idxSongname.resize(iSize);
  idxGenre.clear();
  idxGenre.resize( iSize);
  idxYear.clear();
  idxYear.resize(iSize);
  int i;

  for (i = 0; i < iSize; i++) // Kopiere alles in vIndexe
  {
    idxArtist[i].iIndex     = i;
    strcpy(idxArtist[i].szArtist, vDataBase[i].szArtist);
    idxSongname[i].iIndex = i;
    strcpy(idxSongname[i].szSongname, vDataBase[i].szSongname);
    idxGenre[i].iIndex    = i;
    strcpy(idxGenre[i].szGenre, vDataBase[i].szGenre);
    idxYear[i].iIndex     = i;
    strcpy(idxYear[i].szYear, vDataBase[i].szYear);
    idxSongname[i].iIndex = i;
    strcpy(idxYear[i].szYear, vDataBase[i].szYear);
  }
  sort(idxArtist.begin(), idxArtist.end());
  sort(idxSongname.begin(),idxSongname.end());
  sort(idxGenre.begin(), idxGenre.end());
  sort(idxYear.begin(), idxYear.end());

  fArtist   = fopen(IDXArtist, "wb");
  fSongname = fopen(IDXSongname, "wb");
  fGenre    = fopen(IDXGenre, "wb");
  fYear     = fopen(IDXYear, "wb");
  for (i = 0; i < iSize; i++)
  {
    fwrite(&idxArtist[i], sizeof(idxArtist[i]), 1, fArtist);
    fwrite(&idxSongname[i], sizeof(idxSongname[i]), 1, fSongname);
    fwrite(&idxGenre[i], sizeof(idxGenre[i]), 1, fGenre);
    fwrite(&idxYear[i], sizeof(idxYear[i]), 1, fYear);
  }
  fclose(fArtist);
  fclose(fSongname);
  fclose(fGenre);
  fclose(fYear);
  return;
}

void ndw_DataBase::WriteFiles()
{
   //write Header Files
    if (fDatabase != NULL )fclose(fDatabase);
    fDatabase = fopen(DBFile, "wb+");
    ndb_Header.iCount = vDataBase.size();
    fwrite(&ndb_Header, sizeof(ndb_Header), 1, fDatabase);

    fArtist   = fopen(IDXArtist, "wb");
    fSongname = fopen(IDXSongname, "wb");
    fGenre    = fopen(IDXGenre, "wb");
    fYear     = fopen(IDXYear, "wb");
    for (int i = 0; i < ndb_Header.iCount; i++) // Kopiere alles in vIndexe
    {
      fwrite(&vDataBase[i], sizeof(vDataBase[i]), 1, fDatabase);
      fwrite(&idxArtist[i], sizeof(idxArtist[i]), 1, fArtist);
      fwrite(&idxSongname[i], sizeof(idxSongname[i]), 1, fSongname);
      fwrite(&idxGenre[i], sizeof(idxGenre[i]), 1, fGenre);
      fwrite(&idxYear[i], sizeof(idxYear[i]), 1, fYear);
    }
  fclose(fArtist);
  fclose(fSongname);
  fclose(fGenre);
  fclose(fYear);
  return;
}




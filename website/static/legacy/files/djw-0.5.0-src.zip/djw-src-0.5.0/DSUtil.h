/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#ifndef DSUtilH
#define DSUtilH
#include "Formate.h"
#include "SoundTouch.h"
#define DSBVOLUME_MIN -10000
#define DSBVOLUME_MAX  0

    // Sekund�res Abspielobject
  class DoublePlayer

  {
    public:

             DoublePlayer();
            ~DoublePlayer();
       void  Init(LPDIRECTSOUND Lpds_Aux, LPDIRECTSOUND Lpds_Head);
       void  Load(LPSTR lpzFileName, int iTFastEnde, LPSTR ext);
       void  UnLoad();
       char *GetTime(int SeekBarPos, BOOL elapse);
       int   GetDuration();
       int   Execute();
       void  Aux_Volume(int iVolume);
       void  Head_Volume(int iVolume);
       void  Play();
       void  CuePlay();
       void  Pause();
       void  CuePause();
       void  Pitch(int iPosition);
       void  SetNecessaryInputBuffer();
       void  SetMastertempo();
       void  UnSetMastertempo();
       void  Seek(int iPosition);


      BOOL        FastEnde;
      BOOL        Mastertempo;
      int         iFastEnde;
      int         iEOFCount;
      bool        loaded;

    private:

      void LoadBuffer(DWORD dwStartOfs);
      void LoadCueBuffer();
      void FlushDSPBuffer();
      int  PrepareData(char *out);
      SoundTouch           pSoundTouch;
      LPVOID               lpData_Aux, lpData_Head;
      LPVOID               lpData_CueAux, lpData_CueHead;
      char                *output_buffer;
      char                *temp_buffer;
	  DWORD                dwtemp_buffer;
      DSBUFFERDESC         dsbdesc;
      DSBUFFERDESC         dsbdescCue;
      char                 szTime[20];
      BasicPlayer         *Player;
      Mp3Player            mp3player;
      VorbisPlayer         vorbisplayer;
      WavPlayer            wavplayer;
      LPDIRECTSOUND        lpds_Aux;      // prim�aere Buffer aus BasicObject Ausgang
      LPDIRECTSOUND        lpds_Head;     // prim�aere Buffer aus BasicObject Kopfh�rer
      LPDIRECTSOUNDBUFFER  lpdsb_Aux;     // Sekund�rer Soundbuffer Ausgang
      LPDIRECTSOUNDBUFFER  lpdsb_Head;    // Sekund�rer Soundbuffer Kopfh�rer
      LPDIRECTSOUNDBUFFER  lpdsb_CueAux;     // Sekund�rer Soundbuffer Ausgang
      LPDIRECTSOUNDBUFFER  lpdsb_CueHead;    // Sekund�rer Soundbuffer Kopfh�rer
      WAVEFORMATEX         pwfx;
      DWORD                dwMidBuffer;   // DSPuffermitte
      DWORD                dwLastPlayPos; // letze abgefragte DSPufferposition
  };



// Basisobject f�r prim�re Buffer und zur DS-Initialisierung

class DSBasicObject

{

  public:

                   DSBasicObject::DSBasicObject()
				   {
					   lpds         = NULL;
				       lpdsbPrimary = NULL;
				       lpds         = NULL;
                       memset( &wfm, 0, sizeof( WAVEFORMATEX ) ); //Initializierung von wfm
                       memset( &dsbdesc, 0, sizeof( DSBUFFERDESC ) ); //Isnitialisieren von dsbdesc
				   }
                   DSBasicObject(const DSBasicObject& other)
				   {
						lpdsbPrimary = other.lpdsbPrimary;
						lpds         = other.lpds;
						wfm          = other.wfm;
						dsbdesc      = other.dsbdesc;
				   };
				   ~DSBasicObject(){};

				   Init(HWND Handle, LPGUID lpGuid);
				   Delete();

    LPDIRECTSOUND  GetDSBuffer(){return lpds;}
  private:


    LPDIRECTSOUNDBUFFER  lpdsbPrimary;  // Primarer DSPuffer zur Initialisierung
    LPDIRECTSOUNDBUFFER  lpdsbSecWin2000;  // Sekund�rer DSPuffer zum Win2000 Workaround
    LPDIRECTSOUND        lpds;          // IDirectSoundObject
    WAVEFORMATEX         wfm;
    DSBUFFERDESC         dsbdesc;
    DSBUFFERDESC         dsbdescSecWin2000;


};


//---------------------------------------------------------------------------

#endif

/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/

#include "Formate.h"

void Mp3Player::Load(LPSTR lpzFileName)
{
   // Initialisierung des Decoderobjectes. Reihenfolge ist wichtig!
   decoder = new XA_Decoder();
   file_input_module_register(&InputModule);
   mpeg_codec_module_register(&CodecModule);
   decoder->CodecModuleRegister(&CodecModule);

   
   decoder->InputModuleRegister(&InputModule);
   decoder->InputNew(lpzFileName, XA_DECODER_INPUT_AUTOSELECT);
   decoder->InputOpen();

   
   // Umwandlung des Wertes f�r Stereo vom xaudio-Wert zum Waveformatex Wert
   do //Workaround for some mp3's seems to be broken at start
   {
     decoder->Decode(NULL);  // Decodiere Frame um ->outputbuffer zu bekommen
   } while (decoder->info->output_buffer->nb_samples == 0);
   //viermal, weil sonst bei manchen M�ll bei pcm_Time rauskommt rauskommt
   channels  = decoder->info->output_buffer->nb_channels;
   
   BitsPerSample     = decoder->info->output_buffer->bytes_per_sample*8;
   frequency         = decoder->info->output_buffer->sample_rate;
   AvgBytesPerSec    = frequency*channels*BitsPerSample/8;
   pcm_buffer        = decoder->info->output_buffer->nb_samples*decoder->info->output_buffer->bytes_per_sample*channels;
   pcm_Time          = (pcm_buffer*1000/AvgBytesPerSec); //Gr�sse eines Frames in ms
   
   decoder->InputSeekToOffset(0); //Seeke Zur�ck

   iBuffer_Uebertrag_Size = 0;
   iBuffer_Uebertrag_Time = 0;
   pBuffer_Uebertrag      = new char[iBuffer_Uebertrag_Size];
   lpData                 = new char[pcm_buffer];

   return;

}

void Mp3Player::Unload()
{
   decoder->InputClose();   // schliesse das Eingabeobject
   decoder->InputDelete();  // Decodereingabeobjekt freigeben
   delete decoder;         // Decoderobjekt freigeben
   ::delete [] lpData;
   ::delete [] pBuffer_Uebertrag;
   return;
}


WAVEFORMATEX Mp3Player::GetSoundFormat()
{
   pwfx.wFormatTag         = 1;
   pwfx.nChannels          = (WORD) channels;
   pwfx.nSamplesPerSec     = (DWORD)frequency;
   pwfx.nAvgBytesPerSec    = (DWORD)AvgBytesPerSec;
   pwfx.nBlockAlign        = (WORD)(channels*BitsPerSample/8);
   pwfx.wBitsPerSample     = (WORD) BitsPerSample;
   pwfx.cbSize             = 0 ;
   return pwfx;
}

int Mp3Player::GetData(char *output_buffer, int Data_needed)
{
   char             *lp3Data;
   int               ErrorCode = 0;
   int               iDataGetted = 0;

   iDataGetted = iBuffer_Uebertrag_Size;
   lp3Data = new char[iBuffer_Uebertrag_Size+Data_needed+pcm_buffer];
   memmove((char *)lp3Data,(char *) pBuffer_Uebertrag, iBuffer_Uebertrag_Size);   
   do
   {
      ErrorCode = decoder->Decode(lpData);
      if (ErrorCode == XA_ERROR_INPUT_EOS)  // Bei Ende mit Stille Auff�llen.
      {
         if (BitsPerSample >= 16) {memset(lpData, 0, pcm_buffer);}
         else {memset(lpData, 128, pcm_buffer);}  // Stille bei 8 Bit Vorzeichenlos
       }
       memmove((char *)lp3Data+iDataGetted,(char *)lpData, pcm_buffer);
	   iDataGetted = iDataGetted + pcm_buffer;
   } while (iDataGetted < Data_needed);
   
   // Copy Teil des wavestram ins DirectSound-Modul
   memmove((char *)output_buffer,(char *) lp3Data, Data_needed);

   // Speichere Neue �bertragsgr�sse
   iBuffer_Uebertrag_Size = iDataGetted-Data_needed;
   iBuffer_Uebertrag_Time = (iBuffer_Uebertrag_Size*100)/AvgBytesPerSec;
   delete [] pBuffer_Uebertrag;

   // Speichere neuen �bertrag
   pBuffer_Uebertrag      = new char [iBuffer_Uebertrag_Size];
   memmove((char *)pBuffer_Uebertrag,(char *) lp3Data+Data_needed, iBuffer_Uebertrag_Size);

   delete [] (lp3Data);

   if (ErrorCode != XA_ERROR_INPUT_EOS) {return 0;}
   else {return SongEnde;}
}

int Mp3Player::GetPosition()
{
  return decoder->info->status->timecode.h*360000+
             decoder->info->status->timecode.m*6000+
              decoder->info->status->timecode.s*100+
               decoder->info->status->timecode.f-iBuffer_Uebertrag_Time;

   
}

void Mp3Player::Seek(int iTimePos) // iTimePos gibt die Zeit in Hunderstel Sek an
{
  delete[] (pBuffer_Uebertrag); // Leere �bertragBuffer

  float fTimePos  = (float) iTimePos*10; // Mache aus Hunderstel Tausenstel

  if (fTimePos > pcm_Time)
  {
	  decoder->InputSeekToTime((fTimePos-pcm_Time)/1000);
      decoder->Decode(lpData); //Seeke einen Frame vor
  } //seeke einen Frame zur�ck
  else
  {decoder->InputSeekToTime(0);} //seeke auf Null weil Anfang
  int newTimePos =  (decoder->info->status->timecode.h*360000+
                        decoder->info->status->timecode.m*6000+
                         decoder->info->status->timecode.s*100+
                          decoder->info->status->timecode.f);
  
  // �bertrag durch Subtr. der Zeiten mit Zur�ckstellung auf Hunderstel
  iBuffer_Uebertrag_Time = ((newTimePos*10) - (iTimePos*10))/10;                                                                    
  iBuffer_Uebertrag_Size = iBuffer_Uebertrag_Time*(AvgBytesPerSec/100);

  if (iBuffer_Uebertrag_Size > pcm_buffer) {iBuffer_Uebertrag_Size = pcm_buffer;} // sicher ist sicher
  if (iBuffer_Uebertrag_Size < 0) {iBuffer_Uebertrag_Size = 0;} // sicher ist sicher

  div_t Test = div(iBuffer_Uebertrag_Size,2); //Test auf ungeraden Wert
  if (Test.rem != 0){iBuffer_Uebertrag_Size--;} //Falls ja mache gerade Zahl daraus sonst M�ll

  pBuffer_Uebertrag  =  new char[iBuffer_Uebertrag_Size];

  // Hier liegt was im Argen wen der �bertrag gr�sser wrd als pcm_buffer
  memmove((char *)pBuffer_Uebertrag,(char *) lpData+(pcm_buffer-iBuffer_Uebertrag_Size), iBuffer_Uebertrag_Size);
}

/***************************************************************************************************************/
//Routinen des Ogg-VorbisPlayer-Objektes


void VorbisPlayer::Load(LPSTR lpzFileName)
{

  f = fopen(lpzFileName,"rb");
  ov_open(f, &vf, NULL, 0);
  
  vorbis_info  *vi  = ov_info(&vf,-1);
  channels          = vi->channels;  
  BitsPerSample     = 16; //Recherchieren
  frequency         = vi->rate;
  AvgBytesPerSec    = frequency*channels*BitsPerSample/8;
  double dDuration  = ov_time_total(&vf,-1);
  iDuration         = (int) dDuration*100;
  pcm_buffer        = 4096;
  pcm_Time          = (pcm_buffer*1000/AvgBytesPerSec); //Gr�sse eines Frames in ms


  iBuffer_Uebertrag_Size = 0;
  iBuffer_Uebertrag_Time = 0;
  pBuffer_Uebertrag      = new char[iBuffer_Uebertrag_Size];
  return;

}

void VorbisPlayer::Unload()
{
   ov_clear(&vf);
   fclose(f);
   ::delete [] pBuffer_Uebertrag;
   return;
}


WAVEFORMATEX VorbisPlayer::GetSoundFormat()
{
   pwfx.wFormatTag         = 1;
   pwfx.nChannels          = (WORD) channels;
   pwfx.nSamplesPerSec     = (DWORD)frequency;
   pwfx.nAvgBytesPerSec    = (DWORD)AvgBytesPerSec;
   pwfx.nBlockAlign        = (WORD)(channels*BitsPerSample/8);
   pwfx.wBitsPerSample     = (WORD) BitsPerSample;
   pwfx.cbSize             = 0 ;
  return pwfx;
}

int VorbisPlayer::GetData(char *output_buffer, int Data_needed)
{
   char    lpDecodeData[4096];
   char    *lp3Data;
   int     ErrorCode = 0;
   int     current_section = -1;
  
   //intialisiere var_Buffer und f�lle ihn gegebenfalls mit dem �bertrag
   lp3Data = new char[Data_needed];
   if (BitsPerSample >= 16) {memset(lp3Data, 0, Data_needed);}
   else {memset(lp3Data, 128, Data_needed);}  // Stille bei 8 Bit Vorzeichenlos
      
   int  iAufgefuellt = iBuffer_Uebertrag_Size;
   memmove(lp3Data, pBuffer_Uebertrag, iBuffer_Uebertrag_Size);
   while (iAufgefuellt < Data_needed)
   {      
        ErrorCode = ov_read(&vf,  lpDecodeData, pcm_buffer, 0, 2, 1, &current_section);
		if (ErrorCode == 0)  // Bei Ende mit Stille Auff�llen.
        {
          if (BitsPerSample >= 16) {memset(lpDecodeData, 0, pcm_buffer);}
          else {memset(lpDecodeData, 128, pcm_buffer);}  // Stille bei 8 Bit Vorzeichenlos
		  iAufgefuellt = Data_needed + 1;
        }
        if (ErrorCode > 0)
		{         
            if ((iAufgefuellt + ErrorCode) < (Data_needed))
            {
			  memmove(lp3Data+iAufgefuellt, lpDecodeData, ErrorCode);
			}
			else
			{
              memmove(lp3Data+iAufgefuellt, lpDecodeData, Data_needed-iAufgefuellt);

			}
		}
		iAufgefuellt = iAufgefuellt + ErrorCode;
   }

   
   // Copy Teil des wavestram ins DirectSound-Modul
   memmove(output_buffer, lp3Data, Data_needed);

   // Speichere Neue �bertragsgr�sse
   iBuffer_Uebertrag_Size = iAufgefuellt - Data_needed;
   iBuffer_Uebertrag_Time = (iBuffer_Uebertrag_Size*100)/AvgBytesPerSec;
   delete [] pBuffer_Uebertrag;

   // Speichere neuen �bertrag
   pBuffer_Uebertrag      = new char [iBuffer_Uebertrag_Size];
   memmove(pBuffer_Uebertrag, lpDecodeData+ErrorCode-iBuffer_Uebertrag_Size, iBuffer_Uebertrag_Size);

   delete [] (lp3Data);
   if (ErrorCode != 0) {return 0;}
   else {return SongEnde;}
}

int VorbisPlayer::GetPosition()
{

  double dTimePosition = ov_time_tell(&vf);
  return (int) dTimePosition*100-iBuffer_Uebertrag_Time;
  
}

void VorbisPlayer::Seek(int iTimePos) // iTimePos gibt die Zeit in Hunderstel Sek an
{
  delete[] (pBuffer_Uebertrag); // Leere �bertragBuffer

  double dTimePos  = (double) iTimePos*10; // Mache aus Hunderstel Tausenstel
  char    lpDecodeData[4096];
  int     current_section = -1;
  int     ErrorCode = 0;

  if (dTimePos > pcm_Time)
  {
	  ov_time_seek(&vf, (dTimePos-pcm_Time)/1000);
      ErrorCode = ov_read(&vf,  lpDecodeData, pcm_buffer, 0, 2, 1, &current_section); //Seeke einen Frame vor
  } //seeke einen Frame zur�ck
  else
  {ov_time_seek(&vf, 0);} //seeke auf Null weil Anfang
  double newTimePos =  ov_time_tell(&vf);

  // �bertrag durch Subtr. der Zeiten mit Zur�ckstellung auf Hunderstel
  iBuffer_Uebertrag_Time = (int)((newTimePos*10) - (iTimePos*10))/10;                                                                    
  iBuffer_Uebertrag_Size = iBuffer_Uebertrag_Time*(AvgBytesPerSec/100);

  if (iBuffer_Uebertrag_Size > pcm_buffer) {iBuffer_Uebertrag_Size = pcm_buffer;} // sicher ist sicher
  if (iBuffer_Uebertrag_Size < 0) {iBuffer_Uebertrag_Size = 0;} // sicher ist sicher

  div_t Test = div(iBuffer_Uebertrag_Size,2); //Test auf ungeraden Wert
  if (Test.rem != 0){iBuffer_Uebertrag_Size--;} //Falls ja mache gerade Zahl daraus sonst M�ll

  pBuffer_Uebertrag  =  new char[iBuffer_Uebertrag_Size];
  if (BitsPerSample >= 16) {memset(lpDecodeData, 0, 4096);}
  else {memset(lpDecodeData, 128, 4096);}  // Stille bei 8 Bit Vorzeichenlos

  // Hier liegt was im Argen wen der �bertrag gr�sser wrd als pcm_buffer
//  memmove(pBuffer_Uebertrag, lpDecodeData+(pcm_buffer-iBuffer_Uebertrag_Size), iBuffer_Uebertrag_Size);
}


/***************************************************************************************************************/
//Routinen des Wave-Player-Objektes

void WavPlayer::Load(LPSTR lpzFileName)
{
   //Initialisierung der Wave-datei
   hmmio =  mmioOpen(lpzFileName, NULL,MMIO_READ );
   mmckinfoParent.fccType = mmioFOURCC('W', 'A', 'V', 'E'); 
   mmioDescend(hmmio, (LPMMCKINFO) &mmckinfoParent, NULL, MMIO_FINDRIFF); 
   mmckinfoSubchunk.ckid = mmioFOURCC('f', 'm', 't', ' ');
   mmioDescend(hmmio, &mmckinfoSubchunk, &mmckinfoParent, MMIO_FINDCHUNK); 
   dwFmtSize = mmckinfoSubchunk.cksize;  
   mmioRead(hmmio, (HPSTR) &pwfx, dwFmtSize);
   mmioAscend(hmmio, &mmckinfoSubchunk, 0); 
   mmckinfoSubchunk.ckid = mmioFOURCC('d', 'a', 't', 'a'); 
   mmioDescend(hmmio, &mmckinfoSubchunk, &mmckinfoParent,MMIO_FINDCHUNK);   
   BitsPerSample     = pwfx.wBitsPerSample;
   AvgBytesPerSec    = pwfx.nAvgBytesPerSec;
   iDuration         = (mmckinfoSubchunk.cksize/AvgBytesPerSec) * 100;
   return;

}

void WavPlayer::Unload()
{
   mmioClose(hmmio, 0); 
}


WAVEFORMATEX WavPlayer::GetSoundFormat()
{
  return pwfx;
}

int WavPlayer::GetData(char *output_buffer, int Data_needed)
{
   char    *lp3Data;
   int               ErrorCode = 0;

   lp3Data = new char[Data_needed];
   if (BitsPerSample >= 16) {memset(lp3Data, 0, Data_needed);}
   else {memset(lp3Data, 128, Data_needed);}  // Stille bei 8 Bit Vorzeichenlos  
   ErrorCode = mmioRead(hmmio, (HPSTR) lp3Data, Data_needed);
//Bei Ende mit Stille auff�llen nicht vergessen
   memmove((char *)output_buffer,(char *) lp3Data, Data_needed);
   delete(lp3Data);
   if (ErrorCode != 0)
   {
	   return 0;
   }
   else {return SongEnde;}
}

int WavPlayer::GetPosition()
{ 
   double iPosition = 0;
   iPosition = mmioSeek(hmmio, 0, SEEK_CUR);
   return (int)(iPosition / AvgBytesPerSec) * 100;
}

void WavPlayer::Seek(int iTimePos) // iTimePos gibt die Zeit in Hunderstel Sek an
{
  double dTimePos  = (double) iTimePos;
  LONG iPosition = (LONG) (dTimePos*AvgBytesPerSec)/100;
  mmioSeek(hmmio, iPosition, SEEK_SET);
}

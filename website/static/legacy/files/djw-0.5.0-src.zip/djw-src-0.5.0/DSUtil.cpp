/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/

#include "DSUtil.h"

DoublePlayer::DoublePlayer()
{
   loaded      = false;
}

DoublePlayer::~DoublePlayer()
{
}

void DoublePlayer::Init(LPDIRECTSOUND Lpds_Aux, LPDIRECTSOUND Lpds_Head)
{
   lpds_Aux      = Lpds_Aux;
   lpds_Head     = Lpds_Head;
   lpdsb_Aux     = NULL;
   lpdsb_Head    = NULL;
   lpdsb_CueAux  = NULL;
   lpdsb_CueHead = NULL;
   return;
}
int  DoublePlayer::GetDuration(){ return Player->GetDuration(); }
       
void DoublePlayer::Load(LPSTR lpzFileName, int iTFastEnde, LPSTR ext)
{
   dwLastPlayPos = 0;
   iFastEnde     = iTFastEnde*100;
   
  if ((strcmp(ext, ".MP3")==0)) Player = reinterpret_cast<Mp3Player *> (&mp3player);
  if ((strcmp(ext, ".WAV")==0)) Player = reinterpret_cast<WavPlayer *> (&wavplayer);
  if ((strcmp(ext, ".OGG")==0)) Player = reinterpret_cast<VorbisPlayer *> (&vorbisplayer);

   
   Player->Load(lpzFileName);
   pwfx          = Player->GetSoundFormat();

   memset( &dsbdesc, 0, sizeof( DSBUFFERDESC ) );
   dsbdesc.dwSize        = sizeof( DSBUFFERDESC );
   dsbdesc.dwFlags       = DSBCAPS_CTRLFREQUENCY
                           | DSBCAPS_GETCURRENTPOSITION2
                           | DSBCAPS_GLOBALFOCUS
                           | DSBCAPS_CTRLPAN
                           | DSBCAPS_CTRLVOLUME;
   dsbdesc.dwReserved    = 0;
   dsbdesc.dwBufferBytes = pwfx.nAvgBytesPerSec/2 ; // Buffer f�r 1/2 Sekunde;
   dsbdesc.lpwfxFormat   = &pwfx;

   memset( &dsbdescCue, 0, sizeof( DSBUFFERDESC ) );
   dsbdescCue.dwSize        = sizeof( DSBUFFERDESC );
   dsbdescCue.dwFlags       = DSBCAPS_CTRLFREQUENCY
                           | DSBCAPS_GETCURRENTPOSITION2
                           | DSBCAPS_GLOBALFOCUS
                           | DSBCAPS_CTRLPAN
                           | DSBCAPS_CTRLVOLUME;
   dsbdescCue.dwReserved    = 0;
   dsbdescCue.dwBufferBytes = pwfx.nAvgBytesPerSec*10/65 ; // Buffer f�r 1/10 Sekunde;
   dsbdescCue.lpwfxFormat   = &pwfx;

   // create secondary Buffers 
   if (lpds_Aux != NULL) 
   {
	   lpds_Aux->CreateSoundBuffer(&dsbdesc, &lpdsb_Aux, NULL);
	   lpds_Aux->CreateSoundBuffer(&dsbdescCue, &lpdsb_CueAux, NULL);
   }
   if (lpds_Head != NULL)
   {
	   lpds_Head->CreateSoundBuffer(&dsbdesc, &lpdsb_Head, NULL);
	   lpds_Head->CreateSoundBuffer(&dsbdescCue, &lpdsb_CueHead, NULL);
   }

   dwMidBuffer   = pwfx.nAvgBytesPerSec/4;
   output_buffer = new char [dwMidBuffer];
   dwtemp_buffer = 0;
   temp_buffer   = new char [dwtemp_buffer];
   FastEnde      = false;
   iEOFCount     = 0;
   loaded        = true;
   return;
}

void DoublePlayer::UnLoad()
{
  if (lpdsb_Aux)
  {
     lpdsb_Aux->Release();   // Sekund�ren DSBuffer freigeben
     lpdsb_Aux = NULL;
  }
  if (lpdsb_Head)
  {
     lpdsb_Head->Release();  // Sekund�ren DSBuffer freigeben
     lpdsb_Head = NULL;
  }
   ::delete [] output_buffer;
   ::delete [] temp_buffer;
   loaded      = false;
   Player->Unload();
}

int DoublePlayer::Execute()
{
  DWORD dwPlay;
  DWORD dwWrite;
  DWORD dwPreBufStreamPos;

  lpdsb_Aux->GetCurrentPosition( &dwPlay, &dwWrite );
  if (((dwPlay >= dwMidBuffer) && (dwLastPlayPos < dwMidBuffer))){LoadBuffer(0);}
  if (dwPlay < dwLastPlayPos){LoadBuffer(dwMidBuffer);}

  if (dwPlay >= dwMidBuffer){dwPreBufStreamPos = pwfx.nAvgBytesPerSec/4 * 3 - dwPlay;}
  else {dwPreBufStreamPos = pwfx.nAvgBytesPerSec/2 - dwPlay;}

  dwLastPlayPos = dwPlay;
  int a =  Player->GetPosition();
  int i = (a - ((dwPreBufStreamPos*100)/pwfx.nAvgBytesPerSec));
  return i;
}

char* DoublePlayer::GetTime(int SeekBarPos, BOOL elapse)
{
   char       ss[3] = "00";
   int        iRealTime = 0;
   int        h,m,s,f = 0;
   int Duration = GetDuration();

   if ( (Duration - SeekBarPos)< iFastEnde)
   {
	   FastEnde = TRUE;
   }
   else
   {
	   FastEnde = FALSE;
   }
   
   if (elapse)
   {
     iRealTime = SeekBarPos;
   }
   else
   {
     iRealTime = GetDuration() - SeekBarPos;
   }
   div_t d_h      = div(iRealTime, 3600000);
   h = d_h.quot;
   div_t d_min    = div(d_h.rem, 6000);
   m = d_min.quot;
   div_t d_s      = div(d_min.rem, 100);
   s = d_s.quot;
   f = d_s.rem;

   if (!elapse) strcpy(szTime, "-");
   else strcpy(szTime, "");
   if (h < 10)
   { itoa(h+10, ss, 10);
     ss[0] = '0';
   } else {itoa(h, ss, 10);}
   strcat(szTime, ss);
   strcat(szTime, ":");


   if (m < 10)
   { itoa(m+10, ss, 10);
     ss[0] = '0';
   } else {itoa(m, ss, 10);}
   strcat(szTime, ss);
   strcat(szTime, ":");

   if (s < 10)
   { itoa(s+10, ss, 10);
     ss[0] = '0';
   }else {itoa(s, ss, 10);}
   strcat(szTime, ss);
   strcat(szTime, ":");

   if (f < 10)
   { itoa(f+10, ss, 10);
     ss[0] = '0';
   } else {itoa(f, ss, 10);}
   strcat(szTime, ss);

   return szTime;
}

#define BUFF_SIZE  8192 //16384// 4096 //8192
#define BUFF_SIZE_BYTES (2 * BUFF_SIZE)

void DoublePlayer::FlushDSPBuffer()
{
    short           buffer[BUFF_SIZE];
    int             nSamples = 0;
    // Extract few last samples from the processing pipeline.
    pSoundTouch.flush();
    do
	{
        nSamples = pSoundTouch.receiveSamples(buffer, BUFF_SIZE);
    } while (nSamples != 0);
   dwtemp_buffer = 0;
   delete [] temp_buffer;
   // Speichere neuen �bertrag
   temp_buffer      = new char [dwtemp_buffer];
   if (pwfx.wBitsPerSample >= 16)
   {
	   memset(output_buffer, 0, dwMidBuffer);
	   memset(buffer, 0, BUFF_SIZE);
   }
   else
   {
	   memset(output_buffer, 128, dwMidBuffer);
	   memset(buffer, 128, BUFF_SIZE);
   }  // Stille bei 8 Bit Vorzeichenlos

}

void DoublePlayer::SetMastertempo()
{
  pSoundTouch.setSampleRate(pwfx.nSamplesPerSec);
  pSoundTouch.setChannels(pwfx.nChannels);
  pSoundTouch.setSetting(SETTING_USE_QUICKSEEK, FALSE);
  pSoundTouch.setSetting(SETTING_USE_AA_FILTER, TRUE);
}

void DoublePlayer::UnSetMastertempo()
{
    pSoundTouch.setTempoChange(0.0);
}

int DoublePlayer::PrepareData(char *out)
{

  char            input_buffer[BUFF_SIZE_BYTES];
  int             iErrorCode = 0;
  DWORD           dwOutputFuellstand = 0;
  char          *local_output_buffer;
  int             nBytes = 0;
  int             nSamples = 0;
  int             bytesPerSample = 0;
  int             buffSizeSamples = 0;
  short           buffer[BUFF_SIZE];
 
  dwOutputFuellstand  = dwtemp_buffer;
  local_output_buffer = new char [dwtemp_buffer+dwMidBuffer*2+BUFF_SIZE_BYTES];
  memmove(local_output_buffer, temp_buffer, dwtemp_buffer);

  bytesPerSample = pwfx.nChannels * pwfx.wBitsPerSample / 8;
  buffSizeSamples = BUFF_SIZE_BYTES / bytesPerSample;
  do
  {  //Get decoded PCM-Data from mp3-Library in input_buffer
     iErrorCode  = Player->GetData(input_buffer, BUFF_SIZE_BYTES);
     memmove(buffer, input_buffer, BUFF_SIZE_BYTES);
     // Calculate number of samples read
     nSamples = BUFF_SIZE_BYTES / bytesPerSample;
     pSoundTouch.putSamples(buffer, nSamples);
     do 
	 {  
        // receive processed audio data
        nSamples = pSoundTouch.receiveSamples(buffer, buffSizeSamples);
        // calculate processed audio data size in bytes
        nBytes   = nSamples * bytesPerSample;
        // write the sound data into the output file.
        memmove(local_output_buffer+dwOutputFuellstand, buffer, nBytes);
        // Calculate number of samples read
        // Feed the sound data into the processing object
        dwOutputFuellstand = dwOutputFuellstand + nBytes;
      } while (nSamples != 0); 
 } while ( dwOutputFuellstand < dwMidBuffer);

   // Copy 1, Teil des wavestram ins DirectSound-Modul
   memmove(out, local_output_buffer, dwMidBuffer);

   // Speichere Neue �bertragsgr�sse
   dwtemp_buffer = dwOutputFuellstand-dwMidBuffer;
   delete [] temp_buffer;

   // Speichere neuen �bertrag
   temp_buffer      = new char [dwtemp_buffer];
   memmove(temp_buffer, local_output_buffer+dwMidBuffer, dwtemp_buffer);

   delete [] local_output_buffer;
  return iErrorCode;
}


// Lade den Halben buffer nach.
void DoublePlayer::LoadBuffer(DWORD dwStartOfs)
{
  DWORD           dwBytes;
  int iErrorCode  = 0;
  iErrorCode  = PrepareData(output_buffer);

  if (iErrorCode == 10){ iEOFCount++;} // for detecting EoF
  if (lpdsb_Aux != NULL) // Fill Secondary buffer for Auxilary
  {
      lpdsb_Aux->Lock(dwStartOfs, dwMidBuffer, &lpData_Aux, &dwBytes, NULL, NULL,0 );
   if (pwfx.wBitsPerSample >= 16) {memset(lpData_Aux, 0, dwMidBuffer);}
   else {memset(lpData_Aux, 1, dwMidBuffer);}  // Stille bei 8 Bit Vorzeichenlos
      memmove(lpData_Aux, output_buffer,dwMidBuffer);
      lpdsb_Aux->Unlock(lpData_Aux, dwBytes, NULL, 0 );
  }
  if (lpdsb_Head != NULL) // Fill Secondary buffer for Headphones
  {
  	  lpdsb_Head->Lock( dwStartOfs, dwMidBuffer, &lpData_Head, &dwBytes, NULL, NULL, 0 );
	  memmove(lpData_Head, output_buffer, dwMidBuffer);   
	  lpdsb_Head->Unlock(lpData_Head, dwBytes, NULL, 0 );
  }
  return;
}

void DoublePlayer::LoadCueBuffer()
{
      DWORD           dwBytes;
      if (lpdsb_CueAux != NULL)
      {
          lpdsb_CueAux->Lock(0, dsbdescCue.dwBufferBytes, &lpData_CueAux, &dwBytes, NULL, NULL,0 );
          memmove(lpData_CueAux, output_buffer,dsbdescCue.dwBufferBytes);
          lpdsb_CueAux->Unlock(lpData_CueAux, dwBytes, NULL, 0 );
      }
      // �bertrag in DS-Head-Buffer
      if (lpdsb_CueHead != NULL)
      {
          lpdsb_CueHead->Lock( 0, dsbdescCue.dwBufferBytes, &lpData_CueHead, &dwBytes, NULL, NULL, 0 );
          memmove(lpData_CueHead, output_buffer, dsbdescCue.dwBufferBytes);
          lpdsb_CueHead->Unlock(lpData_CueHead, dwBytes, NULL, 0 );
      }
  return;
}


/****************************************************************************
 Player Steuerungsfunktionen
*****************************************************************************/

void DoublePlayer::Seek(int iPosition)
{
   if (lpdsb_Aux != NULL)  {lpdsb_Aux->SetCurrentPosition(0);}
   if (lpdsb_Head != NULL) {lpdsb_Head->SetCurrentPosition(0);}
 
   FlushDSPBuffer();
   Player->Seek(iPosition);
   LoadBuffer(0);
   LoadCueBuffer();
   LoadBuffer(dwMidBuffer);
   dwLastPlayPos = 0;
}

void DoublePlayer::Play()
{
  if (lpdsb_Aux != NULL){lpdsb_Aux->Play(0, 0, DSBPLAY_LOOPING );}
  if (lpdsb_Head != NULL){lpdsb_Head->Play(0, 0, DSBPLAY_LOOPING ); }
}

void DoublePlayer::CuePlay()
{  HRESULT hr;
  if (lpdsb_CueAux != NULL){hr = lpdsb_CueAux->Play(0, 0, DSBPLAY_LOOPING );}
  if (lpdsb_CueHead != NULL){lpdsb_CueHead->Play(0, 0, DSBPLAY_LOOPING ); }
}

void DoublePlayer::Pause()
{
   if (lpdsb_Aux != NULL)  {lpdsb_Aux->Stop();}
   if (lpdsb_Head != NULL) {lpdsb_Head->Stop();}
}

void DoublePlayer::CuePause()
{
   if (lpdsb_CueAux != NULL)  {lpdsb_CueAux->Stop();}
   if (lpdsb_CueHead != NULL) {lpdsb_CueHead->Stop();}
}

void DoublePlayer::Pitch(int iPosition)
{
    if (Mastertempo == TRUE)
    {      
       float TC = (float) iPosition;
	   TC = TC/10;
       pSoundTouch.setTempoChange(TC);
	}
	else
	{
        DWORD dwFrequency = pwfx.nSamplesPerSec + pwfx.nSamplesPerSec/1000*iPosition;
        if (lpdsb_Aux != NULL){lpdsb_Aux->SetFrequency(dwFrequency);}
        if (lpdsb_Head != NULL){lpdsb_Head->SetFrequency(dwFrequency);}
	}
}

void DoublePlayer::Aux_Volume(int iVolume)
{
   if (lpdsb_Aux != NULL){lpdsb_Aux->SetVolume(iVolume);}
   if (lpdsb_CueAux != NULL){lpdsb_CueAux->SetVolume(iVolume);}
}

void DoublePlayer::Head_Volume(int iVolume)
{
   if (lpdsb_Head != NULL){lpdsb_Head->SetVolume(iVolume);}
   if (lpdsb_CueHead != NULL){lpdsb_CueHead->SetVolume(iVolume);}
}


/****************************************************************************
Hier wird das prim�re DirectSoundobject angelegt/initialisiert.
*****************************************************************************/

DSBasicObject::Init(HWND Handle, LPGUID lpGuid)
{

    if (DSERR_NODRIVER != DirectSoundCreate(lpGuid, &lpds, NULL))
    {
      lpds->SetCooperativeLevel(Handle,DSSCL_PRIORITY); // Kooperationsebene setzen

      // Spezifizierung der ben�tigten Flags
      dsbdesc.dwSize = sizeof( DSBUFFERDESC );
      dsbdesc.dwFlags = DSBCAPS_PRIMARYBUFFER;
      dsbdesc.dwReserved = 0;
      dsbdesc.dwBufferBytes = 0;
      dsbdesc.lpwfxFormat = NULL;

      // Beschreibung des einzustellenden Waveformates 16-Bit 44 Khz
      wfm.wFormatTag = WAVE_FORMAT_PCM;          //Standard Wave-Format
      wfm.nChannels = 2;                         // Stereo
      wfm.nSamplesPerSec = 44100;                // Samplerate
      wfm.wBitsPerSample = 16;                   // Bits pro Sample
      wfm.nBlockAlign = (WORD) (wfm.wBitsPerSample / 8 * wfm.nChannels);
      wfm.nAvgBytesPerSec = wfm.nSamplesPerSec * wfm.nBlockAlign;  // 176400 bytes/sec

      lpds->CreateSoundBuffer(&dsbdesc,&lpdsbPrimary, NULL); //prim�ren Soundbuffer erstellen
      lpdsbPrimary->SetFormat(&wfm); // setzen des eingestellten WaveFormates
      // Hardwaremixer in Dauerbetrieb schalten wegen DMA-Latenz bei ISA-Soundkarten
      lpdsbPrimary->Play ( 0, 0, DSBPLAY_LOOPING);
      // Win2000 Workaround 
	  memset( &dsbdescSecWin2000, 0, sizeof( DSBUFFERDESC ) );
	  dsbdescSecWin2000.dwSize        = sizeof( DSBUFFERDESC );
	  dsbdescSecWin2000.dwFlags       = DSBCAPS_CTRLFREQUENCY
                           | DSBCAPS_GETCURRENTPOSITION2
                           | DSBCAPS_GLOBALFOCUS
                           | DSBCAPS_CTRLPAN
                           | DSBCAPS_CTRLVOLUME;
      dsbdescSecWin2000.dwReserved    = 0;
	  dsbdescSecWin2000.dwBufferBytes = 176400 ; // Buffer f�r 1 Sekunde;
	  dsbdescSecWin2000.lpwfxFormat   = &wfm;
      lpds->CreateSoundBuffer(&dsbdescSecWin2000,&lpdsbSecWin2000, NULL); //Sek Soundbuffer erstellen
      // Sekund�ren Buffer in Dauerbetrieb schalten wegen Win2000 DirectX-Bug
      lpdsbSecWin2000->Play ( 0, 0, DSBPLAY_LOOPING);
    }
}

DSBasicObject::Delete()
{
   lpdsbPrimary->Stop();      // Prim�ren DSBuffer stoppen
   lpds->Release();           // DSObject freigeben
}


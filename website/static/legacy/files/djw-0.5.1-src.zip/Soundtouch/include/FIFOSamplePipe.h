/*****************************************************************************
 *
 * 'FIFOSamplePipe' : An abstract base class for classes that manipulate sound
 * samples by operating like a first-in-first-out pipe: New samples are fed
 * into one end of the pipe with the 'putSamples' function, and the processed
 * samples are received from the other end with the 'receiveSamples' function.
 *
 * 'FIFOProcessor' : A base class for signal processing classes operating like
 * a first-in-first-out pipe. When samples are inputted with the 'putSamples' 
 * function, the class processes them and moves the processed samples to the 
 * given 'output' pipe object, which may be either another processing stage
 * or a fifo buffer object.
 *
 * Author        : Copyright (c) Olli Parviainen 2002
 * Author e-mail : oparviai@iki.fi
 * File created  : 13-Jan-2002
 * Last modified : 13-Jan-2002
 *
 * License :
 *
 *  This file is part of SoundTouch sound processing library.
 *
 *  SoundTouch is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  SoundTouch is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SoundTouch; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/

#ifndef FIFOSamplePipe_H
#define FIFOSamplePipe_H

#include <assert.h>
#include <stdlib.h>
#include "STTypes.h"

class FIFOSamplePipe
{
public:
    // Returns a pointer to the location of the output buffer where the samples
    // haven't been outputted yet. This function is provided for accessing the 
    // output samples directly. Please be careful!
    //
    // When using this function to output samples, also remember to remove the
    // used samples from the buffer by calling the 'receiveSamples(numsamples)' 
    // function
    virtual short *ptrBegin() const = 0;

    // Adds 'numSamples' pcs of samples from the 'samples' memory position to
    // the sample buffer.
    virtual void putSamples(const short *samples, const uint numSamples) = 0;

    // Moves samples from the 'other' pipe object to this object by copying and
    // then removing all the samples from the 'other' object.
    void moveSamples(FIFOSamplePipe &other)
    {
        int oNumSamples = other.numSamples();

        putSamples(other.ptrBegin(), oNumSamples);
        other.receiveSamples(oNumSamples);
    };

    // Output samples from the object. Copies requested number samples to 
    // 'outBuffer' and removes them from the object's output buffer. If there 
    // are less than 'numsample' samples available, outputs all available 
    // samples.
    //
    // Returns number of samples copied.
    virtual uint receiveSamples(short *output, const uint maxSamples) = 0;

    // Removes samples from the output of the object without copying them 
    // anywhere. This function is used to reduce the number of samples in 
    // the object when accessing the object's output buffer directly with 
    // the 'ptrBegin' function.
    virtual uint receiveSamples(const uint maxSamples) = 0;

    // Returns number of samples currently available for outputting.
    virtual uint numSamples() const = 0;

    // Returns nonzero if there aren't any samples available for outputting.
    virtual int isEmpty() const = 0;

    // Clears all the samples in the object
    virtual void clear() = 0;
};



class FIFOProcessor :public FIFOSamplePipe
{
protected:
    FIFOSamplePipe *output;

    void setOutPipe(FIFOSamplePipe *pOutput)
    {
        assert(output == NULL);
        assert(pOutput != NULL);
        output = pOutput;
    }


    FIFOProcessor()
    {
        output = NULL;
    }


    FIFOProcessor(FIFOSamplePipe *pOutput)
    {
        output = pOutput;
    }


    virtual ~FIFOProcessor()
    {
    }


    virtual short *ptrBegin() const
    {
        return output->ptrBegin();
    }

public:

    // Output samples from the object. Copies requested number samples to 
    // 'outBuffer' and removes them from the object's output buffer. If there 
    // are less than 'numsample' samples available, outputs all available 
    // samples.
    //
    // Returns number of samples copied.
    virtual uint receiveSamples(short *outBuffer, const uint maxSamples)
    {
        return output->receiveSamples(outBuffer, maxSamples);
    }


    // Removes samples from the output of the object without copying them 
    // anywhere. This function is used to reduce the number of samples in 
    // the object when accessing the object's output buffer directly with 
    // the 'ptrBegin' function.
    virtual uint receiveSamples(const uint maxSamples)
    {
        return output->receiveSamples(maxSamples);
    }


    // Returns the number of samples currently available in the object for 
    // outputting.
    virtual uint numSamples() const
    {
        return output->numSamples();
    }


    // Returns nonzero if there aren't any samples available for outputting.
    virtual int isEmpty() const
    {
        return output->isEmpty();
    }
};

#endif

/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "mixerdlg.h"

DlgMixer::DlgMixer(HINSTANCE hCopyLibrary)
{
   GetCurrentDirectory(MAX_PATH, IniPath);
   strcat(IniPath,"\\djw.ini");
   hdlg              = NULL;
   pfnOldbtLeftProc  = NULL;
   pfnOldbtRightProc = NULL;
   hBtLeft           = NULL;
   hBtRight          = NULL;
   PlayerLinks       = NULL;
   PlayerRechts      = NULL;
  // Load Language-dll
  CommActive = false;
  char szLanguage[MAX_PATH];
  GetPrivateProfileString("MainWnd","Language", "leng.dll", szLanguage, MAX_PATH,IniPath);
  hLibrary = hCopyLibrary;
  LoadString(hLibrary, IDS_HELPPATH, HelpPath,10);
  FILE *Test = fopen(HelpPath,"r");
  if (Test == NULL) strcpy(HelpPath, "djw_e.hlp");
  else fclose(Test);

}

void DlgMixer::OnCreate(ndw_DataBase* DataBaseCopy)
{
  DataBase = DataBaseCopy;
  hdlg = CreateDialogParam(hLibrary, TEXT ("MIXERDLG"), NULL,(DLGPROC) MixerDlgProc, (LPARAM)this);
  WinPlayList       = new PlayList(hdlg, hLibrary);
  return;
}


DlgMixer::~DlgMixer()
{
  delete WinPlayList;
  DestroyWindow(hdlg);
}

DWORD WINAPI DlgMixer::StaticThreadRoutine(PVOID pParam)
{
  DlgMixer * pObject;

  pObject=(DlgMixer*)GetWindowLong((HWND)pParam,DWL_USER);
  return pObject->ThreadRoutine();
}
 
DWORD DlgMixer::ThreadRoutine()
{
  DWORD dwEvtMask;
  DWORD e;
  unsigned long nBytesRead = 0;
  char tempBuffer [2048] ="";
  char inBuffer [2058] ="";
  char chBefehl [14] ="";
  int iinBuffer = 0;
  int ichBefehl = 0;
  COMSTAT ComStat;
  while (!Terminated)
  {
	if (WaitCommEvent(hCom, &dwEvtMask, NULL)) 
	{
		if (dwEvtMask & EV_RXCHAR) 
		{//Zeichen wurden empfangen
			if(ClearCommError(hCom, &e, &ComStat))
            {//Teste auf Fehler
				if (ComStat.cbInQue > 0)
				{//Daten stehen im Eingangspuffer + \r +\n
					//Lese 40 bytes vom serielle Puffer in lokalen Puffer
					strset(inBuffer, '\0'); //L�sche vorher den Puffer
					strset(tempBuffer, '\0'); //L�sche vorher den Puffer
					iinBuffer =0;           //Und setze Ihn auf Null
  					ReadFile(hCom, &tempBuffer, 40, &nBytesRead, NULL);//&o);
                    strcpy(inBuffer, chBefehl);
					strcat(inBuffer, tempBuffer);
					ichBefehl = 0;           //Und setze Ihn auf Null
					
                  while ((inBuffer[iinBuffer] != '\0') & (iinBuffer < 41))
					{						
                       if (inBuffer[iinBuffer] != '\n')
					   {
							chBefehl[ichBefehl] = inBuffer[iinBuffer];
					   }
					   else
					   {
       						strset(chBefehl, '\0');
							ichBefehl = 0;
					   }

						if ((ichBefehl > 0) & (strncmp(chBefehl, "Pitch_A=", 8)) & (strncmp(chBefehl, "Pitch_A=", 8)))
						{
							if ((chBefehl[ichBefehl] == '2') & (chBefehl[ichBefehl-1] == '2'))
							{//Taste #
					            SCROLLINFO info;
								memset(&info,0,sizeof(SCROLLINFO));
								info.cbSize = sizeof(SCROLLINFO);
								info.fMask = SIF_ALL;
								::GetScrollInfo(PlayerLinks->hSBarSeek, SB_CTL, &info);
								PlayerLinks->SBarSeekScroll((int)SB_LINERIGHT, (int)::GetScrollPos(PlayerLinks->hSBarSeek, SB_CTL), info.nTrackPos);
            					strset(chBefehl, '\0');
								ichBefehl = 0;

							}
							if ((chBefehl[ichBefehl] == '0') & (chBefehl[ichBefehl-1] == '0'))
							{ //Taste *
								SCROLLINFO info;
								memset(&info,0,sizeof(SCROLLINFO));
								info.cbSize = sizeof(SCROLLINFO);
								info.fMask = SIF_ALL;
								::GetScrollInfo(PlayerLinks->hSBarSeek, SB_CTL, &info);
								PlayerLinks->SBarSeekScroll((int)SB_LINELEFT, (int)::GetScrollPos(PlayerLinks->hSBarSeek, SB_CTL), info.nTrackPos);
            					strset(chBefehl, '\0');
								ichBefehl = 0;
							}
						}

						if (strncmp(chBefehl, "Pitch_A=", 8)==0)
						{
							char *PitchWert = NULL;;
                            PitchWert = strrchr(chBefehl, '\r');
							if (PitchWert != NULL)
							{
								PitchWert = strrchr(chBefehl, '=')+1;
								int iPitch = atoi(PitchWert);							 
								SendMessage(PlayerLinks->_hwnd, WM_VSCROLL, MAKEWPARAM(SB_THUMBPOSITION,iPitch) ,(LPARAM) PlayerLinks->hSBarPitch);
								SendMessage(PlayerLinks->_hwnd, WM_VSCROLL, MAKEWPARAM(SB_THUMBTRACK,iPitch) ,(LPARAM) PlayerLinks->hSBarPitch);
			   					strset(chBefehl, '\0');
								ichBefehl = 0;
							}
						}
						if (strncmp(chBefehl, "Pitch_B=", 8)==0)
						{
							char *PitchWert = NULL;
                            PitchWert = strrchr(chBefehl, '\r');
							if (PitchWert != NULL)
							{
								PitchWert = strrchr(chBefehl, '=')+1;
								int iPitch = atoi(PitchWert);						
								SendMessage(PlayerRechts->_hwnd, WM_VSCROLL, MAKEWPARAM(SB_THUMBPOSITION,iPitch) ,(LPARAM) PlayerRechts->hSBarPitch);
								SendMessage(PlayerRechts->_hwnd, WM_VSCROLL, MAKEWPARAM(SB_THUMBTRACK,iPitch) ,(LPARAM) PlayerRechts->hSBarPitch);
	           					strset(chBefehl, '\0');
								ichBefehl = 0;
							}
						}
						if (strcmp(chBefehl, "12\r")==0)
						{
							PlayerLeftPlay(); //Taste 1
           					strset(chBefehl, '\0');
							ichBefehl = 0;
						}
						if (strcmp(chBefehl, "13\r")==0)
						{
							PlayerLeftCue(); //Taste 2
           					strset(chBefehl, '\0');
							ichBefehl = 0;
						}
						if (strcmp(chBefehl, "14\r")==0)
						{
							PlayerLeftLoad(); //Taste 3
           					strset(chBefehl, '\0');
							ichBefehl = 0;
						}
						if (strcmp(chBefehl, "8\r")==0)
						{
							PlayerRightPlay(); //Taste 6
           					strset(chBefehl, '\0');
							ichBefehl = 0;
						}
						if (strcmp(chBefehl, "9\r")==0)
						{
							PlayerRightCue(); //Taste 5
           					strset(chBefehl, '\0');
							ichBefehl = 0;
						}
						if (strcmp(chBefehl, "10\r")==0)
						{
							PlayerRightLoad(); //Taste 4
           					strset(chBefehl, '\0');
							ichBefehl = 0;
						}
						iinBuffer++;
						ichBefehl++;
                    } //while i Verarbeitung
				
				}//if (ComStat.cbInQue > 0)
			}//if(ClearCommError(hCom, &e, &ComStat))
			
		}//if (dwEvtMask & EV_RXCHAR) 
	} //if (WaitCommEvent(hCom, &dwEvtMask, NULL)) 
  } //While !Terminated
  return 0;
}
void DlgMixer::CloseRemote()
{
	if (CommActive)
	{ 
		Terminated = true;
		SuspendThread(hThread);
        TerminateThread(hThread,0);
		CloseHandle(hThread);
		CloseHandle(hCom);
		CommActive = false;
        MessageBox(hdlg,(LPCTSTR) "Com-Port und Thread wurden geschlossen",
                  (LPCTSTR) "Information", MB_ICONWARNING );
	}
}

void DlgMixer::InitRemote(LPSTR lpzCommPort)
{
	hCom = CreateFile(lpzCommPort,
				GENERIC_READ,
				0,    // exclusive access 
				NULL, // no security attributes 
				OPEN_EXISTING,
				0,//FILE_FLAG_OVERLAPPED,
				NULL
				);
	if (hCom == INVALID_HANDLE_VALUE) 
	{
       MessageBox(hdlg,(LPCTSTR) "Dieser Com-Port scheint besetzt zu sein - Init fehlgeschlagen",
                  (LPCTSTR) lpzCommPort, MB_ICONWARNING );
	   CommActive = false;
	}
	else
	{
		CommActive = true;  
		SetupComm(hCom, 2048,1024);
		DCB dcb;
		dcb.DCBlength = sizeof(dcb);	
		GetCommState(hCom, &dcb); //Aktuelle Konfiguration lesen
		// �bertragungsparameter setzen
		dcb.BaudRate         = 9600 ;
		dcb.ByteSize         = 8 ;
		dcb.Parity           = NOPARITY ;
		dcb.StopBits         = ONESTOPBIT ;
		dcb.fDsrSensitivity  = FALSE ;
		dcb.fDtrControl      = DTR_CONTROL_DISABLE;
		dcb.fRtsControl      = RTS_CONTROL_DISABLE;
		dcb.fOutxCtsFlow     = FALSE ;
		dcb.fOutxDsrFlow     = FALSE ;
		dcb.fOutX = dcb.fInX = FALSE ;
		dcb.fBinary          = TRUE ;
		SetCommState(hCom, &dcb);
//		DWORD modem_status;
		//Modemstatus lesen und auf Sender warten
//		GetCommModemStatus(hCom, &modem_status);
		COMMTIMEOUTS timeouts;
		timeouts.ReadIntervalTimeout = MAXDWORD; 
		timeouts.ReadTotalTimeoutMultiplier = MAXDWORD ;
		timeouts.ReadTotalTimeoutConstant = MAXDWORD-1;
		timeouts.WriteTotalTimeoutMultiplier = 0;
		timeouts.WriteTotalTimeoutConstant = 0;
		SetCommTimeouts(hCom, &timeouts);
		SetCommMask(hCom, EV_RXCHAR);			
		Terminated = false;
		hThread = CreateThread(NULL,0,StaticThreadRoutine,(LPVOID)hdlg,CREATE_SUSPENDED ,&dwThreadId);
		ResumeThread(hThread);
        MessageBox(hdlg,(LPCTSTR) "Com-Port und Thread wurden erfolgreich ge�ffnet",
                  (LPCTSTR) "Information", MB_ICONWARNING );
	}
}




void DlgMixer::ShowDialog()
{
  MoveWindow(hdlg,GetPrivateProfileInt("Mixer","Left", 0,IniPath),
                  GetPrivateProfileInt("Mixer","Top", 0,IniPath) ,280, 170, TRUE);
  ShowWindow(hdlg, SW_SHOW);
}


void DlgMixer::HideDialog()
{
  ShowWindow(hdlg, SW_HIDE);
}

void DlgMixer::slCrossfaderScroll(int iScrollPos)
{
  if (iScrollPos > 0)
     {
       PlayerLinks->AuxVolume(iScrollPos);
       PlayerRechts->AuxVolume(0);
     }
  if (iScrollPos < 0)
     {
       PlayerLinks->AuxVolume(0);
       PlayerRechts->AuxVolume(-iScrollPos);
     }
  if (iScrollPos == 0)
     {
       PlayerLinks->AuxVolume(iScrollPos);
       PlayerRechts->AuxVolume(iScrollPos);
     }
}

void DlgMixer::SetDataBase()
{
   char   szPath[260]   = "";
   if (WinPlayList->_hwnd != NULL)
   {
      if (WinPlayList->GetListBoxCount() > 0)
      {
        strcpy(szPath, WinPlayList->GetSongPath(WinPlayList->GetPlayPos()));
        DataBase->SetActiveIndex("Path");
        DataBase->FindPath(szPath);
        WinPlayList->SetPlayPos(WinPlayList->GetPlayPos()+1);
        if ((WinPlayList->GetPlayPos()) > (WinPlayList->GetListBoxCount()-1)){WinPlayList->SetPlayPos(0);}
       }
   }
}

void DlgMixer::StartPlayer_Left()
{
  PlayerLinks->btLoadClick();
  PlayerLinks->Play();
}

void DlgMixer::StartPlayer_Right()
{
  PlayerRechts->btLoadClick();
  PlayerRechts->Play();
}

void DlgMixer::AutoPlayTimer()
{
  if (PlayerLinks != NULL)
  {
    if ((PlayerRechts->DSPlayer.FastEnde == TRUE) && (PlayerLinks->GetPlayStatus() != TRUE))
    {
      if (SendDlgItemMessage(hdlg, ID_CBOX_AUTOFADE, BM_GETCHECK, 0,0) == BST_CHECKED)
	  {
        BlendToRight = FALSE;
	    BlendToLeft  = TRUE;
        SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)3000);
        SendMessage(hdlg,  WM_HSCROLL, MAKELONG(SB_THUMBPOSITION, 3000),(LPARAM)hslCrossfader);
        SetTimer(hdlg, 20, 100, NULL);
	  }
      SetDataBase();
	  StartPlayer_Left();
      return;
    }
   }
  
  if (PlayerRechts != NULL)
  {
    if ((PlayerLinks->DSPlayer.FastEnde == TRUE) && ( PlayerRechts->GetPlayStatus() != TRUE))
    {
      if (SendDlgItemMessage(hdlg, ID_CBOX_AUTOFADE, BM_GETCHECK, 0,0) == BST_CHECKED)
	  {
        BlendToRight = TRUE;
	    BlendToLeft  = FALSE;
        SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)-3000);
        SendMessage(hdlg,  WM_HSCROLL, (unsigned int)MAKELONG(SB_THUMBPOSITION, -3000),(LPARAM)hslCrossfader);
        SetTimer(hdlg, 20, 100, NULL);
	  }
      SetDataBase();
	  StartPlayer_Right();
      return;
    }
  }
}

void DlgMixer::AutoFadeTimer()
{
  int i = SendMessage(hslCrossfader, TBM_GETPOS,0,0);
  int iTime = SendDlgItemMessage(hdlg, ID_UD_FADETIME, UDM_GETPOS, 0, 0)*10;
  int iRange = SendMessage(hslCrossfader, TBM_GETRANGEMAX, 0, 0) - SendMessage(hslCrossfader, TBM_GETRANGEMIN, 0, 0);
  if (iTime == 0) iTime++; // Prevent a div with Zero 
  div_t t = div(iRange, iTime); 
  
  if ((SendDlgItemMessage(hdlg, ID_CBOX_AUTOFADE, BM_GETCHECK, 0,0) == BST_CHECKED) && (iTime != 1))
  {
	  if (BlendToRight == TRUE)
      {
          SendMessage(hdlg,  WM_HSCROLL, (unsigned int)MAKELONG(SB_THUMBPOSITION,
			  SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)i + t.quot)),(LPARAM)hslCrossfader);
          if (i  == SendMessage(hslCrossfader, TBM_GETRANGEMAX, 0, 0))
          {
            EnableWindow(GetDlgItem(hdlg, ID_BTFADE), TRUE);
            PlayerLinks->Cue();
            KillTimer(hdlg, 20);
		  }
      }
	  if (BlendToLeft == TRUE)
      {
          SendMessage(hdlg,  WM_HSCROLL, (unsigned int)MAKELONG(SB_THUMBPOSITION,
			  SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)i-t.quot)),(LPARAM)hslCrossfader);
          if (i  == SendMessage(hslCrossfader, TBM_GETRANGEMIN, 0, 0))
          {
            EnableWindow(GetDlgItem(hdlg, ID_BTFADE), TRUE);
            PlayerRechts->Cue();
            KillTimer(hdlg, 20);
		  }
      }
  }
  else
  {
	  if (BlendToRight == TRUE)
      {
          SendMessage(hdlg,  WM_HSCROLL, (unsigned int)MAKELONG(SB_THUMBPOSITION,
			  SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)SendMessage(hslCrossfader, TBM_GETRANGEMAX, 0, 0))),(LPARAM)hslCrossfader);
          EnableWindow(GetDlgItem(hdlg, ID_BTFADE), TRUE);
          PlayerLinks->Cue();
          KillTimer(hdlg, 20);
      }
	  if (BlendToLeft == TRUE)
      {
          SendMessage(hdlg,  WM_HSCROLL, (unsigned int)MAKELONG(SB_THUMBPOSITION,
			  SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)SendMessage(hslCrossfader, TBM_GETRANGEMIN, 0, 0))),(LPARAM)hslCrossfader);
          EnableWindow(GetDlgItem(hdlg, ID_BTFADE), TRUE);
          PlayerRechts->Cue();
          KillTimer(hdlg, 20);
      }

  }
}


BOOL DlgMixer::DialogEvents(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
     int i;
     switch (message)
     {
       case WM_INITDIALOG:
            hBtLeft       = GetDlgItem(hDlg,ID_BTLEFT);
            hBtRight      = GetDlgItem(hDlg,ID_BTRIGHT);
            hslCrossfader = GetDlgItem(hDlg,ID_TB_CROSSFADER);
            SendMessage(hslCrossfader, TBM_SETRANGE, TRUE, MAKELONG(-3000, 3000));
            SendMessage(hslCrossfader, TBM_SETLINESIZE,0,10);
            SendMessage(hslCrossfader, TBM_SETPAGESIZE,0,100);
            SendMessage(hslCrossfader, TBM_SETPOS,TRUE, 0);           
            SendDlgItemMessage(hDlg, ID_UD_PLAYSTART, UDM_SETBUDDY, (WPARAM) GetDlgItem(hDlg, ID_ED_PLAYSTART), 0);
            SendDlgItemMessage(hDlg, ID_UD_PLAYSTART, UDM_SETRANGE, 0, (LPARAM) MAKELONG(0, 100));
            SendDlgItemMessage(hDlg, ID_UD_PLAYSTART, UDM_SETPOS, 0, (LPARAM) MAKELONG(GetPrivateProfileInt("Mixer", "Playstart", 7, IniPath), 0));
            SendDlgItemMessage(hDlg, ID_UD_FADETIME, UDM_SETBUDDY, (WPARAM) GetDlgItem(hDlg, ID_ED_FADETIME), 0);
            SendDlgItemMessage(hDlg, ID_UD_FADETIME, UDM_SETRANGE, 0, (LPARAM) MAKELONG(0, 100));
            SendDlgItemMessage(hDlg, ID_UD_FADETIME, UDM_SETPOS, 0, (LPARAM) MAKELONG(GetPrivateProfileInt("Mixer", "Fadetime", 5, IniPath), 0));
            pfnOldbtLeftProc  = (FARPROC)::SetWindowLong(hBtLeft, GWL_WNDPROC, (LONG)btLeftProc);
            pfnOldbtRightProc = (FARPROC)::SetWindowLong(hBtRight, GWL_WNDPROC, (LONG)btRightProc);
            return TRUE ;
       case WM_HELP:
            WinHelp(hDlg, HelpPath,HELP_CONTEXT, 70);
            return TRUE ;

       case WM_COMMAND :
            switch (LOWORD (wParam))
            {
              case ID_MIXBTZERO:
                   SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)0);
                   SendMessage(hdlg,  WM_HSCROLL, MAKELONG(SB_THUMBPOSITION, 0),(LPARAM)hslCrossfader);
				   return TRUE ;

              case ID_BTFADE:
                   if (PlayerRechts->GetPlayStatus() != TRUE)
				   {
                      SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)-3000);
                      SendMessage(hdlg,  WM_HSCROLL, (unsigned int)MAKELONG(SB_THUMBPOSITION, -3000),(LPARAM)hslCrossfader);
                      SetDataBase();
	                  StartPlayer_Right();
					  BlendToRight = TRUE;
					  BlendToLeft  = FALSE;
                      SetTimer(hdlg, 20, 100, NULL);
					  EnableWindow(GetDlgItem(hdlg, ID_BTFADE), FALSE);
	                  return TRUE ;
    			   }
                   if (PlayerLinks->GetPlayStatus() != TRUE)
				   {
                      SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)3000);
                      SendMessage(hdlg,  WM_HSCROLL, MAKELONG(SB_THUMBPOSITION, 3000),(LPARAM)hslCrossfader);
                      SetDataBase();
	                  StartPlayer_Left();
					  BlendToRight = FALSE;
					  BlendToLeft  = TRUE;
                      SetTimer(hdlg, 20, 100, NULL);
	                  return TRUE ;
    			   }
                   return TRUE ;
              case ID_CB_PLAYERLEFT:
                   if (HIWORD(wParam) == CBN_CLOSEUP)
                   {
                     i = SendDlgItemMessage(hdlg, ID_CB_PLAYERLEFT, CB_GETCURSEL,0,0);
                     PlayerLinks = (PlayerWnd *)(void *)SendDlgItemMessage(hdlg, ID_CB_PLAYERLEFT, CB_GETITEMDATA, i, 0);
                   }
                   return TRUE ;
              case ID_CB_PLAYERRIGHT:
                   if (HIWORD(wParam) == CBN_CLOSEUP)
                   {
                     i = SendDlgItemMessage(hdlg, ID_CB_PLAYERRIGHT, CB_GETCURSEL,0,0);
                     PlayerRechts = (PlayerWnd *)SendDlgItemMessage(hdlg, ID_CB_PLAYERRIGHT, CB_GETITEMDATA, i, 0);
                   }
                   return TRUE ;
              case ID_ED_PLAYSTART:
                   if (HIWORD(wParam) == EN_CHANGE)
                   {
                     if ((SendDlgItemMessage(hDlg, ID_UD_FADETIME, UDM_GETPOS, 0, 0) < 100) & (SendDlgItemMessage(hDlg, ID_UD_PLAYSTART, UDM_GETPOS, 0, 0) > -1))
                     {
                       if (PlayerRechts != NULL)PlayerRechts->DSPlayer.iFastEnde = SendDlgItemMessage(hDlg, ID_UD_PLAYSTART, UDM_GETPOS, 0, 0)*100;
                       if (PlayerLinks != NULL)PlayerLinks->DSPlayer.iFastEnde = SendDlgItemMessage(hDlg, ID_UD_PLAYSTART, UDM_GETPOS, 0, 0)*100;
                     }
                   }
                   return TRUE ;
              case ID_CBOX_AUTOPLAY:
                   if (SendDlgItemMessage(hdlg, ID_CBOX_AUTOPLAY,  BM_GETCHECK, 0, 0)!= BST_UNCHECKED)
                   {
                     SetTimer(hdlg, 10, 500, NULL);
                   }
                   else
                   {
                     KillTimer(hdlg, 10);
                   }
                   return TRUE ;
            }
            break ;
      case WM_TIMER:
           if (wParam == 10) AutoPlayTimer();
           if (wParam == 20) AutoFadeTimer();
           break ;

      case WM_HSCROLL:
             slCrossfaderScroll((int)SendMessage(hslCrossfader, TBM_GETPOS,0,0));
           return TRUE;
      case WM_VSCROLL:
             if ((HWND)lParam == GetDlgItem(hDlg, ID_UD_PLAYSTART))
             {
               if (PlayerRechts->DSPlayer.loaded == true)PlayerRechts->DSPlayer.iFastEnde = SendDlgItemMessage(hDlg, ID_UD_PLAYSTART, UDM_GETPOS, 0, 0)*100;
               if (PlayerRechts->DSPlayer.loaded == true)PlayerLinks->DSPlayer.iFastEnde = SendDlgItemMessage(hDlg, ID_UD_PLAYSTART, UDM_GETPOS, 0, 0)*100;
             }
           return TRUE;
       case WM_DESTROY :
            ::SetWindowLong(hBtLeft,DWL_DLGPROC,(LONG)pfnOldbtLeftProc);
            ::SetWindowLong(hBtRight,DWL_DLGPROC,(LONG)pfnOldbtRightProc);
            return TRUE ;
     }
     return FALSE ;
}

LRESULT DlgMixer::btLeftEvents(UINT message, WPARAM wParam, LPARAM lParam)
{
     switch (message)
     {
       case WM_LBUTTONDOWN:
            SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)-3000);
            SendMessage(hdlg,  WM_HSCROLL, (unsigned int)MAKELONG(SB_THUMBPOSITION, -3000),(LPARAM)hslCrossfader);
          return ::CallWindowProc((WNDPROC)pfnOldbtLeftProc, hBtLeft, message, wParam, lParam);
       case WM_RBUTTONDOWN:
            SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)-3000);
            SendMessage(hdlg,  WM_HSCROLL, (unsigned int) MAKELONG(SB_THUMBPOSITION, -3000),(LPARAM)hslCrossfader);
            return ::CallWindowProc((WNDPROC)pfnOldbtLeftProc, hBtLeft, message, wParam, lParam);
       case WM_RBUTTONUP:
            SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)0);
            SendMessage(hdlg,  WM_HSCROLL, (unsigned int) MAKELONG(SB_THUMBPOSITION, 0),(LPARAM)hslCrossfader);
            return ::CallWindowProc((WNDPROC)pfnOldbtLeftProc, hBtLeft, message, wParam, lParam);
     }

   return ::CallWindowProc((WNDPROC)pfnOldbtLeftProc, hBtLeft, message, wParam, lParam);
}

LRESULT DlgMixer::btRightEvents(UINT message, WPARAM wParam, LPARAM lParam)
{
     switch (message)
     {
       case WM_LBUTTONDOWN:
            SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)3000);
            SendMessage(hdlg,  WM_HSCROLL, MAKELONG(SB_THUMBPOSITION, 3000),(LPARAM)hslCrossfader);
          return ::CallWindowProc((WNDPROC)pfnOldbtRightProc, hBtRight, message, wParam, lParam);
       case WM_RBUTTONDOWN:
            SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)3000);
            SendMessage(hdlg,  WM_HSCROLL, MAKELONG(SB_THUMBPOSITION, 3000),(LPARAM)hslCrossfader);
            return ::CallWindowProc((WNDPROC)pfnOldbtRightProc, hBtRight, message, wParam, lParam);
       case WM_RBUTTONUP:
            SendMessage(hslCrossfader,  TBM_SETPOS, TRUE, (LPARAM)0);
            SendMessage(hdlg,  WM_HSCROLL, MAKELONG(SB_THUMBPOSITION, 0),(LPARAM)hslCrossfader);
            return ::CallWindowProc((WNDPROC)pfnOldbtRightProc, hBtRight, message, wParam, lParam);
     }

   return ::CallWindowProc((WNDPROC)pfnOldbtRightProc, hBtRight, message, wParam, lParam);
}

LRESULT CALLBACK DlgMixer::btLeftProc(HWND hDlg, UINT Message,WPARAM wParam,LPARAM lParam)
{
  DlgMixer * pObject;
  pObject=(DlgMixer*)GetWindowLong((HWND)GetWindowLong(hDlg,GWL_HWNDPARENT), DWL_USER);

  if (pObject) // sicherheitshalber nachfragen....
    return pObject->btLeftEvents(Message,wParam,lParam);
  else
   return(::CallWindowProc((WNDPROC)pObject->pfnOldbtLeftProc, hDlg, Message, wParam, lParam));
}

LRESULT CALLBACK DlgMixer::btRightProc(HWND hDlg, UINT Message,WPARAM wParam,LPARAM lParam)
{
  DlgMixer * pObject;
  pObject=(DlgMixer*)GetWindowLong((HWND)GetWindowLong(hDlg,GWL_HWNDPARENT), DWL_USER);

  if (pObject) // sicherheitshalber nachfragen....
    return pObject->btRightEvents(Message,wParam,lParam);
  else
   return(::CallWindowProc((WNDPROC)pObject->pfnOldbtRightProc, hDlg, Message, wParam, lParam));
}



BOOL CALLBACK DlgMixer::MixerDlgProc (HWND hDlg, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
  DlgMixer *pObject;
  if (message == WM_INITDIALOG)
  {
    SetWindowLong(hDlg,DWL_USER,lParam);
    pObject=(DlgMixer*)GetWindowLong(hDlg,DWL_USER);
  }
  else // Alle anderen Messages
  {
    pObject=(DlgMixer*)GetWindowLong(hDlg,DWL_USER);
  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->DialogEvents(hDlg, message, wParam, lParam);
  else
    return DefWindowProc(hDlg,message,wParam,lParam);
}


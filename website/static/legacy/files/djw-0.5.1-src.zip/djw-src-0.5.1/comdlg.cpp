/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "comdlg.h"

DlgCom::DlgCom(HINSTANCE hCopyLibrary)
{
  GetCurrentDirectory(MAX_PATH, IniPath);
  strcat(IniPath, "\\djw.ini");
  LoadString(hCopyLibrary, IDS_HELPPATH, HelpPath,10);
  FILE *Test = fopen(HelpPath,"r");
  if (Test == NULL) strcpy(HelpPath, "djw_e.hlp");
  else fclose(Test);
}

DlgCom::~DlgCom()
{
}

void DlgCom::GetData(HWND hDlg1)
{
  GetDlgItemText(hDlg1, ID_CB_SELECT_COM, lpString, 9);//sizeof(lpString));
  WritePrivateProfileString("Devices","Comport", lpString,IniPath); 
}

void DlgCom::TestExistingComPorts(HWND hDlg1)
{
	char s[6] = "";
	DWORD i;
	COMMCONFIG CommConfig;
    GetPrivateProfileString("Devices","Comport", "COM1", s, 10,IniPath);
	SendDlgItemMessage(hDlg1, ID_CB_SELECT_COM, WM_SETTEXT, 0,(LPARAM) (LPCTSTR) s);
    
	for (int CommPort = 0; CommPort < 10; CommPort++)
	{
		strcpy(s, "COMx");
		s[3] = (char)(0x31+CommPort);
		i    = sizeof(CommConfig);
		if (GetDefaultCommConfig(s, &CommConfig, &i))
		{
			SendDlgItemMessage(hDlg1, ID_CB_SELECT_COM, CB_ADDSTRING, 0,(LPARAM) (LPCTSTR) s);
		}
	}
}

                
BOOL DlgCom::DialogEvents(HWND hDlg, UINT message, WPARAM wParam)

{
     switch (message)
     {
     case WM_INITDIALOG:
           //Sende Initialisierenden Text in die Combobox
			  TestExistingComPorts(hDlg);
          return TRUE ;
     case WM_HELP :
//          WinHelp(hDlg, HelpPath,HELP_CONTEXT, 90);
          return TRUE ;

     case WM_COMMAND :
          switch (LOWORD (wParam))
          {
          case IDOK :
               GetData(hDlg);
               EndDialog (hDlg, 1) ;
               return TRUE ;

          case IDCANCEL :
               EndDialog (hDlg, 0) ;
               return TRUE ;

          case IDHELP :
               //WinHelp(hDlg, HelpPath,HELP_CONTEXT, 90);
               return TRUE ;
          }
          break ;
     }
     return FALSE ;
}


BOOL CALLBACK DlgCom::ComDlgProc (HWND hDlg, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
  DlgCom *pObject;

  if (message == WM_INITDIALOG)
  {
    SetWindowLong(hDlg,DWL_USER,lParam);
    pObject=(DlgCom*)GetWindowLong(hDlg,DWL_USER);
  }
  else // Alle anderen Messages
  {
    pObject=(DlgCom*)GetWindowLong(hDlg,DWL_USER);
  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->DialogEvents(hDlg, message, wParam);
  else
    return DefWindowProc(hDlg,message,wParam,lParam);

}


//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Editor.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormEditor *FormEditor;
//---------------------------------------------------------------------------
__fastcall TFormEditor::TFormEditor(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormEditor::FormShow(TObject *Sender)
{
  DataModule1->AfterPost = true;
}
//---------------------------------------------------------------------------

void __fastcall TFormEditor::FormClose(TObject *Sender,
      TCloseAction &Action)
{
  DataModule1->AfterPost = false;
}
//---------------------------------------------------------------------------


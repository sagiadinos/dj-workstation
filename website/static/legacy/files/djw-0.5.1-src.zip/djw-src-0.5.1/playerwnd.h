/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#ifndef PlayerWndH
#define PlayerWndH
//---------------------------------------------------------------------------
#include "database.h"
#include "DSUtil.h"
#include <shellapi.h> 
#include <commctrl.h> //danach weil in scandlg.h windows.h definiert wird
#include "resource.h"

#define PressPlus  2
#define PressMinus 3

class PlayerWnd
{
public:
                  PlayerWnd(HINSTANCE hCopyLibrary);
                 ~PlayerWnd();
//                  PlayerWnd(const PlayerWnd& other){}; //Copy-Constructor
                  PlayerWnd operator= (PlayerWnd& other)
				  {
				    if (this != &other)
					{
					} 
					return *this;
				   };
          void    Init(HWND Mixer, ndw_DataBase* DataBaseCopy);
          void    btLoadClick();
          BOOL    Show(HWND hParent, HINSTANCE hInstance, LPDIRECTSOUND _Prim_Aux, LPDIRECTSOUND _Prim_Head, int ixPos, int iyPos,
                            int iWidth, int iHeight, char *lpzCaption, BOOL bo_checked, BOOL bo_elapsed, BOOL Mastertempo);
          void    Play(){SendMessage(hBtPlay, WM_LBUTTONDOWN, 0, 0);}
          void    Cue(){SendMessage(hBtCue, WM_LBUTTONDOWN, 0, 0);}
          HWND    GetWndHandle(){return _hwnd;}
          void    AuxVolume(int iScrollPos){SendMessage(_hwnd, WM_VSCROLL, MAKELONG(SB_THUMBPOSITION, iScrollPos),(LPARAM)hSBarVolume);}
          void    DisplayTime();
          void    SBarSeekScroll(int iScrollCode, int iScrollPos, int iScrollPosMouse);
          BOOL    GetPlayStatus()
          {
              char   lbStatus[10]   = "";
              int i = SendMessage(hSTextStatus, WM_GETTEXTLENGTH,0,0);
              SendMessage(hSTextStatus, WM_GETTEXT,(WPARAM)i+1, (LPARAM) lbStatus);
              if (strcmp(lbStatus, "playing") == 0) return TRUE;
              else return FALSE;
          }
//          void    SetStatus(char* status){;}
   bool           inited;
   DoublePlayer   DSPlayer; //Das DirectSound Playerobject
   char           szClassCaption[11];
   BOOL           elapse;            // Ob die Zeitanzeige r�ckw�rts l�uft
   HWND           hSBarSeek;
   HWND           hCbAutoCue;
   HWND          _hwnd;
   HWND           hSBarPitch;
   HWND           hBtPlus;
   HWND           hBtMinus;
   int            TimerCount;

private:
          void    DestroyItems();
          void    SetControls();
          void    btTimeClick();
          void    SBarPitchScroll(int iScrollCode, int iScrollPos, int iScrollPosMouse);
          void    SBarVolumeScroll(int iScrollCode, int iScrollPos, int iScrollPosMouse);
          void    SBarHeadVolumeScroll(int iScrollCode, int iScrollPos, int iScrollPosMouse);
          void    MoveControls(int iWidth, int iLength);
          void    OnDropFile(HDROP hDropFile);
          void    DrawBtPlay(LPDRAWITEMSTRUCT lpdis);
          void    DrawBtCue(LPDRAWITEMSTRUCT lpdis);
          LRESULT Events(UINT message, WPARAM wParam, LPARAM lParam);
   static VOID    CALLBACK TimeProc(UINT uID,UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2);
          VOID    TimerEvents(UINT uID,UINT uMsg, DWORD dw1, DWORD dw2);
   static LRESULT CALLBACK PlayerWndProc(HWND hWnd, UINT message,WPARAM wParam,LPARAM lParam);
          LRESULT ListBoxEvents(UINT message, WPARAM wParam, LPARAM lParam);
   static LRESULT CALLBACK btMinusProc(HWND hWnd, UINT message,WPARAM wParam,LPARAM lParam);
   static LRESULT CALLBACK btPlusProc(HWND hWnd, UINT message,WPARAM wParam,LPARAM lParam);
          LRESULT btMinusEvents(UINT message, WPARAM wParam, LPARAM lParam);
          LRESULT btPlusEvents(UINT message, WPARAM wParam, LPARAM lParam);
   static LRESULT CALLBACK btPlayProc(HWND hWnd, UINT message,WPARAM wParam,LPARAM lParam);
   static LRESULT CALLBACK btCueProc(HWND hWnd, UINT message,WPARAM wParam,LPARAM lParam);
          LRESULT btPlayEvents(UINT message, WPARAM wParam, LPARAM lParam);
          LRESULT btCueEvents(UINT message, WPARAM wParam, LPARAM lParam);


   HBRUSH         hGreenBrush;
   HBRUSH         hRedBrush;
		  
   LPDIRECTSOUND  Prim_Aux;
   LPDIRECTSOUND  Prim_Head;
   ndw_DataSet    DataSet;
   ndw_DataBase   *DataBase;
   FARPROC        pfnOldbtMinusProc;
   FARPROC        pfnOldbtPlusProc;
   FARPROC        pfnOldbtPlayProc;
   FARPROC        pfnOldbtCueProc;
   char           Name[12];
   BOOL           HeadCue;           // Ob Kopfh�rer-Funktion Aktiviert ist
   HBITMAP        hLED_ON;
   HBITMAP        hLED_OFF;
   HINSTANCE      hLibrary;
   TIMECAPS       ptc;
   UINT           uPeriod;
   UINT           idTimer;
   HACCEL         hAccel;
   HWND           hBtPlay;
   HWND           hBtCue;
   HWND           hSBarHeadVolume;
   HWND           hSBarVolume;
   HWND           hSTextStatus;
   HWND           hBtHeadCue;
   HWND           hBtLoad;
   HWND           hBtZero;
   HWND           hBtTime;
   HWND           hFrameTime;
   HWND           hSplitter;
   HWND           hFrameInfo;
   HWND           hSTextPitch;
   HWND           hSTextPitchPer;
   HWND           hSTextHead;
   HWND           hSTextVolume;
   HWND           hSTextArtist;
   HWND           hSTextSong;
   HWND           hDlgMixer;
   HFONT          hFontLoad;
   HFONT          hFontPM;
   HFONT          hFontCue;
   HFONT          hFontTime;
   HFONT          hFontZero;
   HFONT          hFontText;
   HWND           hSTextTime;
   HBRUSH         hBrush;
   UINT           TimerEvent;
   WNDCLASSEX    _class;
   HMENU          hFirstMenu;
   HMENU          hMenu;
   HBITMAP        hPlayUp;
   HBITMAP        hPlayDown;
   HBITMAP        hCueUp;
   HBITMAP        hCueDown;
   char           IniPath[260];
   char           HelpPath[10];
protected:
/*                 void CopyAll(PlayerWnd& other)
                 {
                      inited = other.inited;
                      DSPlayer  = other.DSPlayer; //Das DirectSound Playerobject
                      Prim_Aux  = other.Prim_Aux;
                      Prim_Head = other.Prim_Head;
                      DataSet   = other.DataSet;
                      DataBase  = other.DataBase;
                      pfnOldbtMinusProc = other.pfnOldbtMinusProc;
                      pfnOldbtPlusProc  = other.pfnOldbtPlusProc;
                      pfnOldbtPlayProc  = other.pfnOldbtPlayProc;
                      pfnOldbtCueProc  = other.pfnOldbtCueProc;
                      strcpy(Name,other.Name);
                      elapse   = other.elapse;            // Ob die Zeitanzeige r�ckw�rts l�uft
                      HeadCue  = other.HeadCue;           // Ob Kopfh�rer-Funktion Aktiviert ist
                      hLED_ON  = other.hLED_ON;
                      hLED_OFF = other.hLED_OFF;
                      hLibrary = other.hLibrary;
                      ptc = other.ptc;
                      uPeriod = other.uPeriod;
                      idTimer = other.idTimer;
                      hAccel  = other.hAccel;
                      _hwnd = other._hwnd;
                      hBtPlay = other.hBtPlay;
                      hBtCue = other.hBtCue;
                      hSBarVolume = other.hSBarVolume;
                      hSTextStatus= other.hSTextStatus;
                      hCbAutoCue= other.hCbAutoCue;
                      hBtHeadCue= other.hBtHeadCue;
                      hBtLoad= other.hBtLoad;
                      hBtZero= other.hBtZero;
                      hBtPlus= other.hBtPlus;
                      hBtMinus= other.hBtMinus;
                      hBtTime= other.hBtTime;
                      hSBarPitch= other.hSBarPitch;
                      hSBarSeek= other.hSBarSeek;
                      hFrameTime= other.hFrameTime;
                      hSplitter= other.hSplitter;
                      hFrameInfo= other.hFrameInfo;
                      hFrameInfo= other.hSTextPitch;
                      hSTextPitchPer= other.hSTextPitchPer;
                      hSTextHead= other.hSTextHead;
                      hSTextVolume= other.hSTextVolume;
                      hSTextArtist= other.hSTextArtist;
                      hSTextSong= other.hSTextSong;
                      hDlgMixer= other.hDlgMixer;
                      hFontLoad= other.hFontLoad;
                      hFontPM= other.hFontPM;
                      hFontCue= other.hFontCue;
                      hFontTime= other.hFontTime;
                      hSTextTime= other.hSTextTime;
                      hFontZero= other.hFontZero;
                      hFontText= other.hFontText;
                      hBrush= other.hBrush;
                      TimerEvent= other.TimerEvent;
                      _class= other._class;
                      hMenu= other.hMenu;
                      hPlayUp= other.hPlayUp;
                      hPlayDown= other.hPlayDown;
                      hCueUp= other.hCueUp;
                      hCueDown= other.hCueDown;
                      strcpy(IniPath, other.IniPath);
                      strcpy(szClassCaption, other.szClassCaption);
                    }

*/};
//---------------------------------------------------------------------------
#endif

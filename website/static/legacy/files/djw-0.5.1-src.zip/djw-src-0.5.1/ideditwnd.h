/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#ifndef ideditwndH
#define ideditwndH

#include "database.h"
#include <windows.h>
//#define STRICT
#include "resource.h"
#include <commctrl.h>


class IdEdit
{
public:
                   IdEdit(ndw_DataBase* DataBaseCopy, HINSTANCE hCopyLibrary);
                  ~IdEdit();
   static LRESULT  CALLBACK IdEditProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
          void     Show(HWND hParent, HINSTANCE hInstance);

private:
          void     SetControls();
          void     SetEditControl(int x, int y);
          void     MoveControls(int iWidth, int iLength);
          void     EditChange();
          LRESULT  ListViewNotify(LPARAM lParam);
          LRESULT  Events(UINT message, WPARAM wParam, LPARAM lParam);
   static LRESULT  CALLBACK ListViewProc(HWND hWnd, UINT Message,WPARAM wParam,LPARAM lParam);
          LRESULT  ListViewEvents(UINT Message, WPARAM wParam, LPARAM lParam);
   static LRESULT  CALLBACK EditProc(HWND hWnd, UINT Message,WPARAM wParam,LPARAM lParam);
          LRESULT  EditEvents(UINT Message, WPARAM wParam, LPARAM lParam);

   HWND          _hwnd;
   ndw_DataBase   *DataBase;
   HWND           hListView;
   HINSTANCE      hLibrary;
   ndw_DataSet    DataSet;
   WNDCLASS      _class;
   HINSTANCE      hinst;
   char           WriteField[31];
   int            iMaxEdit;
   HFONT          hFont_Normal;
   HWND           ParentHandle;
   HWND           hEdit;
   BOOL           ChangeEdit;
   BOOL           ChangeListView;
   BOOL           boShift;
   FARPROC        pfnOldListViewProc;
   FARPROC        pfnOldEditProc;
   int            iListViewPos;
   int            iListViewCol;
   char           HelpPath[10];
};

//---------------------------------------------------------------------------
#endif

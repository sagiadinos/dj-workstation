/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/

#include "devicedlg.h"

DlgDevice::DlgDevice(HINSTANCE hCopyLibrary)
{
  hLibrary = hCopyLibrary;
  LoadString(hLibrary, IDS_HELPPATH, HelpPath,10);
  FILE *Test = fopen(HelpPath,"r");
  if (Test == NULL) strcpy(HelpPath, "djw_e.hlp");
  else fclose(Test);
  GetCurrentDirectory(MAX_PATH, IniPath);
  strcat(IniPath, "\\djw.ini");
  iDeviceCount = 0;
  for (int i = 0; i< 20; i++)
  {
    hCBDevice[i] = NULL;
    hSSDevice[i] = NULL;
  }
   hFont        = CreateFont(-11, 0, 0, 0, FW_NORMAL, FALSE, FALSE,	FALSE, ANSI_CHARSET,
                           OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                           DEFAULT_PITCH | FF_DONTCARE, "MS Sans Serif" );
}

DlgDevice::~DlgDevice()
{
  iDeviceCount = 0;
  DeleteObject(hFont);
}

BOOL CALLBACK DlgDevice::EnumCallback(LPGUID lpGuid, LPCSTR lpcstrDescription, LPCSTR, LPVOID hwnd)
{
  DlgDevice *pObject;
  pObject=(DlgDevice *)GetWindowLong((HWND)hwnd,DWL_USER);
  return pObject->SoundCallback(lpGuid, lpcstrDescription);
}

BOOL DlgDevice::SoundCallback(LPGUID lpGuid,LPCSTR lpcstrDescription)
{

  OLECHAR lpsz[128];
  char  lpstr[128]  = "";

  if ( lpGuid != NULL )
  {
    iDeviceCount++;
    lDevice.push_back((char *)lpcstrDescription);
    StringFromGUID2(*lpGuid, (LPOLESTR)lpsz, sizeof(lpsz));
    for (int i=0; i<128; i++){lpstr[i]= (char) lpsz[i];}
    WritePrivateProfileString("present Devices",lpcstrDescription, lpstr, IniPath);
  }
  return TRUE;
}

BOOL DlgDevice::WriteIni()
{
 char lpString[50];

 char sMode[3];
 WritePrivateProfileString("Devices","Mode", itoa(iMode, sMode, 10), IniPath);
 WritePrivateProfileString("Devices","Count", itoa(iDeviceCount, sMode, 10), IniPath);

 for (int i = 0; i< iDeviceCount; i++)
 {
   if (hCBDevice[i] != NULL)
   {
     char szCard[11]  = "Card_";
     char szNumber[4] = "";
     itoa(i, szNumber, 10);
     strcat(szCard, szNumber);
     SendMessage(hCBDevice[i], WM_GETTEXT, 49, (LPARAM) lpString);
     WritePrivateProfileString("Devices",szCard, lpString, IniPath);
   };
 }
 return TRUE;
}

void DlgDevice::ClearBoxes()
{
  for (int i = 0; i< iDeviceCount; i++)
  {
    if (hCBDevice[i] != NULL)
    {
       DestroyWindow(hCBDevice[i]);
       hCBDevice[i] = NULL;
    };
    if (hSSDevice[i] != NULL)
    {
       DestroyWindow(hSSDevice[i]);
       hSSDevice[i] = NULL;
    };
  }
  DestroyWindow(hBtOK); 
  DestroyWindow(hBtCancel); 
  DestroyWindow(hBtHelp); 
}

void DlgDevice::SetOnlyOne(HWND hDlg)
{

  ClearBoxes();
  int iHeight = 40;
  SetWindowPos(hDlg, HWND_TOP,  300, 300, 245, 95 + iHeight + 50, SWP_NOMOVE);
  int iyPos = 0;
  iyPos = 85;
  char szResource[50] = "";
  LoadString(hLibrary, IDS_CHOOSE_DEVICE, szResource, 50);

  hSSDevice[0]  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("STATIC"), szResource, SS_SIMPLE | WS_CHILD | WS_VISIBLE,
                             5, iyPos-16, 180, 16, hDlg, NULL,NULL,NULL);
  hCBDevice[0]  = CreateWindowEx(WS_EX_CLIENTEDGE | WS_EX_NOPARENTNOTIFY, TEXT("COMBOBOX"),"", CBS_DROPDOWN | WS_TABSTOP | WS_CHILD | WS_VISIBLE,
                             5, iyPos, 220, 121, hDlg, NULL,NULL,NULL);
  SendMessage(hCBDevice[0], WM_SETFONT, (WPARAM)hFont, TRUE);
  SendMessage(hSSDevice[0], WM_SETFONT, (WPARAM)hFont, TRUE);
  b = lDevice.begin();
  char sDevName[50] ="";
  GetPrivateProfileString("Devices","Card_0","", sDevName, 49,IniPath);
  if (strcmp(sDevName, "") == 0){SendMessage(hCBDevice[0], WM_SETTEXT, 0, (LPARAM) (LPCTSTR) *b);}
  else {SendMessage(hCBDevice[0], WM_SETTEXT, 0, (LPARAM) (LPCTSTR) sDevName);}
  do
  {
    SendMessage(hCBDevice[0], CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) *b);
    b++;
  }
  while (b!= lDevice.end());

  LoadString(hLibrary, IDS_OK, szResource, 50);
  hBtOK     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               5, iyPos+40, 60, 25, hDlg, (HMENU)IDOK, NULL, NULL);
  SendMessage(hBtOK, WM_SETFONT, (WPARAM)hFont, TRUE);

  LoadString(hLibrary, IDS_CANCEL, szResource, 50);
  hBtCancel     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                                80, iyPos+40, 60, 25, hDlg, (HMENU)IDCANCEL, NULL, NULL);
  SendMessage(hBtCancel, WM_SETFONT, (WPARAM)hFont, TRUE);

  LoadString(hLibrary, IDS_HELP,  szResource, 50);
  hBtHelp     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               155, iyPos+40, 60, 25, hDlg, (HMENU)IDHELP, NULL, NULL);
  SendMessage(hBtHelp, WM_SETFONT, (WPARAM)hFont, TRUE);
}


void DlgDevice::SetAuxHead(HWND hDlg)
{

  ClearBoxes();
  int iHeight = 40 * 2;
  SetWindowPos(hDlg, HWND_TOP,  300, 300, 245, 95 + iHeight + 50, SWP_NOMOVE);
  int iyPos = 0;

  for (int i = 0; i < 2; i++)
  {
    iyPos = (i * 40) + 85;
    char szPlayer[12] = "Player ";
    char PlayerCount[4] = "";
    itoa(i, PlayerCount, 10);
    strcat(szPlayer, PlayerCount);
    hSSDevice[i]  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("STATIC"),szPlayer, SS_SIMPLE | WS_CHILD | WS_VISIBLE,
                               5, iyPos-16, 180, 16, hDlg, NULL,NULL,NULL);
    hCBDevice[i]  = CreateWindowEx(WS_EX_CLIENTEDGE | WS_EX_NOPARENTNOTIFY, TEXT("COMBOBOX"),"", CBS_DROPDOWN | WS_TABSTOP | WS_CHILD | WS_VISIBLE,
                               5, iyPos, 220, 121, hDlg, NULL,NULL,NULL);
    SendMessage(hCBDevice[i], WM_SETFONT, (WPARAM)hFont, TRUE);
    SendMessage(hSSDevice[i], WM_SETFONT, (WPARAM)hFont, TRUE);
    char szCard[11]  = "Card_";
    char szNumber[4] = "";
    itoa(i, szNumber, 10);
    strcat(szCard, szNumber);
    char lpString[50] = "";
    GetPrivateProfileString("Devices",szCard,"", lpString, 49,IniPath);  
	SendMessage(hCBDevice[i], WM_SETTEXT, 0, (LPARAM) (LPCTSTR) lpString);  
	b = lDevice.begin();
    do
    {
      SendMessage(hCBDevice[i], CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) *b);
      b++;
    }
    while (b!= lDevice.end());
  }
  b = lDevice.begin();
  SendMessage(hCBDevice[0], WM_SETTEXT, 0, (LPARAM) (LPCTSTR) *b);
  b++;
  SendMessage(hCBDevice[1], WM_SETTEXT, 0, (LPARAM) (LPCTSTR) *b);
  char szResource[50] = "";
  LoadString(hLibrary, IDS_DEVICE_AUX,  szResource, 50);
  SendMessage(hSSDevice[0], WM_SETTEXT, 0, (LPARAM)(LPCTSTR) szResource);
  LoadString(hLibrary, IDS_DEVICE_HEAD,  szResource, 50);
  SendMessage(hSSDevice[1], WM_SETTEXT, 0, (LPARAM)(LPCTSTR)szResource);

  LoadString(hLibrary, IDS_OK, szResource, 50);
  hBtOK     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               5, iyPos+40, 60, 25, hDlg, (HMENU)IDOK, NULL, NULL);
  SendMessage(hBtOK, WM_SETFONT, (WPARAM)hFont, TRUE);

  LoadString(hLibrary, IDS_CANCEL, szResource, 50);
  hBtCancel     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                                80, iyPos+40, 60, 25, hDlg, (HMENU)IDCANCEL, NULL, NULL);
  SendMessage(hBtCancel, WM_SETFONT, (WPARAM)hFont, TRUE);

  LoadString(hLibrary, IDS_HELP,  szResource, 50);
  hBtHelp     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               155, iyPos+40, 60, 25, hDlg, (HMENU)IDHELP, NULL, NULL);
  SendMessage(hBtHelp, WM_SETFONT, (WPARAM)hFont, TRUE);
}

void DlgDevice::SetPerPlayer(HWND hDlg)
{

  ClearBoxes();
  int iHeight = 40 * (iDeviceCount);
  SetWindowPos(hDlg, HWND_TOP,  300, 300, 245, 95 + iHeight + 50, SWP_NOMOVE);
  int iyPos = 0;
  for (int i = 0; i < iDeviceCount; i++)
  {
    iyPos = (i * 40) + 85;
    char szPlayer[12] = "Player ";
    char PlayerCount[4] = "";
    itoa(i, PlayerCount, 10);
    strcat(szPlayer, PlayerCount);
    hSSDevice[i]  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("STATIC"),szPlayer, SS_SIMPLE | WS_CHILD | WS_VISIBLE,
                               5, iyPos-16, 180, 16, hDlg, NULL,NULL,NULL);
    hCBDevice[i]  = CreateWindowEx(WS_EX_CLIENTEDGE | WS_EX_NOPARENTNOTIFY, TEXT("COMBOBOX"),"", CBS_DROPDOWN | WS_TABSTOP | WS_CHILD | WS_VISIBLE,
                               5, iyPos, 220, 121, hDlg, NULL,NULL,NULL);
    SendMessage(hCBDevice[i], WM_SETFONT, (WPARAM)hFont, TRUE);
    SendMessage(hSSDevice[i], WM_SETFONT, (WPARAM)hFont, TRUE);
    char szCard[11]  = "Card_";
    char szNumber[4] = "";
    itoa(i, szNumber, 10);
    strcat(szCard, szNumber);
    char lpString[50] = "";
    GetPrivateProfileString("Devices",szCard,"", lpString, 49,IniPath);  
	SendMessage(hCBDevice[i], WM_SETTEXT, 0, (LPARAM) (LPCTSTR) lpString);
    b = lDevice.begin();
    do
    {
      SendMessage(hCBDevice[i], CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) *b);
      b++;
    }
    while (b!= lDevice.end());
  }

  char szResource[50] = "";
  LoadString(hLibrary, IDS_OK, szResource, 50);
  hBtOK     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               5, iyPos+40, 60, 25, hDlg, (HMENU)IDOK, NULL, NULL);
  SendMessage(hBtOK, WM_SETFONT, (WPARAM)hFont, TRUE);

  LoadString(hLibrary, IDS_CANCEL, szResource, 50);
  hBtCancel     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                                80, iyPos+40, 60, 25, hDlg, (HMENU)IDCANCEL, NULL, NULL);
  SendMessage(hBtCancel, WM_SETFONT, (WPARAM)hFont, TRUE);

  LoadString(hLibrary, IDS_HELP,  szResource, 50);
  hBtHelp     = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                               155, iyPos+40, 60, 25, hDlg, (HMENU)IDHELP, NULL, NULL);
  SendMessage(hBtHelp, WM_SETFONT, (WPARAM)hFont, TRUE);
}

void DlgDevice::InitDialog(HWND hDlg)
{
  // Call DSoundEnumerate-Callback to get devies
  DirectSoundEnumerate((LPDSENUMCALLBACK) EnumCallback, hDlg);

  TCHAR lpString[50]  = "";
  TCHAR Devices[50]       = "";
  TCHAR Count[3]          = "";

  SendDlgItemMessage(hDlg, IDSS_DEVICECOUNT, WM_GETTEXT, 50, (LPARAM) Devices);
  itoa(iDeviceCount, Count, 10);
  strcat(Devices, " ");
  strcat(Devices, Count);
  SendDlgItemMessage(hDlg, IDSS_DEVICECOUNT, WM_SETTEXT, 0, (LPARAM) Devices);
  iMode = GetPrivateProfileInt("Devices","Mode", 0, IniPath);
  switch (iMode)
  {
    case 0:
         SendDlgItemMessage(hDlg, IDRB_ONLYONE, BM_SETCHECK, BST_CHECKED, 0);//Check Checkbox Onlyone
         SetOnlyOne(hDlg);
         GetPrivateProfileString("Devices","Card_0","", lpString, 49,IniPath);
         SendMessage(hCBDevice[0],WM_SETTEXT, 0, (LPARAM)lpString);
         break;

    case 1:
         SendDlgItemMessage(hDlg, IDRB_AUX_HEAD, BM_SETCHECK, BST_CHECKED, 0);//Check Checkbox Onlyone
         SetAuxHead(hDlg);
         GetPrivateProfileString("Devices","Card_0","", lpString, 49,IniPath);
         SendMessage(hCBDevice[0],WM_SETTEXT, 0, (LPARAM)lpString);
         GetPrivateProfileString("Devices","Card_1","", lpString, 49,IniPath);
         SendMessage(hCBDevice[1],WM_SETTEXT, 0, (LPARAM)lpString);
         break;


    case 2:
         SendDlgItemMessage(hDlg, IDRB_PER_PLAYER, BM_SETCHECK, BST_CHECKED, 0);//Check Checkbox Onlyone
         SetPerPlayer(hDlg);
         for (int i = 0; i < iDeviceCount; i++)
         {
           char szCard[11]  = "Card_";
           char szNumber[4] = "";
           itoa(i, szNumber, 10);
           strcat(szCard, szNumber);
           GetPrivateProfileString("Devices",szCard,"", lpString, 49,IniPath);
           SendMessage(hCBDevice[i],WM_SETTEXT, 0, (LPARAM)lpString);
         }
         break;
  }

  //If there is only one sound device present, disable components and set OnlyOne permanent checked
  if (iDeviceCount < 2)
  {
    SetOnlyOne(hDlg);
    SendDlgItemMessage(hDlg, IDRB_ONLYONE, BM_SETCHECK, BST_CHECKED, 0);//Check Checkbox Onlyone
    EnableWindow(GetDlgItem(hDlg,IDRB_AUX_HEAD), FALSE);                //Enable Checkbox
    EnableWindow(GetDlgItem(hDlg,IDRB_PER_PLAYER), FALSE);              //Enable Checkbox
  }

}

BOOL DlgDevice::DialogEvents(HWND hDlg, UINT message, WPARAM wParam)
{

     switch (message)
     {
       case WM_INITDIALOG:
             InitDialog(hDlg);
            //Sende Initialisierenden Text in die Comboboxen
            return TRUE ;
       case WM_HELP:
            WinHelp(hDlg, HelpPath,HELP_CONTEXT, 40);
            return TRUE ;

       case WM_COMMAND :
            switch (LOWORD (wParam))
            {
              case IDOK:
                   WriteIni();
                   EndDialog (hDlg, 1);
                   return TRUE ;

              case IDCANCEL:
                   EndDialog (hDlg, 0) ;
                   return TRUE ;

              case IDRB_ONLYONE:
                   SetOnlyOne(hDlg);
                   iMode = 0;
                   return FALSE ;

              case IDRB_AUX_HEAD:
                   SetAuxHead(hDlg);
                   iMode = 1;
                   return FALSE ;

              case IDRB_PER_PLAYER:
                   SetPerPlayer(hDlg);
                   iMode = 2;
                   return FALSE ;

              case IDHELP :
                   WinHelp(hDlg, HelpPath,HELP_CONTEXT, 40);
                   return TRUE ;
            }
            break ;
     }
     return FALSE ;
}



BOOL CALLBACK DlgDevice::DeviceDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
  DlgDevice *pObject;
  if (message == WM_INITDIALOG)
  {
 //   pObject = (DlgDevice*)(((CREATESTRUCT FAR*)lParam)->lpCreateParams);
    SetWindowLong(hDlg,DWL_USER,lParam);
    pObject=(DlgDevice*)GetWindowLong(hDlg,DWL_USER);
  }
  else // Alle anderen Messages
  {
    pObject=(DlgDevice*)GetWindowLong(hDlg,DWL_USER);
  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->DialogEvents(hDlg, message, wParam);
  else
    return DefWindowProc(hDlg,message,wParam,lParam);
//  return reinterpret_cast < DlgDlgDevice* >( lParam)->DialogEvents( hDlg, message, wParam);
}


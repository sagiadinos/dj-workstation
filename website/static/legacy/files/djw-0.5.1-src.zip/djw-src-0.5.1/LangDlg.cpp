/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "LangDlg.h"

DlgLanguage::DlgLanguage(HINSTANCE hCopyLibrary)
{
  GetCurrentDirectory(MAX_PATH, IniPath);
  strcat(IniPath, "\\djw.ini");
  LoadString(hCopyLibrary, IDS_HELPPATH, HelpPath,10);
  FILE *Test = fopen(HelpPath,"r");
  if (Test == NULL) strcpy(HelpPath, "djw_e.hlp");
  else fclose(Test);
}

DlgLanguage::~DlgLanguage()
{
}

void DlgLanguage::GetData(HWND hDlg1)
{
  GetDlgItemText(hDlg1, IDCB_LANGUAGE, lpString, 9);//sizeof(lpString));
  if (strcmp(lpString, "English")==0)
  {
    WritePrivateProfileString("MainWnd","Language", "leng.dll",IniPath);
  }
  if (strcmp(lpString, "Deutsch")==0)
  {
    WritePrivateProfileString("MainWnd","Language", "lger.dll",IniPath);
  }
  if (strcmp(lpString, "Fran�ais")==0)
  {
    WritePrivateProfileString("MainWnd","Language", "lfra.dll",IniPath);
  }
  if (strcmp(lpString, "Italiano")==0)
  {
    WritePrivateProfileString("MainWnd","Language", "lita.dll",IniPath);
  }
  if (strcmp(lpString, "Espaniol")==0)
  {
    WritePrivateProfileString("MainWnd","Language", "lesp.dll",IniPath);
  }
}
                

BOOL DlgLanguage::DialogEvents(HWND hDlg, UINT message, WPARAM wParam)
{
   FILE *Test;
   char szlPath[260];
   char szLanguage[260] = "";
     switch (message)
     {
     case WM_INITDIALOG:
           //Sende Initialisierenden Text in die Combobox
             GetCurrentDirectory(MAX_PATH, szlPath);
             strcat(szlPath, "\\leng.dll");
             Test = fopen(szlPath, "r");
             if ( Test != NULL)
             {
                SendDlgItemMessage(hDlg, IDCB_LANGUAGE, CB_ADDSTRING, 0,(LPARAM) (LPCTSTR) "English");
                fclose(Test);
             }
             GetCurrentDirectory(MAX_PATH, szlPath);
             strcat(szlPath, "\\lger.dll");
             Test = fopen(szlPath, "r");
             if ( Test != NULL)
             {
                SendDlgItemMessage(hDlg, IDCB_LANGUAGE, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) "Deutsch");
                fclose(Test);
             }
             GetCurrentDirectory(MAX_PATH, szlPath);
             strcat(szlPath, "\\lfra.dll");
             Test = fopen(szlPath, "r");
             if ( Test != NULL)
             {
                SendDlgItemMessage(hDlg, IDCB_LANGUAGE, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) "Fran�ais");
                fclose(Test);
             }
             GetCurrentDirectory(MAX_PATH, szlPath);
             strcat(szlPath, "\\lita.dll");
             Test = fopen(szlPath, "r");
             if ( Test != NULL)
             {
                SendDlgItemMessage(hDlg, IDCB_LANGUAGE, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) "Italiano");
                fclose(Test);
             }
             GetCurrentDirectory(MAX_PATH, szlPath);
             strcat(szlPath, "\\lesp.dll");
             Test = fopen(szlPath, "r");
             if ( Test != NULL)
             {
                SendDlgItemMessage(hDlg, IDCB_LANGUAGE, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR) "Espaniol");
                fclose(Test);
             }
         
             GetCurrentDirectory(MAX_PATH, szlPath);
             strcat(szlPath, "\\djw.ini");
             Test = fopen(IniPath, "r+");
             if ( Test != NULL)
			 {
				GetPrivateProfileString("MainWnd","Language", "leng.dll", szLanguage, MAX_PATH,IniPath);
                fclose(Test);
			 }
			 if (strcmp(szLanguage, "lger.dll") == 0) SendDlgItemMessage(hDlg, IDCB_LANGUAGE, WM_SETTEXT, 0, (LPARAM) (LPCTSTR) "Deutsch");
			 if (strcmp(szLanguage, "leng.dll") == 0) SendDlgItemMessage(hDlg, IDCB_LANGUAGE, WM_SETTEXT, 0, (LPARAM) (LPCTSTR) "English");
			 if (strcmp(szLanguage, "lfra.dll") == 0) SendDlgItemMessage(hDlg, IDCB_LANGUAGE, WM_SETTEXT, 0, (LPARAM) (LPCTSTR) "Fran�ais");
			 if (strcmp(szLanguage, "lita.dll") == 0) SendDlgItemMessage(hDlg, IDCB_LANGUAGE, WM_SETTEXT, 0, (LPARAM) (LPCTSTR) "Italiano");
			 if (strcmp(szLanguage, "lesp.dll") == 0) SendDlgItemMessage(hDlg, IDCB_LANGUAGE, WM_SETTEXT, 0, (LPARAM) (LPCTSTR) "Espaniol");

          return TRUE ;
     case WM_HELP :
          WinHelp(hDlg, HelpPath,HELP_CONTEXT, 90);
          return TRUE ;

     case WM_COMMAND :
          switch (LOWORD (wParam))
          {
          case IDOK :
               GetData(hDlg);
               EndDialog (hDlg, 1) ;
               return TRUE ;

          case IDCANCEL :
               EndDialog (hDlg, 0) ;
               return TRUE ;

          case IDHELP :
               WinHelp(hDlg, HelpPath,HELP_CONTEXT, 90);
               return TRUE ;
          }
          break ;
     }
     return FALSE ;
}


BOOL CALLBACK DlgLanguage::LanguageDlgProc (HWND hDlg, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
  DlgLanguage *pObject;

  if (message == WM_INITDIALOG)
  {
    SetWindowLong(hDlg,DWL_USER,lParam);
    pObject=(DlgLanguage*)GetWindowLong(hDlg,DWL_USER);
  }
  else // Alle anderen Messages
  {
    pObject=(DlgLanguage*)GetWindowLong(hDlg,DWL_USER);
  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->DialogEvents(hDlg, message, wParam);
  else
    return DefWindowProc(hDlg,message,wParam,lParam);
//  return reinterpret_cast < DlgLanguage* >( lParam)->DialogEvents( hDlg, message, wParam);

}


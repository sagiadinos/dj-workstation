/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#ifndef PrintPreviewH
#define PrintPreviewH

#include "database.h"
#include <shellapi.h> 
#include <commctrl.h>
#include "resource.h"


class PrintPreview
{
 public:

   PrintPreview(int iMode, ndw_DataBase* DataBaseCopy);
  ~PrintPreview();
  
   static LRESULT CALLBACK PrintPreviewProc(HWND hWnd, UINT Message,WPARAM wParam,LPARAM lParam);
          LRESULT Events(UINT message, WPARAM wParam, LPARAM lParam);
   HWND     _hwnd;
   WNDCLASS _class;
 private:
   void       PaintWindow();
   int        CalculatePrintSides();
   char       HelpPath[10];

   ndw_DataSet     DataSet;
   ndw_DataBase   *DataBase;
   int             iPrintSides;
   HWND            hStatusBar;
};

//---------------------------------------------------------------------------
#endif

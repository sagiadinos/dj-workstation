/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "printdlg.h"

DlgPrint::DlgPrint(ndw_DataBase* DataBaseCopy)
{
	DataBase = DataBaseCopy;
  
}

DlgPrint::~DlgPrint()
{
}

void DlgPrint::PickReport()
{
 switch (iMode)
 {
         case 0:// DataModule1->Table1->IndexName = "iInterpret";
                 break;
         case 1: //DataModule1->Table1->IndexName = "iTitel";
                 break;
         case 2:// DataModule1->Table1->IndexName = "iGenre";
                 break;
         case 3:// DataModule1->Table1->IndexName = "iJahr";
                 break;
  }
// DataModule1->Table1->SetKey();
}


BOOL DlgPrint::DialogEvents(HWND hDlg, UINT message, WPARAM wParam)
{

     switch (message)
     {
       case WM_INITDIALOG:
            SendDlgItemMessage(hDlg, IDRB_ARTIST, BM_SETCHECK, BST_CHECKED, 0);
            iMode = 0;
            return TRUE ;

       case WM_COMMAND :
            switch (LOWORD (wParam))
            {
              case ID_BTPRINT:
                   PickReport();
                   EndDialog (hDlg, 0) ;
                   return TRUE ;

              case ID_BTPREVIEW:
                   Preview = new PrintPreview(iMode, DataBase);
                   return TRUE ;

              case IDCANCEL:
                   EndDialog (hDlg, 0) ;
                   return TRUE ;

              case IDHELP:
                   return TRUE ;

              case IDRB_ARTIST:
                   iMode = 0;
                   return FALSE ;

              case IDRB_SONG:
                   iMode = 1;
                   return FALSE ;

              case IDRB_GENRE:
                   iMode = 2;
                   return FALSE ;

              case IDRB_YEAR:
                   iMode = 3;
                   return FALSE ;
            }
            break ;
     }
     return FALSE ;
}



BOOL CALLBACK DlgPrint::PrintDlgProc (HWND hDlg, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
  DlgPrint *pObject;
  if (message == WM_INITDIALOG)
  {
 //   pObject = (DlgDevice*)(((CREATESTRUCT FAR*)lParam)->lpCreateParams);
    SetWindowLong(hDlg,DWL_USER,lParam);
    pObject=(DlgPrint*)GetWindowLong(hDlg,DWL_USER);
  }
  else // Alle anderen Messages
  {
    pObject=(DlgPrint*)GetWindowLong(hDlg,DWL_USER);
  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->DialogEvents(hDlg, message, wParam);
  else
    return DefWindowProc(hDlg,message,wParam,lParam);
//  return reinterpret_cast < DlgDlgDevice* >( lParam)->DialogEvents( hDlg, message, wParam);
}


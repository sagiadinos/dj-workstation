/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include <windows.h>
//#define STRICT
#include "resource.h"
#include <stdio.h>


class PlayList
{
public:
                  PlayList(HWND Mixer, HINSTANCE CopyhLibrary);
                 ~PlayList();
   static LRESULT CALLBACK PlayListProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
          void    Show();
          void    AddStringToListBox(char *Artist, char *Songname, char *Path);
		  void    ClearListBox(){SendMessage(hListBox, LB_RESETCONTENT, 0, 0);}
		  int     GetListBoxCount(){return SendMessage(hListBox, LB_GETCOUNT, 0, 0);}
		  char   *GetSongPath(int PlayPos)
		  {
            return (char *)SendMessage(hListBox, LB_GETITEMDATA, PlayPos,0);
		  }		
		  int     GetPlayPos()
		  {
			  RePaintListBox(iPlayPos);
              if(GetListBoxCount() < (iPlayPos+1)) iPlayPos = 0;
			  return iPlayPos;
		  }
		  void    SetPlayPos(int NewPos)
		  {
			  RePaintListBox(iPlayPos);
			  iPlayPos = NewPos;
		      return;
		  }

   HWND _hwnd;
private:
          void    SetControls();
          void    MoveControls(int iWidth, int iLength);
          void    btSaveClick();
		  void    RePaintListBox(int idx);
          LRESULT Events(UINT message, WPARAM wParam, LPARAM lParam);
   static LRESULT CALLBACK ListBoxProc(HWND hWnd, UINT Message,WPARAM wParam,LPARAM lParam);
          LRESULT ListBoxEvents(UINT Message, WPARAM wParam, LPARAM lParam);

   int      iPlayPos;
   HFONT     hFont;
   HFONT     hFontBold;
   HWND      hListBox;
   HWND      hBtStart;
   HWND      hBtSave;
   HWND      hBtCancel;
   HWND      hBtHelp;
   HWND      hBtDelete;
   HWND      hBtUp;
   HWND      hBtDown;
   HWND      hDlgMixer;
   WNDCLASS  _class;
   HINSTANCE hinst;
   HINSTANCE hLibrary;
   char      IniPath[MAX_PATH];
   HWND      ParentHandle;
   FARPROC   pfnOldWndProc;
   int       iCountSelItems;
   BOOL      moved;
   int       iItemPoint;
   HMENU     hFirstMenu;
   HMENU     hMenu;
   char      HelpPath[10];

};

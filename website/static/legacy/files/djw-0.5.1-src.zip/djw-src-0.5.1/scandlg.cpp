/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 21-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "scandlg.h"

DlgScan::DlgScan(ndw_DataBase* DataBaseCopy, HINSTANCE hCopyLibrary)
{

  DataBase = DataBaseCopy;
  DataBase->lDataBase.resize(0);
  int iCount = DataBase->vDataBase.size();
  for (int i = 0; i < iCount; i++)
  {
    DataBase->AppendRecord(DataBase->vDataBase[i]);
  }
  LoadString(hCopyLibrary, IDS_HELPPATH, HelpPath,10);
  FILE *Test = fopen(HelpPath,"r");
  if (Test == NULL) strcpy(HelpPath, "djw_e.hlp");
  else fclose(Test);
};


//Puts the ID3-Tags's into database
void DlgScan::MP3IntoDB(char *lpzString)
{
  FILE *FileHandle;
  char *name = NULL;
  ndw_DataSet  DataSet;

  char          Tag[3] = "";
  char          Songname[30] = "";
  char          Artist[30] = "";
  char          Album[30] = "";
  char          Year[4] = "";
  char          Comment[30] = "";
  unsigned char Genre;

  if (DataBase->FindExactPath(lpzString) == -1)
  {
    FileHandle = fopen(lpzString, "rb");
    fseek(FileHandle, -128, SEEK_END);
    fread(&Tag, 3, 1, FileHandle);
    fread(&Songname, 30, 1, FileHandle);
    fread(&Artist, 30, 1, FileHandle);
    fread(&Album, 30, 1, FileHandle);
    fread(&Year, 4, 1, FileHandle);
    fread(&Comment, 30, 1, FileHandle);
    fread(&Genre, 1, 1, FileHandle);
    fclose(FileHandle);
    name = strrchr(lpzString,'\\')+1; //gets name from Path
    DataSet.EQ = 0;
    DataSet.StartTime = 0;
    DataSet.EndTime   = 0;
    DataSet.Duration  = 0;
    if ((strncmp(Tag, "TAG", 3)) == 0)
    {
       int i;
	   for (i = 29; i > -1; i--)
	   {
         if (Artist[i] == ' ') Artist[i] = '\0';
		 else break;
	   }
       strncpy(DataSet.szArtist, Artist,30);
	   DataSet.szArtist[30] = '\0';

       for (i = 29; i > -1; i--)
	   {
         if (Songname[i] == ' ') Songname[i] = '\0';
		 else break;
	   }
       strncpy(DataSet.szSongname, Songname,30);
       DataSet.szSongname[30] = '\0';

       DataSet.Beats    = 0;

       for (i = 29; i > -1; i--)
	   {
         if (Comment[i] == ' ') Comment[i] = '\0';
		 else break;
	   }
       strncpy(DataSet.szGenre,    Comment,10);
       DataSet.szGenre[10] = '\0';
     
       for (i = 3; i > -1; i--)
	   {
         if (Year[i] == ' ') Year[i] = '\0';
		 else break;
	   }
	   strncpy(DataSet.szYear,     Year,4);
       DataSet.szYear[4] = '\0';
       strcpy(DataSet.szPath,     lpzString);
       DataBase->AppendRecord(DataSet);
    }
    else
    {
       strcpy(DataSet.szArtist, name);
       strcpy(DataSet.szSongname , "");
       DataSet.Beats    = 0;
       strcpy(DataSet.szGenre    , "");
       strcpy(DataSet.szYear     , "");
       strcpy(DataSet.szPath     ,lpzString);
       DataBase->AppendRecord(DataSet);
    }
 } //Falls Index vorhanden
 return;

}

//Puts the ID3-Tags's into database
void DlgScan::OGGIntoDB(char *lpzString)
{
  FILE            *FileHandle;
  OggVorbis_File   vf;
  char            *name = NULL;
  char            v_comment[20] = "";
  ndw_DataSet      DataSet;

  if (DataBase->FindExactPath(lpzString) == -1)
  {
    name = strrchr(lpzString,'\\')+1; //gets name from Path
    
  //Initialisierung
    DataSet.EQ = 0;
    DataSet.StartTime = 0;
    DataSet.EndTime   = 0;
    DataSet.Duration  = 0;
    DataSet.Beats    = 0;
    strcpy(DataSet.szArtist, name);
    strcpy(DataSet.szSongname , "");
    DataSet.Beats    = 0;
    strcpy(DataSet.szGenre    , "");
    strcpy(DataSet.szYear     , "");
    strcpy(DataSet.szPath     ,lpzString);
    FileHandle = fopen(lpzString, "rb");
    if (ov_open(FileHandle, &vf, NULL, 0) ==0)
	{
      vorbis_comment  *vc  = ov_comment(&vf,-1);
	  for (int i = 0; i < vc->comments; i++)
	  {
     	strset(v_comment,'\0');
		strncpy(v_comment, vc->user_comments[i], strcspn(vc->user_comments[i],"="));
	    if ((strcmp(v_comment,"ARTIST")==0) | (strcmp(v_comment,"ENSEMBLE")==0) | (strcmp(v_comment,"PERFORMER")==0))
        {
          strncpy(DataSet.szArtist, strrchr(vc->user_comments[i],'=')+1,30);
          DataSet.szArtist[30] = '\0';
		}
	    if (strcmp(v_comment,"TITLE")==0)
        {
          strncpy(DataSet.szSongname, strrchr(vc->user_comments[i],'=')+1,30);
          DataSet.szSongname[30] = '\0';
		}
	    if (strcmp(v_comment,"GENRE")==0)
        {
          strncpy(DataSet.szGenre, strrchr(vc->user_comments[i],'=')+1,10);
          DataSet.szGenre[10] = '\0';
		}
	    if ((strcmp(v_comment,"DATE")==0) |(strcmp(v_comment,"YEAR")==0))
		{
  	       strncpy(DataSet.szYear,strrchr(vc->user_comments[i],'=')+1,4);
           DataSet.szYear[4] = '\0';
		}
	  }
	
      strcpy(DataSet.szPath,     lpzString);
      DataBase->AppendRecord(DataSet);

	} //Falls es wirklich ein OGG ist;
	} //Falls Index vorhanden
 return;

}

void DlgScan::WAVIntoDB(char *lpzString)
{
  char            *name = NULL;
  ndw_DataSet      DataSet;

  if (DataBase->FindExactPath(lpzString) == -1)
  {
    name = strrchr(lpzString,'\\')+1; //gets name from Path
    
  //Initialisierung
    DataSet.EQ = 0;
    DataSet.StartTime = 0;
    DataSet.EndTime   = 0;
    DataSet.Duration  = 0;
    DataSet.Beats    = 0;
    strcpy(DataSet.szArtist, name);
    strcpy(DataSet.szSongname , "");
    DataSet.Beats    = 0;
    strcpy(DataSet.szGenre    , "");
    strcpy(DataSet.szYear     , "");
    strcpy(DataSet.szPath     ,lpzString);
    DataBase->AppendRecord(DataSet);

  } //Falls Index vorhanden
 return;
}


void DlgScan::ChangeDir(char *lpzString) //Rekursive Verzeichnisssuche
{
  WIN32_FIND_DATA  ffblk;
  char lpzStringDir[MAX_PATH] = "";
  strcpy(lpzStringDir, lpzString);
  strcat(lpzStringDir, "*.*");

  HANDLE hFile = FindFirstFile(lpzStringDir, &ffblk);

  do
  {
    //Move in if it's a dir but not a System-Dir (like Recycle ...)
    if ((ffblk.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && !(ffblk.dwFileAttributes & FILE_ATTRIBUTE_SYSTEM) &&
       ((strcmp(ffblk.cFileName,".") != 0) && (strcmp(ffblk.cFileName,"..")!=0)))     //Wenn Verzeichniss
     {
       strcpy(lpzStringDir, lpzString);
       strcat(lpzStringDir,ffblk.cFileName);
       strcat(lpzStringDir,"\\");
       ChangeDir(lpzStringDir);
     }
    SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)lpzString);
    char *ext = strrchr(ffblk.cFileName,'.');
    if (ext != NULL)
    {
      ext[1] = (char) toupper(ext[1]);
      ext[2] = (char) toupper(ext[2]);
      ext[3] = (char) toupper(ext[3]);
      if (strcmp(ext, ".MP3")==0)
      {
        if (BST_CHECKED == SendDlgItemMessage(hdlg, ID_CBMP3, BM_GETCHECK, 0, 0))
		{
          strcpy(lpzStringDir, lpzString);
          strcat(lpzStringDir, ffblk.cFileName);
          SendDlgItemMessage(hdlg,ID_SSFILE, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)ffblk.cFileName);
          MP3IntoDB(lpzStringDir);
          SendDlgItemMessage(hdlg,ID_SSFILE, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"");
		}
      }
      if (strcmp(ext, ".OGG")==0)
      {
        if (BST_CHECKED == SendDlgItemMessage(hdlg, ID_CBOGG, BM_GETCHECK, 0, 0))
		{
          strcpy(lpzStringDir, lpzString);
          strcat(lpzStringDir, ffblk.cFileName);
          SendDlgItemMessage(hdlg,ID_SSFILE, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)ffblk.cFileName);
          OGGIntoDB(lpzStringDir);
          SendDlgItemMessage(hdlg,ID_SSFILE, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"");
		}
      }
      if (strcmp(ext, ".WAV")==0)
      {
        if (BST_CHECKED == SendDlgItemMessage(hdlg, ID_CBWAV, BM_GETCHECK, 0, 0))
		{
          strcpy(lpzStringDir, lpzString);
          strcat(lpzStringDir, ffblk.cFileName);
          SendDlgItemMessage(hdlg,ID_SSFILE, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)ffblk.cFileName);
          WAVIntoDB(lpzStringDir);
          SendDlgItemMessage(hdlg,ID_SSFILE, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"");
		}
      }
    }
  }
  while(FindNextFile(hFile, &ffblk) == TRUE);
  FindClose(hFile);
  return;
}


void DlgScan::CheckDB() // Testen der Datenbank ob Titel noch vorhanden
{
  list<ndw_DataSet>::iterator b = DataBase->lDataBase.begin();

  while (b != DataBase->lDataBase.end())
  {
    SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR) (*b).szPath);
    FILE *FileHandle = fopen((*b).szPath, "r");  //Open only readonly for check
    if ( FileHandle != NULL)
    {
      fclose(FileHandle);
      b++;
    }
    else {b = DataBase->lDataBase.erase(b);}
  }
  return;
}

void DlgScan::InitDialog(HWND hDlg)
{
  hdlg = hDlg;

  DataBase->SetActiveIndex("Path");

  SendDlgItemMessage(hDlg, ID_LBDIR, LB_RESETCONTENT, 0, 0);
  UINT i;
  char DriveName[4] = "C:\\";
  char DriveName2[4] = "C:\0"; 
  SendDlgItemMessage(hDlg, ID_CBMP3, BM_SETCHECK, BST_CHECKED, 0);
  SendDlgItemMessage(hDlg, ID_CBOGG, BM_SETCHECK, BST_CHECKED, 0);
  SendDlgItemMessage(hDlg, ID_CBWAV, BM_SETCHECK, BST_CHECKED, 0);
  for (char Drive = 'C'; Drive <= 'Z'; Drive++) // Alle m�glichen Laufwerke testen
  {
    DriveName[0] = Drive;
    DriveName2[0] = Drive;
    i = GetDriveType(DriveName);
    switch (i)
    {
      case DRIVE_REMOVABLE:	// Listenelement hinzuf�gen
        SendDlgItemMessage(hDlg, ID_LBDIR, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR) DriveName2);
        break;
      case DRIVE_FIXED:	// Listenelement hinzuf�gen
        SendDlgItemMessage(hDlg, ID_LBDIR, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR) DriveName2);
        break;
      case DRIVE_REMOTE:	// Listenelement hinzuf�gen
        SendDlgItemMessage(hDlg, ID_LBDIR, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR) DriveName2);
        break;
      case DRIVE_CDROM:	// Listenelement hinzuf�gen
        SendDlgItemMessage(hDlg, ID_LBDIR, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR) DriveName2);
        break;
    }
  }
}

BOOL DlgScan::DialogEvents(HWND hDlg, UINT message, WPARAM wParam)
{
   int       *ilpbuffer;
   char      *lpzString;
   int iCountSelItems, i;
     switch (message)
     {
       case WM_INITDIALOG:
            InitDialog(hDlg);
            return TRUE ;
       case WM_HELP:
            WinHelp(hDlg, HelpPath,HELP_CONTEXT, 30);
            return TRUE ;

       case WM_COMMAND :
            switch (LOWORD (wParam))
            {
              case ID_BTSCAN:
                   DataBase->SetActiveIndex("Path");
                   lpzString = new char[MAX_PATH];
                   iCountSelItems = SendDlgItemMessage(hDlg, ID_LBDIR,LB_GETSELCOUNT,0, 0); //Anzahl der markierten Items
                   ilpbuffer = new int[iCountSelItems];
                   SendDlgItemMessage(hDlg, ID_LBDIR, LB_GETSELITEMS,(WPARAM) iCountSelItems, (LPARAM)ilpbuffer);
                   for (i=0; i < iCountSelItems; i++)
                   {
                     SendDlgItemMessage(hDlg, ID_LBDIR, LB_GETTEXT, ilpbuffer[i],(LPARAM) lpzString);
                     strcat(lpzString,"\\");
                     ChangeDir(lpzString); //Rekursive Verzeichnissuchfunktion mit root
                   } // for...
                   if (DataBase->lDataBase.size() > 0)
                   {
                     SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"Erstelle Indizes");
                     DataBase->CreateIndices();
                     SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"Sortiere");
                     DataBase->Sort();
                     SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"Schreibe Dateien");
                     DataBase->WriteFiles();
                   }
                 EndDialog (hDlg, 0) ;
                 return TRUE ;

              case ID_BTCHECK:
                   CheckDB(); // Check auf Datenkonsistenz
                   if (DataBase->lDataBase.size() > 0)
                   {
                     SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"Erstelle Indizes");
                     DataBase->CreateIndices();
                     SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"Sortiere");
                     DataBase->Sort();
                     SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"Schreibe Dateien");
                     DataBase->WriteFiles();
                   }
                   EndDialog (hDlg, 0) ;
                   return TRUE ;

              case ID_BTSCANCHECK:
                   CheckDB(); // Check auf Datenkonsistenz
                   DataBase->SetActiveIndex("Path");
                   lpzString = new char[MAX_PATH];
                   iCountSelItems = SendDlgItemMessage(hDlg, ID_LBDIR,LB_GETSELCOUNT,0, 0); //Anzahl der markierten Items
                   ilpbuffer = new int[iCountSelItems];
                   SendDlgItemMessage(hDlg, ID_LBDIR, LB_GETSELITEMS,(WPARAM) iCountSelItems, (LPARAM)ilpbuffer);
                   for (i=0; i < iCountSelItems; i++)
                   {
                     SendDlgItemMessage(hDlg, ID_LBDIR, LB_GETTEXT, ilpbuffer[i],(LPARAM) lpzString);
                     strcat(lpzString,"\\");
                     ChangeDir(lpzString); //Rekursive Verzeichnissuchfunktion mit root
                   } // for...                 
				   if (DataBase->lDataBase.size() > 0)
                   {
                     SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"Erstelle Indizes");
                     DataBase->CreateIndices();
                     SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"Sortiere");
                     DataBase->Sort();
                     SendDlgItemMessage(hdlg,ID_SSDIR, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"Schreibe Dateien");
                     DataBase->WriteFiles();
                   }
                   EndDialog (hDlg, 0) ;
                   return TRUE ;

              case IDCANCEL:
                   EndDialog (hDlg, 0) ;
                   return TRUE ;

              case IDHELP:
                   WinHelp(hDlg, HelpPath,HELP_CONTEXT, 30);
                   return TRUE ;
            }
            break ;
     }
     return FALSE ;
}

BOOL CALLBACK DlgScan::ScanDlgProc (HWND hDlg, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
  DlgScan *pObject;
  if (message == WM_INITDIALOG)
  {
 //   pObject = (DlgScan*)(((CREATESTRUCT FAR*)lParam)->lpCreateParams);
    SetWindowLong(hDlg,DWL_USER,lParam);
    pObject=(DlgScan*)GetWindowLong(hDlg,DWL_USER);
  }
  else // Alle anderen Messages
  {
    pObject=(DlgScan*)GetWindowLong(hDlg,DWL_USER);
  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->DialogEvents(hDlg, message, wParam);
  else
    return DefWindowProc(hDlg,message,wParam,lParam);
//  return reinterpret_cast < DlgDlgDevice* >( lParam)->DialogEvents( hDlg, message, wParam);
}






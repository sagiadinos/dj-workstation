#include "mixer.h"

DlgMixer::DlgMixer(HWND hParent)
{
  hdlg = CreateDialogParam(NULL, TEXT ("MIXERDLG"), hParent,
  (DLGPROC) MixerDlgProc, (LPARAM)this);
}


DlgMixer::~DlgMixer()
{
}


void DlgMixer::ShowDialog()
{
  ShowWindow(hdlg, SW_SHOW);
}


void DlgMixer::HideDialog()
{
  ShowWindow(hdlg, SW_HIDE);
}


BOOL DlgMixer::DialogEvents(HWND hDlg, UINT message, WPARAM wParam)
{
     int i;
     char lpszFind[12] = "";
     switch (message)
     {
       case WM_INITDIALOG:
            return TRUE ;

       case WM_COMMAND :
            switch (LOWORD (wParam))
            {
              case IDOK:
                   return TRUE ;
              case IDCANCEL:
                   return TRUE ;
              case ID_CB_PLAYERLEFT:
                   if (HIWORD(wParam) == CBN_CLOSEUP)
                   {
                     i = SendDlgItemMessage(hdlg, ID_CB_PLAYERLEFT, CB_GETCURSEL,0,0);
                     PlayerLinks = (PlayerWnd*)SendDlgItemMessage(hdlg, ID_CB_PLAYERLEFT, CB_GETITEMDATA, i, 0);
                   }
                   return TRUE ;
              case ID_CB_PLAYERRIGHT:
                   if (HIWORD(wParam) == CBN_CLOSEUP)
                   {
                     i = SendDlgItemMessage(hdlg, ID_CB_PLAYERRIGHT, CB_GETCURSEL,0,0);
                     PlayerRechts = (PlayerWnd*)SendDlgItemMessage(hdlg, ID_CB_PLAYERRIGHT, CB_GETITEMDATA, i, 0);
                   }
                   return TRUE ;

            }
            break ;
     }
     return FALSE ;
}


BOOL CALLBACK DlgMixer::MixerDlgProc (HWND hDlg, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
  DlgMixer *pObject;
  if (message == WM_INITDIALOG)
  {
    SetWindowLong(hDlg,DWL_USER,lParam);
    pObject=(DlgMixer*)GetWindowLong(hDlg,DWL_USER);
  }
  else // Alle anderen Messages
  {
    pObject=(DlgMixer*)GetWindowLong(hDlg,DWL_USER);
  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->DialogEvents(hDlg, message, wParam);
  else
    return DefWindowProc(hDlg,message,wParam,lParam);
}


/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "playlistw.h"

PlayList::PlayList(HWND Mixer, HINSTANCE CopyhLibrary)
{
  hDlgMixer = Mixer;
  GetCurrentDirectory(MAX_PATH, IniPath);
  strcat(IniPath, "\\djw.ini");
  char szLanguage[MAX_PATH];
  GetPrivateProfileString("MainWnd","Language", "leng.dll", szLanguage, MAX_PATH,IniPath);
  hLibrary = CopyhLibrary;
  LoadString(hLibrary, IDS_HELPPATH, HelpPath,10);
  FILE *Test = fopen(HelpPath,"r");
  if (Test == NULL) strcpy(HelpPath, "djw_e.hlp");
  else fclose(Test);
  _hwnd = NULL;
  hFont     = CreateFont(-11, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET,
                             OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                             DEFAULT_PITCH | FF_DONTCARE, "MS Sans Serif" );
  hFontBold = CreateFont(-11, 0, 0, 0, FW_BLACK, FALSE, FALSE, FALSE, ANSI_CHARSET,
                             OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                             DEFAULT_PITCH | FF_DONTCARE, "MS Sans Serif" );
}

PlayList::~PlayList()
{
  _hwnd     = NULL;
  hDlgMixer = NULL;
  hLibrary  = NULL;
  DeleteObject(hFont);
  DeleteObject(hFontBold);
  hFont     = NULL;
  hFontBold = NULL;
}


void PlayList::Show()
{
   memset(&_class,0,sizeof(WNDCLASS));
  _class.style         = CS_HREDRAW | CS_VREDRAW;
  _class.lpfnWndProc   = (WNDPROC) PlayListProc;
  _class.cbClsExtra    = 0;
  _class.cbWndExtra    = sizeof(PlayList*);
  _class.hInstance     = NULL;
  _class.hIcon         = NULL;
  _class.hCursor       = NULL;
  _class.hbrBackground = (HBRUSH) GetStockObject (LTGRAY_BRUSH);
  _class.lpszClassName = "Playlist";
  ::RegisterClass(&_class);
    

	_hwnd = ::CreateWindowEx(0,"Playlist","Playlist", WS_OVERLAPPEDWINDOW,
		                    GetPrivateProfileInt("Playlist","Left", CW_USEDEFAULT,IniPath),
                            GetPrivateProfileInt("Playlist","Top", CW_USEDEFAULT,IniPath),
                            GetPrivateProfileInt("Playlist","Width", 500,IniPath),
                            GetPrivateProfileInt("Playlist","Height", 300,IniPath),
							NULL, NULL, NULL,(void FAR*)this);
  ::ShowWindow (_hwnd, SW_SHOWNORMAL );
  ::UpdateWindow (_hwnd);
}


void PlayList::SetControls()
{
	hListBox  = CreateWindowEx(WS_EX_CLIENTEDGE | WS_EX_ACCEPTFILES,TEXT("LISTBOX"), "", LBS_OWNERDRAWFIXED| WS_CHILD | LBS_NOTIFY | LBS_EXTENDEDSEL | LBS_WANTKEYBOARDINPUT | LBS_NOINTEGRALHEIGHT | LBS_HASSTRINGS | WS_VSCROLL | WS_VISIBLE | WS_TABSTOP,
                             0, 0, 400, 200, _hwnd, NULL, NULL, NULL);
//  MakeDragList(hListBox);

  hBtStart  = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"),"&Auto", BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                             0, 245, 75, 25, _hwnd, (HMENU)ID_BTSTART,NULL,NULL);
  char szResource[10] = "";
  LoadString(hLibrary, IDS_SAVE, szResource, 50);
  hBtSave   = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"), szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                             75, 245, 75, 25, _hwnd, (HMENU)ID_BTSAVE, NULL,NULL);

  LoadString(hLibrary, IDS_CANCEL, szResource, 50);
  hBtCancel = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"), szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                             150,245, 75, 25, _hwnd, (HMENU)IDCANCEL, NULL,NULL);
  LoadString(hLibrary, IDS_HELP, szResource, 50);
  hBtHelp   = CreateWindowEx(WS_EX_NOPARENTNOTIFY, TEXT("BUTTON"), szResource, BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                             225, 245, 75, 25, _hwnd, (HMENU)IDHELP, NULL,NULL);
  SendMessage(hListBox, WM_SETFONT, (WPARAM)hFont, TRUE);
  SendMessage(hBtStart,  WM_SETFONT, (WPARAM)hFont, TRUE);
  SendMessage(hBtSave,   WM_SETFONT, (WPARAM)hFont, TRUE);
  SendMessage(hBtCancel, WM_SETFONT, (WPARAM)hFont, TRUE);
  SendMessage(hBtHelp,   WM_SETFONT, (WPARAM)hFont, TRUE);
}

void PlayList::MoveControls(int iWidth, int iHeight)
{
  MoveWindow(hListBox,    0, 0,          iWidth,  iHeight-30, TRUE);
  MoveWindow(hBtStart,    0, iHeight-27, 75,      25,         TRUE);
  MoveWindow(hBtSave,    75, iHeight-27, 75,      25,         TRUE);
  MoveWindow(hBtCancel, 150, iHeight-27, 75,      25,         TRUE);
  MoveWindow(hBtHelp,   225, iHeight-27, 75,      25,         TRUE);
  ::UpdateWindow (_hwnd);
}

void PlayList::btSaveClick()
{
  OPENFILENAME ofn ;
  char pstrFileName[MAX_PATH] = "";
  char szFilter[]             = "DJWorkstation Playlist (*.dwp)\0*.dwp\0";
  char path[MAX_PATH]         = "";
  char lpzString[MAX_PATH]    = "";

  GetCurrentDirectory(MAX_PATH, path);
  strcat(path, "\\PlayList");
  ofn.lStructSize       = sizeof (OPENFILENAME) ;
  ofn.hwndOwner         = _hwnd;
  ofn.hInstance         = NULL ;
  ofn.lpstrFilter       = szFilter ;
  ofn.lpstrCustomFilter = NULL ;
  ofn.nMaxCustFilter    = 0 ;
  ofn.nFilterIndex      = 0 ;
  ofn.lpstrFile         = NULL ;          // Bei �ffnen bzw. Schlie�en gesetzt
  ofn.nMaxFile          = MAX_PATH ;
  ofn.lpstrFileTitle    = NULL ;          // Bei �ffnen bzw. Schlie�en gesetzt
  ofn.nMaxFileTitle     = MAX_PATH ;
  ofn.lpstrInitialDir   = path ;
  ofn.lpstrTitle        = NULL ;
  ofn.Flags             = 0 ;             // Bei �ffnen bzw. Schlie�en gesetzt
  ofn.nFileOffset       = 0 ;
  ofn.nFileExtension    = 0 ;
  ofn.lpstrDefExt       = TEXT ("dwp") ;
  ofn.lCustData         = 0L;
  ofn.lpfnHook          = NULL;
  ofn.lpTemplateName    = NULL;
  ofn.lpstrFile         = pstrFileName;
  ofn.lpstrFileTitle    = NULL;
  ofn.Flags             = OFN_HIDEREADONLY | OFN_CREATEPROMPT ;
  if (GetSaveFileName(&ofn))
  {
     FILE *FileHandle;
     FileHandle = fopen(pstrFileName, "w");
     for (int i=0; i < SendMessage(hListBox, LB_GETCOUNT,0, 0); i++)
     {
       strcpy (lpzString, GetSongPath(i));
       strcat(lpzString, "\n");
       fputs(lpzString, FileHandle);
     }
     fclose(FileHandle);
  }
}

void  PlayList::RePaintListBox(int idx)
{
	RECT r;
    SendMessage(hListBox, LB_GETITEMRECT, idx,(LPARAM)  &r);
    InvalidateRect(hListBox, &r, TRUE);
	SendMessage(_hwnd, WM_PAINT, 0, 0);
}

void  PlayList::AddStringToListBox(char *Artist, char *Songname, char *Path)
{
  char Value[260];
  strcpy(Value, Artist); strcat(Value, " - ");strcat(Value, Songname);
  SendMessage(hListBox, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR) Value);
  SendMessage(hListBox, LB_SETITEMDATA, SendMessage(hListBox, LB_GETCOUNT, 0, 0)-1, (LPARAM) (DWORD)Path);
  return;
}


LRESULT PlayList::ListBoxEvents(UINT message, WPARAM wParam, LPARAM lParam)
{
  int    iNewItemPoint;
  int   *ilpbuffer;
  char  *lpzString;
  POINT  point;

    switch (message)
    {
	case WM_LBUTTONDOWN:
           // Stelle fest, wo wir sind
           iItemPoint = HIWORD(lParam);
           moved = FALSE;
           switch (wParam)
           {
              case MK_LBUTTON:
                   if (SendMessage(hListBox, LB_GETSEL, SendMessage(hListBox, LB_ITEMFROMPOINT, 0,(LPARAM) MAKELPARAM(LOWORD(lParam), HIWORD(lParam))), 0)==0)
                   {
                     iCountSelItems = SendMessage(hListBox, LB_GETSELCOUNT,0, 0); //Anzahl der markierten Items
                     ilpbuffer = new int[iCountSelItems];
                     SendMessage(hListBox, LB_GETSELITEMS,(WPARAM) iCountSelItems, (LPARAM)ilpbuffer);
                     for (int i=iCountSelItems-1; i > -1; i--)
                     {
                        SendMessage(hListBox, LB_SETSEL, FALSE, ilpbuffer[i]);
                      }
                     delete[] ilpbuffer;
                   }
                   SendMessage(hListBox, LB_SETSEL, TRUE, SendMessage(hListBox, LB_ITEMFROMPOINT, 0,(LPARAM) MAKELPARAM(LOWORD(lParam), HIWORD(lParam))));
                   break;

              case MK_LBUTTON + MK_CONTROL:
                   SendMessage(hListBox, LB_SETSEL, TRUE, SendMessage(hListBox, LB_ITEMFROMPOINT, 0,(LPARAM) MAKELPARAM(LOWORD(lParam), HIWORD(lParam))));
                   break;

              case MK_LBUTTON + MK_SHIFT:
                   iCountSelItems = SendMessage(hListBox, LB_GETSELCOUNT,0, 0); //Anzahl der markierten Items
                   ilpbuffer = new int[iCountSelItems];
                   SendMessage(hListBox, LB_GETSELITEMS,(WPARAM) iCountSelItems, (LPARAM)ilpbuffer);
                   iNewItemPoint = SendMessage(hListBox, LB_ITEMFROMPOINT, 0,(LPARAM) MAKELPARAM(LOWORD(lParam), HIWORD(lParam)));

                   if (ilpbuffer[0] > iNewItemPoint)
                     {SendMessage(hListBox, LB_SELITEMRANGE, TRUE, MAKELPARAM(ilpbuffer[0], iNewItemPoint));}
                   else
                     {SendMessage(hListBox, LB_SELITEMRANGE, TRUE, MAKELPARAM(iNewItemPoint, ilpbuffer[0]));}

                   delete[] ilpbuffer;
                   break;

           }
           return 0;

      case WM_LBUTTONDBLCLK:
           RePaintListBox(iPlayPos);
           iPlayPos = SendMessage(hListBox, LB_ITEMFROMPOINT, 0,(LPARAM) MAKELPARAM(LOWORD(lParam), HIWORD(lParam)));
           return 0;

      case WM_RBUTTONUP:
           point.x = LOWORD (lParam);
           point.y = HIWORD (lParam);
           ClientToScreen(_hwnd, &point);
           TrackPopupMenu(hMenu, TPM_RIGHTBUTTON, point.x, point.y, 0, _hwnd, NULL);
           return 0;

      case WM_LBUTTONUP:
           if ((moved == FALSE) & (wParam == MK_LBUTTON-1))
           {
             if (SendMessage(hListBox, LB_GETSEL, SendMessage(hListBox, LB_ITEMFROMPOINT, 0,(LPARAM) MAKELPARAM(LOWORD(lParam), HIWORD(lParam))), 0) > 0)
             {
               iCountSelItems = SendMessage(hListBox, LB_GETSELCOUNT,0, 0); //Anzahl der markierten Items
               ilpbuffer = new int[iCountSelItems];
               SendMessage(hListBox, LB_GETSELITEMS,(WPARAM) iCountSelItems, (LPARAM)ilpbuffer);
               for (int i=iCountSelItems-1; i > -1; i--)
               {
                  SendMessage(hListBox, LB_SETSEL, FALSE, ilpbuffer[i]);
                }
               delete[] ilpbuffer;
             }
             SendMessage(hListBox, LB_SETSEL, TRUE, SendMessage(hListBox, LB_ITEMFROMPOINT, 0,(LPARAM) MAKELPARAM(LOWORD(lParam), HIWORD(lParam))));
            }
          return 0;

      case WM_MOUSEMOVE: //Wenn der linke MB gedr�ck und etwas selektiert und die Maus signifikant verschoben wurde
           iNewItemPoint = HIWORD(lParam);//SendMessage(hListBox, LB_ITEMFROMPOINT, 0,(LPARAM) MAKELPARAM(LOWORD(lParam), HIWORD(lParam)));
           if ((wParam == MK_LBUTTON) & (SendMessage(hListBox, LB_GETSELCOUNT,0, 0)>0) &
                (iItemPoint != iNewItemPoint))
           {
             moved = TRUE;
             lpzString = new char[255];
             iCountSelItems = SendMessage(hListBox, LB_GETSELCOUNT,0, 0); //Anzahl der markierten Items
             ilpbuffer = new int[iCountSelItems];
             SendMessage(hListBox, LB_GETSELITEMS,(WPARAM) iCountSelItems, (LPARAM)ilpbuffer);
             DWORD ItemDataTmp;

             //Wenn neue Position des obersten > 0 beim verkleinern wird soll nix passieren nach unten genauso
             if ((iNewItemPoint < iItemPoint-11) & (ilpbuffer[0] > 0))
             { // nach oben
               for (int i=0; i < iCountSelItems; i++)
               {
                  SendMessage(hListBox, LB_GETTEXT, ilpbuffer[i],(LPARAM) lpzString);
				  ItemDataTmp = SendMessage(hListBox, LB_GETITEMDATA, ilpbuffer[i],0);
                  SendMessage(hListBox, LB_DELETESTRING, ilpbuffer[i],0);
                  SendMessage(hListBox, LB_INSERTSTRING, ilpbuffer[i]-1,(LPARAM) lpzString);
                  SendMessage(hListBox, LB_SETITEMDATA, ilpbuffer[i]-1,(LPARAM) ItemDataTmp);
                  SendMessage(hListBox, LB_SETSEL, TRUE, ilpbuffer[i]-1);
                  iItemPoint = HIWORD(lParam);
               }
             }
             if ((iNewItemPoint > iItemPoint+11) & (ilpbuffer[iCountSelItems-1] < ((SendMessage(hListBox, LB_GETCOUNT,0, 0)-1))))
             { //nach unten
               for (int i=iCountSelItems-1; i > -1; i--)
               {
                  SendMessage(hListBox, LB_GETTEXT, ilpbuffer[i],(LPARAM) lpzString);
				  ItemDataTmp = SendMessage(hListBox, LB_GETITEMDATA, ilpbuffer[i],0);
                  SendMessage(hListBox, LB_DELETESTRING, ilpbuffer[i],0);
                  SendMessage(hListBox, LB_INSERTSTRING, ilpbuffer[i]+1,(LPARAM) lpzString);
                  SendMessage(hListBox, LB_SETITEMDATA, ilpbuffer[i]+1,(LPARAM) ItemDataTmp);
                  SendMessage(hListBox, LB_SETSEL, TRUE, ilpbuffer[i]+1);
                  iItemPoint = HIWORD(lParam);
               }
             delete[] lpzString;
             delete[] ilpbuffer;
             }
           }
           return 0;
   }
   return ::CallWindowProc((WNDPROC)pfnOldWndProc, hListBox, message, wParam, lParam);
}

 
LRESULT PlayList::Events(UINT message, WPARAM wParam, LPARAM lParam)
{
    RECT              rect;
    int              *ilpbuffer;
    POINT             point;
    LPDRAWITEMSTRUCT  lpDIS; 
    char              szText[255];
    char              szValue[260];

    switch (message)
    {
        case WM_COMMAND:
             switch (LOWORD (wParam))
             {
             case ID_BTSTART:
                  RePaintListBox(iPlayPos);
                  iPlayPos = 0;
    			  RePaintListBox(iPlayPos);
                  SendDlgItemMessage(hDlgMixer, ID_CBOX_AUTOPLAY, BM_SETCHECK, BST_CHECKED, 0);
                  SetTimer(hDlgMixer, 10, 500, NULL);
                  return 0 ;
             case ID_MN_DELETE:
                  if (SendMessage(hListBox, LB_GETSELCOUNT,0, 0)>0)
                  {
                     iCountSelItems = SendMessage(hListBox, LB_GETSELCOUNT,0, 0); //Anzahl der markierten Items
                     ilpbuffer = new int[iCountSelItems];
                     SendMessage(hListBox, LB_GETSELITEMS,(WPARAM) iCountSelItems, (LPARAM)ilpbuffer);
                     for (int i=iCountSelItems-1; i > -1; i--)
                     {
                       SendMessage(hListBox, LB_DELETESTRING, ilpbuffer[i],0);
                     }
                     delete[] ilpbuffer;
                  }
                  return 0 ;
             case ID_BTSAVE:
                  btSaveClick();
                  return 0 ;
             case IDCANCEL:
                  iPlayPos = 0;
                  SendDlgItemMessage(hDlgMixer, ID_CBOX_AUTOPLAY, BM_SETCHECK, BST_UNCHECKED, 0);
                  KillTimer(hDlgMixer, 10);
				  DestroyWindow(_hwnd);
                  return 0 ;
             case IDHELP:
                  WinHelp(_hwnd, HelpPath,HELP_CONTEXT, 50);
                  return 0 ;
             }
             break;

        case WM_RBUTTONUP:
             point.x = LOWORD (lParam);
             point.y = HIWORD (lParam);
             ClientToScreen(_hwnd, &point);
             TrackPopupMenu(hMenu, TPM_RIGHTBUTTON, point.x, point.y, 0, _hwnd, NULL);
             return 0;

        case WM_CREATE:
             hFirstMenu = LoadMenu(hLibrary, TEXT("PLAYLISTPOPUP"));
             hMenu      = GetSubMenu(hFirstMenu,0);
             SetControls();
             pfnOldWndProc = (FARPROC)::SetWindowLong(hListBox, GWL_WNDPROC, (LONG)ListBoxProc) ;
             return 0;

        case WM_HELP:
 		     WinHelp(_hwnd, HelpPath,HELP_CONTEXT, 50);
             return 0;

        case WM_SIZE:
             GetClientRect(_hwnd, &rect);
             MoveControls(rect.right, rect.bottom);
             return 0;

        case WM_DRAWITEM: 
             lpDIS = (DRAWITEMSTRUCT*)lParam;
 
             // If there are no list box items, skip
             if( lpDIS->CtlType == ODT_LISTBOX )
			 {
				SendMessage( lpDIS->hwndItem, LB_GETTEXT, lpDIS->itemID,(LPARAM) szText );
     			SetTextColor( lpDIS->hDC, GetSysColor (COLOR_BTNTEXT));
				SetBkColor(lpDIS->hDC, GetSysColor(COLOR_WINDOW));
				FillRect(lpDIS->hDC, &lpDIS->rcItem, (HBRUSH) (COLOR_WINDOW+1));//GetSysColor(COLOR_HIGHLIGHT));
	            itoa(lpDIS->itemID+1, szValue, 10);
				strcat(szValue, ". ");strcat(szValue, szText);
				if (lpDIS->itemState == ODS_SELECTED)
				{
					SetTextColor(lpDIS->hDC, GetSysColor(COLOR_HIGHLIGHTTEXT));
					SetBkColor(lpDIS->hDC, GetSysColor(COLOR_HIGHLIGHT));
					FillRect(lpDIS->hDC, &lpDIS->rcItem, (HBRUSH) (COLOR_HIGHLIGHT+1));//GetSysColor(COLOR_HIGHLIGHT));
				}
				else
				{
		     		SetTextColor( lpDIS->hDC, GetSysColor (COLOR_WINDOWTEXT));
					SetBkColor(lpDIS->hDC, GetSysColor(COLOR_WINDOW));
					FillRect(lpDIS->hDC, &lpDIS->rcItem, (HBRUSH) (COLOR_WINDOW+1));//GetSysColor(COLOR_HIGHLIGHT));

				}
				HGDIOBJ tmp; // Due to a resource leak bug in Win32
                if (lpDIS->itemID == ((UINT)iPlayPos)) tmp = SelectObject(lpDIS->hDC,(HGDIOBJ) hFontBold);
				else tmp = SelectObject(lpDIS->hDC,(HGDIOBJ) hFont);
				TextOut( lpDIS->hDC, lpDIS->rcItem.left, lpDIS->rcItem.top,szValue, strlen( szValue ) );
				SelectObject(lpDIS->hDC, tmp); // Restore to prevent leak
			 }

             return 0; 
		case WM_NCDESTROY:
//			 delete this;
             return 0;

        case WM_DESTROY:
             DestroyMenu(hFirstMenu); 
             DestroyMenu(hMenu);
             ::SetWindowLong(hListBox,GWL_WNDPROC,(LONG)pfnOldWndProc);
             _hwnd     = NULL;
          return 0;

    }
    return ::DefWindowProc (_hwnd, message, wParam, lParam );
}

//Static Callback Functions

LRESULT CALLBACK PlayList::ListBoxProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  PlayList * pObject;
  pObject=(PlayList*)GetWindowLong((HWND)GetWindowLong(hwnd,GWL_HWNDPARENT), NULL);

  if (pObject) // sicherheitshalber nachfragen....
    return pObject->ListBoxEvents(message,wParam,lParam);
  else
   return(::CallWindowProc((WNDPROC) pObject->pfnOldWndProc, hwnd, message, wParam, lParam));
}


LRESULT CALLBACK PlayList::PlayListProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  PlayList * pObject;

  if (message==WM_CREATE)
  {
    pObject = (PlayList*)(((CREATESTRUCT FAR*)lParam)->lpCreateParams);
    SetWindowLong(hwnd,0,(LONG)pObject);

    pObject->_hwnd = hwnd;

  } else { // Alle anderen Messages

   pObject=(PlayList*)GetWindowLong(hwnd,NULL);

  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->Events(message,wParam,lParam);
  else
    return DefWindowProc(hwnd,message,wParam,lParam);

}




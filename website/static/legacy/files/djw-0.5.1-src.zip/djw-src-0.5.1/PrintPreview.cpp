/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "PrintPreview.h"

PrintPreview::PrintPreview(int iMode, ndw_DataBase* DataBaseCopy)
{
   DataBase = DataBaseCopy;
  _class.style         = CS_HREDRAW | CS_VREDRAW;
  _class.lpfnWndProc   = (WNDPROC) PrintPreviewProc;
  _class.cbClsExtra    = 0;
  _class.cbWndExtra    = sizeof(PrintPreview*);
  _class.hInstance     = NULL;
  _class.hIcon         = NULL;
  _class.hCursor       = NULL;
  _class.hbrBackground = (HBRUSH) GetStockObject (LTGRAY_BRUSH);
  _class.lpszClassName = "PrintPreview";
  ::RegisterClass(&_class);

  _hwnd = ::CreateWindowEx(0 ,"PrintPreview","Druckvorschau",
	                       WS_OVERLAPPEDWINDOW | WS_VSCROLL,
                           CW_USEDEFAULT,
                           CW_USEDEFAULT,
                           CW_USEDEFAULT,
                           CW_USEDEFAULT,
                           NULL, NULL, NULL,(void FAR*)this);
 //hStatusBar = CreateStatusWindow(WS_CHILD | WS_VISIBLE ,"Test", _hwnd, ID_PRINT_STATUSBAR); 
 hStatusBar = ::CreateWindowEx(
        0,                       // no extended styles 
        STATUSCLASSNAME,         // name of status bar class 
        (LPCTSTR) NULL,          // no text when first created 
        WS_CHILD | WS_VISIBLE,                // creates a child window 
        -100, -100, 10, 10,              // ignores size and position 
        _hwnd,              // handle to parent window 
        (HMENU) ID_PRINT_STATUSBAR,       // child window identifier 
        NULL,                   // handle to application instance 
        NULL);                   // no window creation data 
  ::ShowWindow (_hwnd, SW_SHOWNORMAL);
  ::UpdateWindow (_hwnd);
  switch (iMode)
  {
         case 0:
              iMode = 0;
              break;

         case 1:
              iMode = 1;
              break;

         case 2:
              iMode = 2;
              break;

         case 3:
              iMode = 3;
              break;

  }
}

PrintPreview::~PrintPreview()
{
}

void PrintPreview::PaintWindow()
{
  HDC hdcPrint;
  char szDevString[120];
  char *szPrinter;       

  GetProfileString("windows", "device", ",,,", szDevString, 120);
  szPrinter = strtok(szDevString,(const char *) ",");
  hdcPrint = CreateDC(NULL, szPrinter, NULL, NULL);
  double DevWidth  = GetDeviceCaps(hdcPrint, PHYSICALWIDTH);
  double DevHeight = GetDeviceCaps(hdcPrint, PHYSICALHEIGHT);
  double DevOffX   = GetDeviceCaps(hdcPrint, PHYSICALOFFSETX);
  double DevOffY   = GetDeviceCaps(hdcPrint, PHYSICALOFFSETY);
  double propWH    = DevWidth/DevHeight;
  double propHW    = DevHeight/DevWidth;
  DeleteDC(hdcPrint);

  PAINTSTRUCT ps;
  HDC  hdc;
  RECT rect;
  hdc = BeginPaint (_hwnd, &ps);
  GetClientRect(_hwnd, &rect);
  int x1, y1, x2, y2;
  double Right   = rect.right-20;
  double Bottom  = rect.bottom-20-10; //-10 wegen Statusbar
  double propRB  = Right/Bottom;
  if (propRB > propWH)
  {
    x1 = (int)(rect.right-(Bottom*propWH))/2;
    y1 = 10;
    x2 = (int) x1 + (int)(Bottom*propWH);
    y2 = (int) Bottom+10;
  }
  else
  {
    x1 = 10;
    y1 = (int)(rect.bottom -(Right*propHW))/2;
    x2 = (int) Right+10;
    y2 = (int) y1+ (int) (Right*propHW);
  }

  SelectObject (hdc, GetStockObject (BLACK_BRUSH)) ;
  Rectangle(hdc, x1+4, y1+4, x2+4, y2+4);
  SelectObject (hdc, GetStockObject (WHITE_BRUSH)) ;
  Rectangle(hdc, x1, y1, x2, y2);

  EndPaint (_hwnd, &ps) ;
//  ::UpdateWindow (_hwnd);
  
}

int PrintPreview::CalculatePrintSides()
{
	DataBase->ndb_Header.iCount;

	// SendMessage(hS, SBM_SETRANGE,0, 3000);
   // SendMessage(hSBarHeadVolume, SBM_SETPOS,0, TRUE);
	return 1;
}


LRESULT PrintPreview::Events(UINT message, WPARAM wParam, LPARAM lParam)
{

  switch (message)
  {
      case WM_COMMAND:
           return 0;
      case WM_CREATE:
		   iPrintSides = CalculatePrintSides();
           return 0;
      case WM_SIZE:
           MoveWindow(hStatusBar, -100, -100, 10,  10, TRUE);
//		  ::UpdateWindow(_hwnd);
           return 0;
      case WM_PAINT:
           PaintWindow();
           return 0;

      case WM_DESTROY:
             PostQuitMessage(0);
          return 0;

  }
  return ::DefWindowProc (_hwnd, message, wParam, lParam );
}


LRESULT CALLBACK PrintPreview::PrintPreviewProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  PrintPreview * pObject;

  if (message==WM_CREATE)
  {
    pObject = (PrintPreview*)(((CREATESTRUCT FAR*)lParam)->lpCreateParams);
    SetWindowLong(hwnd,0,(LONG)pObject);

   pObject->_hwnd = hwnd;

  } else { // Alle anderen Messages

   pObject=(PrintPreview*)GetWindowLong(hwnd,NULL);

  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->Events(message,wParam,lParam);
  else
    return DefWindowProc(hwnd,message,wParam,lParam);
}
//---------------------------------------------------------------------------


/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#ifndef FormateH
#define FormateH
#include <windows.h>
#pragma warning( disable : 4201 )//Wegen merkw�rdiger mmsystem.h Warnungen in Stufe 4
#include <mmsystem.h>
#include <dsound.h>
#include "file_input.h"
#include "mpeg_codec.h"
/***************************Wegen Vorbis*******/
#include "vorbis/codec.h"
#include "vorbis/vorbisfile.h"

#define   SongEnde 10;

  // Mp3 Abspielobjekt
class BasicPlayer
{

  public:

				   BasicPlayer(){};
				   ~BasicPlayer(){};
                   BasicPlayer(const BasicPlayer& other) //Copy-Constructor
                   {
                     pwfx = other.pwfx;
                   };

				   BasicPlayer operator= (const BasicPlayer& other)
				   {
					  if (this != &other)
					  {
                        pwfx = other.pwfx;
					  } 
					return *this;
				   };

     virtual void          Load(LPSTR lpzFileName)= 0;
     virtual void          Unload() = 0;
     virtual int           GetData(char *output_buffer, int Data_needed) = 0;
     virtual WAVEFORMATEX  GetSoundFormat() = 0;
     virtual int           GetPosition() = 0;
     virtual int           GetDuration() = 0;
     virtual void          Seek(int iTimePos) = 0;

     WAVEFORMATEX     pwfx;
     int              BitsPerSample;
     int              frequency;
     int              AvgBytesPerSec;     //Bytes pro Sek
};



// Mp3 Abspielobjekt
class Mp3Player : public BasicPlayer
{

  public:

				   Mp3Player(){};
				   ~Mp3Player(){};
                   Mp3Player(const Mp3Player& other) //Copy-Constructor
                   {
                     pwfx = other.pwfx;
                   };

				   Mp3Player operator= (const Mp3Player& other)
				   {
					  if (this != &other)
					  {
                        pwfx = other.pwfx;
					  } 
					return *this;
				   };

     virtual void          Load(LPSTR lpzFileName);
     virtual void          Unload();
     virtual int           GetData(char *output_buffer, int Data_needed);
     virtual WAVEFORMATEX  GetSoundFormat();
     virtual int           GetPosition();
     virtual int           GetDuration(){return decoder->info->status->info.duration/10;}
     virtual void          Seek(int iTimePos);

  private:
     XA_Decoder      *decoder;
     XA_InputModule   InputModule;
     XA_CodecModule   CodecModule;
     int              channels;
     int              Frame_Time;          // Zeit eines komprimierten Frames
     int              pcm_buffer;       // Gr�sse eines dekomprimierten Frames
     int              pcm_Time;         // Zeit eines dekomprimierten Frames in ms
     char            *pBuffer_Uebertrag;
     char            *lpData;
     int              iBuffer_Uebertrag_Size;
     int              iBuffer_Uebertrag_Time;

};

// Wave-Abspielobjekt
class WavPlayer : public BasicPlayer
{

  public:

				   WavPlayer(){};
				   ~WavPlayer(){};
                   WavPlayer(const WavPlayer& other) //Copy-Constructor
                   {
                     pwfx = other.pwfx;
                   };

				   WavPlayer operator= (const WavPlayer& other)
				   {
					  if (this != &other)
					  {
                        pwfx = other.pwfx;
					  } 
					return *this;
				   };

     virtual void          Load(LPSTR lpzFileName);
     virtual void          Unload();
     virtual int           GetData(char *output_buffer, int Data_needed);
     virtual WAVEFORMATEX  GetSoundFormat();
     virtual int           GetPosition();
     virtual int           GetDuration(){return iDuration;}
     virtual void          Seek(int iTimePos);

  private:
    HMMIO       hmmio;              // file handle for open file 
    MMCKINFO    mmckinfoParent;     // parent chunk information 
    MMCKINFO    mmckinfoSubchunk;   // subchunk information structure 
    DWORD       dwFmtSize;          // size of "FMT" chunk 
    int         iDuration;

};


// Ogg-Vorbis Abspielobjekt
class VorbisPlayer : public BasicPlayer

{

  public:

				   VorbisPlayer(){};
				   ~VorbisPlayer(){};
                   VorbisPlayer(const VorbisPlayer& other) //Copy-Constructor
                   {
                     pwfx = other.pwfx;
                   };

				   VorbisPlayer operator= (const VorbisPlayer& other)
				   {
					  if (this != &other)
					  {
                        pwfx = other.pwfx;
					  } 
					return *this;
				   };

     virtual void          Load(LPSTR lpzFileName);
     virtual void          Unload();
     virtual int           GetData(char *output_buffer, int Data_needed);
     virtual WAVEFORMATEX  GetSoundFormat();
     virtual int           GetPosition();
     virtual int           GetDuration(){return iDuration;}
     virtual void          Seek(int iTimePos);

  private:
	  
     OggVorbis_File   vf;
	 FILE            *f;
	 int              channels;
     int              Frame_Time;          // Zeit eines komprimierten Frames
     int              pcm_buffer;       // Gr�sse eines dekomprimierten Frames
     int              pcm_Time;         // Zeit eines dekomprimierten Frames in ms
     char            *pBuffer_Uebertrag;
     int              iBuffer_Uebertrag_Size;
     int              iBuffer_Uebertrag_Time;
	 int              iDuration;

};
/*
// CDDA-Abspielobjekt
class CDDAPlayer : public CDDAPlayer
{

  public:

				   CDDAPlayer(){};
				   ~CDDAPlayer(){};
                   CDDAPlayer(const WavPlayer& other) //Copy-Constructor
                   {
                     pwfx = other.pwfx;
                   };

				   CDDAPlayer operator= (const WavPlayer& other)
				   {
					  if (this != &other)
					  {
                        pwfx = other.pwfx;
					  } 
					return *this;
				   };

     virtual void          Load(LPSTR lpzFileName);
     virtual void          Unload();
     virtual int           GetData(char *output_buffer, int Data_needed);
     virtual WAVEFORMATEX  GetSoundFormat();
     virtual int           GetPosition();
     virtual int           GetDuration(){return iDuration;}
     virtual void          Seek(int iTimePos);

  private:
    HMMIO       hmmio;              // file handle for open file 
    MMCKINFO    mmckinfoParent;     // parent chunk information 
    MMCKINFO    mmckinfoSubchunk;   // subchunk information structure 
    DWORD       dwFmtSize;          // size of "FMT" chunk 
    int         iDuration;

};
*/


//---------------------------------------------------------------------------
#endif

#include "playerwnd.h"

class DlgMixer
{
 public:
   DSBasicObject *Prim_Aux;
   DSBasicObject *Prim_Head;
   PlayerWnd *PlayerForm;
   PlayerWnd *PlayerLinks;
   PlayerWnd *PlayerRechts;

  DlgMixer(HWND hParent);
 ~DlgMixer();
  static BOOL CALLBACK MixerDlgProc (HWND hDlg,
                               UINT message,
                               WPARAM wParam,
                               LPARAM lParam);

  BOOL DialogEvents(HWND hDlg, UINT message, WPARAM wParam);

  void ShowDialog();
  void HideDialog();

  HWND hdlg;

 private:
};
extern DlgMixer *DLGMIXER;

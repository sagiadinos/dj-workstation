/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#ifndef MixerDlgH
#define MixerDlgH
//---------------------------------------------------------------------------
#include "playerwnd.h"
#include "playlistw.h"
class DlgMixer
{
 public:
                        DlgMixer(HINSTANCE hCopyLibrary);
                       ~DlgMixer();
                  BOOL  DialogEvents(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
  static BOOL CALLBACK  MixerDlgProc (HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam);
                  void  OnCreate(ndw_DataBase* DataBaseCopy);
                  void  LoadPlayer(){PlayerLinks->btLoadClick();PlayerRechts->btLoadClick();};
                  void  PlayerLeftLoad(){PlayerLinks->btLoadClick();};
                  void  PlayerRightLoad(){PlayerRechts->btLoadClick();};
                  void  SetPlayerLeft(PlayerWnd *Player){PlayerLinks   = Player;};
                  void  SetPlayerRight(PlayerWnd *Player){PlayerRechts = Player;};
                  void  PlayerLeftPlay(){PlayerLinks->Play();};
                  void  PlayerLeftCue(){PlayerLinks->Cue();};
                  void  PlayerRightPlay(){PlayerRechts->Play();};
                  void  PlayerRightCue(){PlayerRechts->Cue();};
                  void  InitRemote(LPSTR lpzCommPort);
                  void  CloseRemote();
                  void  ShowDialog();
                  void  HideDialog();
                  HWND  GetDlgHandle(){return hdlg;};


   PlayList  *WinPlayList;

 private:

               void  slCrossfaderScroll(int iScrollPos);
               void  AutoPlayTimer();
               void  AutoFadeTimer();
               void  SetDataBase();
               void  StartPlayer_Left();
               void  StartPlayer_Right();
    static  LRESULT  CALLBACK btLeftProc(HWND hDlg, UINT Message,WPARAM wParam,LPARAM lParam);
    static  LRESULT  CALLBACK btRightProc(HWND hDlg, UINT Message,WPARAM wParam,LPARAM lParam);
            LRESULT  btLeftEvents(UINT Message, WPARAM wParam, LPARAM lParam);
            LRESULT  btRightEvents(UINT Message, WPARAM wParam, LPARAM lParam);

static DWORD WINAPI  StaticThreadRoutine(PVOID pParam);
              DWORD  ThreadRoutine();

   HANDLE        hCom;
   HANDLE        hThread;
   OVERLAPPED    o;
   BOOL          Terminated;
   BOOL          CommActive;
   DWORD         dwThreadId;
   PlayerWnd     *PlayerLinks;
   PlayerWnd     *PlayerRechts;
   ndw_DataBase  *DataBase;
   char          IniPath[260];
   FARPROC       pfnOldbtLeftProc;
   FARPROC       pfnOldbtRightProc;
   HINSTANCE     hLibrary;
   HWND          hdlg;
   HWND          hBtLeft;
   HWND          hBtRight;
   HWND          hslCrossfader;
   BOOL          BlendToRight;
   BOOL          BlendToLeft;
   char          HelpPath[10];
};
//---------------------------------------------------------------------------
#endif

/****************************************************************************
This unit encapsulates the classes for the Serial Remote Unit


Autor     : Nikolaos Saghiadinos
Date      : Oktober 2002
*****************************************************************************/
/*
SerialRemoteUnit::SerialRemoteUnit()
{
}

SerialRemoteUnit::~SerialRemoteUnit()
{
}

int SerialRemoteUnit::Init()
{
	return 0;
}

  */
//---------------------------------------------------------------------------
#ifndef remoteH
#define remoteH

class SerialRemoteUnit
{
	:public
		SerialRemoteUnit(); //Constructor
		~SerialRemoteUnit(); //Destructor
		int Init();

	:private

};






//---------------------------------------------------------------------------

#endif


/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#ifndef DeviceDlgH
#define DeviceDlgH

#include <windows.h>
#pragma warning( disable : 4201 ) //Wegen merkw�rdiger mmsystem.h Warnungen in Stufe 4
#include <mmsystem.h>
#include <dsound.h> 
#include "resource.h"
#pragma warning ( disable : 4710 4702) //wegen stlport Warnungen in Stufe 4

#include <stdio.h>
#include <string.h>
#include <objbase.h>
#include <initguid.h>
#include <list>

using namespace std;
 

class DlgDevice
{
  public:

                          DlgDevice(HINSTANCE hCopyLibrary);
                         ~DlgDevice();
                    BOOL  DialogEvents(HWND hDlg, UINT message, WPARAM wParam);
    static BOOL CALLBACK  DeviceDlgProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

  private:

	static BOOL CALLBACK  EnumCallback(LPGUID lpGuid, LPCSTR lpcstrDescription, LPCSTR lpcstrModule, LPVOID hwnd);
                    void  InitDialog(HWND hDlg);
                    void  SetAuxHead(HWND hDlg);
                    void  ClearBoxes();
                    void  SetOnlyOne(HWND hDlg);
                    void  SetPerPlayer(HWND hDlg);
                    BOOL  SoundCallback (LPGUID lpGuid, LPCSTR lpcstrDescription);
                    void  GetValues(HWND hDlg);
                    BOOL  WriteIni();


  list<char *>::const_iterator b;
  list<char *> lDevice;

  int       iMode;
  int       iDeviceCount;
  char      IniPath[MAX_PATH];
//  HWND      hDlg;
  HFONT      hFont;
  HINSTANCE  hLibrary;
  HWND       hCBDevice[64];
  HWND       hSSDevice[64];
  HWND       hBtOK;
  HWND       hBtCancel;
  HWND       hBtHelp;
  char       HelpPath[10];
};

//---------------------------------------------------------------------------

#endif



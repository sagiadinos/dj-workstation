/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 21-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#ifndef databaseH
#define databaseH
#  pragma warning ( disable : 4710 4702) //wegen stlport Warnungen
#include <windows.h>
#include<stdio.h>
#include <string.h>
#include <list>
#include <vector>
#include <algorithm>
#include "vcedit.h"

using namespace std;

class ndw_DataSet
 {
 public:
    ndw_DataSet() //Constructor
    {
      // Doing some initializations
      int i;
	  for (i = 0; i < 31; i++) szArtist[i] = '\0';
	  for (i = 0; i < 31; i++) szSongname[i] = '\0';
	  for (i = 0; i <  5; i++) szYear[i] = '\0';
      for (i = 0; i < 11; i++) szGenre[i] = '\0';
      for (i = 0; i < MAX_PATH; i++) szPath[i] = '\0'; 
      Beats = 0;
      EQ = 0;
      StartTime = 0;
      EndTime = 0;
      Duration = 0;
    };

    ~ndw_DataSet(){}; //Destructor

   ndw_DataSet(const ndw_DataSet& other) //Copy-Constructor
   {
      strcpy(szArtist, other.szArtist);
      strcpy(szSongname, other.szSongname);
      Beats = other.Beats;
      strcpy(szGenre, other.szGenre);
      strcpy(szYear, other.szYear);
      strcpy(szPath, other.szPath);
      EQ = other.EQ;
      StartTime = other.StartTime;
      EndTime = other.EndTime;
      Duration = other.Duration;
   };

   ndw_DataSet operator= (const ndw_DataSet& other)
   {
      if (this != &other)
      {
        strcpy(szArtist, other.szArtist);
        strcpy(szSongname, other.szSongname);
        Beats = other.Beats;
        strcpy(szGenre, other.szGenre);
        strcpy(szYear, other.szYear);
        strcpy(szPath, other.szPath);
        EQ = other.EQ;
        StartTime = other.StartTime;
        EndTime = other.EndTime;
        Duration = other.Duration;
      }
	  return *this;
   };


   bool operator < (const ndw_DataSet& other) const
   {
     char s1[260] = "";
     char s2[260] = "";
     strcpy(s1, szPath);
     strcpy(s2, other.szPath);
	 size_t i ;
     for ( i=0; i < strlen(s1); i++){ s1[i] = (char) toupper(s1[i]);}
     for ( i=0; i < strlen(s2); i++){ s2[i] = (char) toupper(s2[i]);}
     return (strncmp(s1, s2, strlen(s2)) < 0);
   };

   char   szArtist[31];
   char   szSongname[31];
   int    Beats;
   char   szGenre[11];
   char   szYear[5];
   char   szPath[MAX_PATH];
   int    EQ;
   int    StartTime;
   int    EndTime;
   int    Duration;
protected:
};

class idx_Artist
{
 public:
    idx_Artist()
    {
      int i;
	  for (i = 0; i < 31; i++) szArtist[i] = '\0';
      iIndex = 0;
    };

    ~idx_Artist(){};

    idx_Artist(const idx_Artist &other)
    {
      iIndex = other.iIndex;
      strcpy(szArtist, other.szArtist);
    };

   bool operator < (const idx_Artist& other) const
   {
     char s1[31] = "";
     char s2[31] = "";
     strcpy(s1, szArtist);
     strcpy(s2, other.szArtist);
	 size_t i;
     for (i=0; i < strlen(s1); i++){ s1[i] = (char) toupper(s1[i]);}
     for (i=0; i < strlen(s2); i++){ s2[i] = (char) toupper(s2[i]);}
     return (strncmp(s1, s2, strlen(s2)) < 0);
   };

   idx_Artist operator= (const idx_Artist& other)
   {
      if (this != &other)
      {
        iIndex = other.iIndex;
        strcpy(szArtist, other.szArtist);
      }
	  return *this;
   };

 int   iIndex;
 char  szArtist[31];
};


class idx_Songname
{
 public:
    idx_Songname()
    {
      int i;
	  for (i = 0; i < 31; i++) szSongname[i] = '\0';
      iIndex = 0;
    };

    ~idx_Songname(){};

    idx_Songname(const idx_Songname &other)
    {
      iIndex = other.iIndex;
      strcpy(szSongname, other.szSongname);
    };

   bool operator < (const idx_Songname& other) const
   {
     char s1[31] = "";
     char s2[31] = "";
     strcpy(s1, szSongname);
     strcpy(s2, other.szSongname);
	 size_t i;
     for (i=0; i < strlen(s1); i++){ s1[i] = (char) toupper(s1[i]);}
     for (i=0; i < strlen(s2); i++){ s2[i] = (char) toupper(s2[i]);}
     return (strncmp(s1, s2, strlen(s2)) < 0);
   };

   idx_Songname operator= (const idx_Songname& other)
   {
      if (this != &other)
      {
        iIndex = other.iIndex;
        strcpy(szSongname, other.szSongname);
      }
	  return *this;
   };

 int   iIndex;
 char  szSongname[31];
};

class idx_Genre
{
 public:
    idx_Genre()
    {
      int i;
      for (i = 0; i < 11; i++) szGenre[i] = '\0';
      iIndex = 0;
    };

    ~idx_Genre(){};

    idx_Genre(const idx_Genre &other)
    {
      iIndex = other.iIndex;
      strcpy(szGenre, other.szGenre);
    };

   bool operator < (const idx_Genre& other) const
   {
     char s1[11] = "";
     char s2[11] = "";
     strcpy(s1, szGenre);
     strcpy(s2, other.szGenre);
	 size_t i;
     for (i=0; i < strlen(s1); i++){ s1[i] = (char) toupper(s1[i]);}
     for (i=0; i < strlen(s2); i++){ s2[i] = (char) toupper(s2[i]);}
     return (strncmp(s1, s2, strlen(s2)) < 0);
   };

   idx_Genre operator= (const idx_Genre& other)
   {
      if (this != &other)
      {
        iIndex = other.iIndex;
        strcpy(szGenre, other.szGenre);
      }
	  return *this;
   };

 int   iIndex;
 char  szGenre[11];
};

class idx_Year
{
 public:
    idx_Year()
    {
      int i;
	  for (i = 0; i <  5; i++) szYear[i] = '\0';
      iIndex = 0;
    };

    ~idx_Year(){};

    idx_Year(const idx_Year &other)
    {
      iIndex = other.iIndex;
      strcpy(szYear, other.szYear);
    };

   bool operator < (const idx_Year& other) const
   {
     char s1[5] = "";
     char s2[5] = "";
     strcpy(s1, szYear);
     strcpy(s2, other.szYear);
	 size_t i;
     for (i=0; i < strlen(s1); i++){ s1[i] = (char) toupper(s1[i]);}
     for (i=0; i < strlen(s2); i++){ s2[i] = (char) toupper(s2[i]);}
     return (strncmp(s1, s2, strlen(s2)) < 0);
   };

   idx_Year operator= (const idx_Year& other)
   {
      if (this != &other)
      {
        iIndex = other.iIndex;
        strcpy(szYear, other.szYear);
      }
	  return *this;
   };

 int   iIndex;
 char  szYear[5];
};


class ndw_DataBase
{
 public:
                 ndw_DataBase();
                ~ndw_DataBase();
    ndw_DataSet  GetActualDataSet();
	       int   GetActualDataPos(){return iActualDataSet;};
           int   GetFromActiveIndex(int iLVCount);
           int   StartFullSearch(char *szArtist, char *szSong, char *szGenre, char *szYear);
           void  ReIndex();
           void  WriteID3Tag(ndw_DataSet DataSet);
           void  WriteOGG_Comment(ndw_DataSet DataSet);
           void  WriteStartTime(int StartTime);
           void  SetActualDataSet(int i);
           void  AppendRecord(ndw_DataSet DataSet);
           int   ReadFiles();
           void  ReadOnlyDB();
           void  WriteFiles();
           void  WriteActualDataSet(ndw_DataSet DataSet);
           void  CreateIndices();
           void  Sort();
           void  SetActiveIndex(char * IndexName);
           int   FindArtist(char *szText);
           int   FindSongname(char *szText);
           int   FindGenre(char *szText);
           int   FindYear(char *szText);
           void  FindPath(char *szText);
           int   FindExactPath(char *szText);

     struct Header
     {
       int iVersion;
       int iCount;
     };
     Header ndb_Header;

     list<ndw_DataSet>    lDataBase;
     vector<ndw_DataSet>::const_iterator itPath;
     vector<ndw_DataSet>  vDataBase;
     vector<ndw_DataSet>  ResultDataBase;

 private:

           void  WriteHeader();
           void  WriteDataToFile(ndw_DataSet DataSet);
           void  WriteFile(int iPos);
           BOOL  strccmp(char *str1, char *str2);
           char* strcstr(char *str1, char *str2);
           BOOL  Compare(char *str, char *mask);


     //Indexes
     vector<idx_Artist>::const_iterator itArtist;
     vector<idx_Artist>   idxArtist;
     vector<idx_Songname>::const_iterator itSongname;
     vector<idx_Songname> idxSongname;
     vector<idx_Genre>::const_iterator itGenre;
     vector<idx_Genre>    idxGenre;
     vector<idx_Year>::const_iterator itYear;
     vector<idx_Year>     idxYear;

     FILE              *fDatabase;
     FILE              *fArtist;
     FILE              *fSongname;
     FILE              *fGenre;
     FILE              *fYear;
     char DBFile[MAX_PATH];
     char IDXSongname[MAX_PATH];
     char IDXGenre[MAX_PATH];
     char IDXYear[MAX_PATH];
     char IDXArtist[MAX_PATH];

     int  iActualDataSet;
     char szActualIndex[10];
};
//---------------------------------------------------------------------------
#endif


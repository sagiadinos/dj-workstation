/*****************************************************************************
 *
 * Author        : Copyright (c) Nikolaos Saghiadinos 2002
 * Author e-mail : niko@dj-workstation.de
 * File created  : 14-Nov-2002
 * Last modified : 14-Nov-2002
 *
 * License :
 *
 *  This file is part of the DJ-Workstation.
 *
 *  DJ-Workstation is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  DJ-Workstation is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DJ-Workstation; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************/
#include "ideditwnd.h"

IdEdit::IdEdit(ndw_DataBase* DataBaseCopy, HINSTANCE hCopyLibrary)
{
  DataBase = DataBaseCopy;
  hLibrary  = hCopyLibrary;
  strcpy(WriteField,"");
  ChangeListView = FALSE;
  hFont_Normal     = CreateFont(-11, 0, 0, 0, FW_NORMAL, FALSE, FALSE,	FALSE, ANSI_CHARSET,
                           OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                           DEFAULT_PITCH | FF_DONTCARE, "MS Sans Serif" );
}

IdEdit::~IdEdit()
{
}


void IdEdit::Show(HWND hParent, HINSTANCE hInstance)
{
   memset(&_class,0,sizeof(WNDCLASS));
  _class.style         = CS_HREDRAW | CS_VREDRAW;
  _class.lpfnWndProc   = (WNDPROC) IdEditProc;
  _class.cbClsExtra    = 0;
  _class.cbWndExtra    = sizeof(IdEdit*);
  _class.hInstance     = hInstance;
  _class.hIcon         = NULL;
  _class.hCursor       = NULL;
  _class.hbrBackground = (HBRUSH) GetStockObject (LTGRAY_BRUSH);
  _class.lpszClassName = "IdEdit";
  ::RegisterClass(&_class);
  _hwnd = ::CreateWindowEx(0,"IdEdit","Id3Editor", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT,
                CW_USEDEFAULT, 500, 300, hParent, NULL, hInstance,(void FAR*)this);
 // DWORD dwTest = GetLastError();
  if (_hwnd != NULL )
  {
    EnableWindow(hParent, FALSE);
  }

  ::ShowWindow (_hwnd, SW_SHOWNORMAL );
  ::UpdateWindow (_hwnd);
}


void IdEdit::SetControls()
{
   InitCommonControls();

   hListView    = CreateWindowEx(WS_EX_CLIENTEDGE | WS_EX_NOPARENTNOTIFY , WC_LISTVIEW,"", LVS_REPORT | LVS_NOSORTHEADER | LVS_SINGLESEL | WS_VISIBLE | LVS_OWNERDATA | LVS_SHOWSELALWAYS |WS_CHILD,
                               0, 22, 528, 327, _hwnd, NULL,NULL,NULL);
   SendMessage(hListView, LVM_SETEXTENDEDLISTVIEWSTYLE, LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);
   char pzsBuffer[260];

   SendMessage(hListView, WM_SETFONT, (WPARAM)hFont_Normal, TRUE);

   LV_COLUMN lvc;

   LoadString(hLibrary,IDS_ARTIST, pzsBuffer, sizeof(pzsBuffer));
   lvc.mask     = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
   lvc.fmt      = LVCFMT_LEFT;
   lvc.cx       = 180;
   lvc.pszText  = pzsBuffer;
   lvc.iSubItem = 0;
   SendMessage(hListView, LVM_INSERTCOLUMN, 0, (LPARAM)&lvc);

   LoadString(hLibrary,IDS_SONGNAME, pzsBuffer, sizeof(pzsBuffer));
   lvc.cx       = 181;
   lvc.pszText  = pzsBuffer;
   lvc.iSubItem = 1;
   SendMessage(hListView, LVM_INSERTCOLUMN, 1, (LPARAM)&lvc);

   LoadString(hLibrary,IDS_GENRE, pzsBuffer, sizeof(pzsBuffer));
   lvc.cx       = 72;
   lvc.pszText  = pzsBuffer;
   lvc.iSubItem = 2;
   SendMessage(hListView, LVM_INSERTCOLUMN, 2, (LPARAM)&lvc);

   LoadString(hLibrary,IDS_YEAR, pzsBuffer, sizeof(pzsBuffer));
   lvc.cx       = 36;
   lvc.pszText  = pzsBuffer;;
   lvc.iSubItem = 3;
   SendMessage(hListView, LVM_INSERTCOLUMN, 3, (LPARAM)&lvc);
}

LRESULT IdEdit::ListViewNotify(LPARAM lParam)
{
  LPNMHDR  lpnmh = (LPNMHDR) lParam;
  LV_DISPINFO *lpdi = (LV_DISPINFO *)lParam;

  if (lpnmh->code ==LVN_GETDISPINFO)
  {
    if(lpdi->item.mask & LVIF_TEXT)
    {
      int i = DataBase->GetFromActiveIndex(lpdi->item.iItem);
      switch (lpdi->item.iSubItem)
      {
             case 0:
                    strcpy(lpdi->item.pszText, DataBase->vDataBase[i].szArtist);
                    break;
             case 1:
                    strcpy(lpdi->item.pszText, DataBase->vDataBase[i].szSongname);
                    break;
             case 2:
                    strcpy(lpdi->item.pszText, DataBase->vDataBase[i].szGenre);
                    break;
             case 3:
                    strcpy(lpdi->item.pszText, DataBase->vDataBase[i].szYear);
                    break;
      }
    }
  }
  return 0;
}

void IdEdit::SetEditControl(int x, int y)
{
   int     ColArtistWidth;
   int     ColSongWidth;
   int     ColGenreWidth;
   int     ColYearWidth;
   int     xPos, yPos, Width, Height;
   char    Text[31];
   DataSet = DataBase->GetActualDataSet();
  //Finde heraus in Welcher Spalte was abgeht
   if (hEdit != NULL)
   {
      ::SetWindowLong(hEdit,GWL_WNDPROC,(LONG)pfnOldEditProc);
      DestroyWindow(hEdit);
   }

   ColArtistWidth = ListView_GetColumnWidth(hListView,0);
   ColSongWidth   = ListView_GetColumnWidth(hListView,1);
   ColGenreWidth  = ListView_GetColumnWidth(hListView,2);
   ColYearWidth   = ListView_GetColumnWidth(hListView,3);
   if (x > ColArtistWidth)
   {
      if (x > ColArtistWidth+ColSongWidth)
       {
          if (x > ColArtistWidth+ColSongWidth+ColGenreWidth)
          {
            xPos  = ColArtistWidth+ColSongWidth+ColGenreWidth;
            Width = ColYearWidth;
            strcpy(Text, DataSet.szYear);
            iMaxEdit = 5;
            strcpy(WriteField,"Year");
          }
          else
          {
            xPos  = ColArtistWidth+ColSongWidth;
            Width = ColGenreWidth;
            strcpy(Text, DataSet.szGenre);
            strcpy(WriteField,"Genre");
            iMaxEdit = 11;
          }
       }
       else
       {
         xPos  = ColArtistWidth;
         Width = ColSongWidth;
         strcpy(Text, DataSet.szSongname);
         strcpy(WriteField,"Songname");
         iMaxEdit = 31;
       }
   }
   else
   {
     xPos  = 0;
     Width = ColArtistWidth;
     strcpy(Text, DataSet.szArtist);
     strcpy(WriteField,"Artist");
     iMaxEdit = 31;
   }
   RECT rect;
   ListView_GetItemRect(hListView, y, &rect, LVIR_LABEL);
   yPos = rect.top;
   Height = rect.bottom-rect.top+5;
   hEdit  = CreateWindowEx(WS_EX_CLIENTEDGE | WS_EX_NOPARENTNOTIFY, TEXT("EDIT"),Text, ES_AUTOHSCROLL | ES_LEFT | WS_CHILD |WS_VISIBLE,
                         xPos, yPos, Width, Height, _hwnd, (HMENU)ID_EDIT_LV,NULL,NULL);
   ChangeEdit = FALSE;
   pfnOldEditProc = (FARPROC)::SetWindowLong(hEdit, GWL_WNDPROC, (LONG)EditProc) ;


   SendMessage(hEdit, WM_SETFONT, (WPARAM)hFont_Normal, TRUE);
   SendMessage(hEdit, EM_SETSEL, 0, SendMessage(hEdit, WM_GETTEXTLENGTH, 0, 0));
   SendMessage(hEdit, EM_LIMITTEXT, iMaxEdit,0);
   SetFocus(hEdit);

return;
}

void IdEdit::EditChange()
{
   char    EditText[255];
   SendMessage(hEdit, WM_GETTEXT, 255, (LPARAM) EditText);
   if (strcmp(WriteField, "Artist") ==0)strcpy(DataSet.szArtist, EditText);
   if (strcmp(WriteField, "Songname") ==0)strcpy(DataSet.szSongname, EditText);
   if (strcmp(WriteField, "Genre") ==0)strcpy(DataSet.szGenre, EditText);
   if (strcmp(WriteField, "Year") ==0)strcpy(DataSet.szYear, EditText);
   DataBase->WriteActualDataSet(DataSet);
   char *ext = strrchr(DataSet.szPath,'.');
    if (ext != NULL)
    {
      ext[1] = (char) toupper(ext[1]);
      ext[2] = (char) toupper(ext[2]);
      ext[3] = (char) toupper(ext[3]);
      if (strcmp(ext, ".MP3")==0)
      {
        DataBase->WriteID3Tag(DataSet);
	  }
      if (strcmp(ext, ".OGG")==0)
      {
        DataBase->WriteOGG_Comment(DataSet);
	  }
	}
   ChangeEdit = FALSE;
   ChangeListView = TRUE;
return;
}



LRESULT IdEdit::EditEvents(UINT message, WPARAM wParam, LPARAM lParam)
{
  int  iHeight;
  switch (message)
  {
    case WM_KEYDOWN:
         switch(wParam)
         {
           case VK_UP:
                if (iListViewPos > 0)
                {
                  if (ChangeEdit == TRUE){EditChange();}
                  iListViewPos--;
                  DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(iListViewPos));
                  ListView_EnsureVisible(hListView, iListViewPos, TRUE);
                  ListView_RedrawItems(hListView,iListViewPos+1,iListViewPos+2);
                  SetEditControl(iListViewCol, iListViewPos);
                 }
                return 0;
           case VK_DOWN:
                if (iListViewPos < ListView_GetItemCount(hListView)-1)
                {
                  if (ChangeEdit == TRUE){EditChange();}
                  iListViewPos++;
                  DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(iListViewPos));
                  ListView_EnsureVisible(hListView, iListViewPos, TRUE);
                  ListView_RedrawItems(hListView,iListViewPos-2,iListViewPos-1);
                  SetEditControl(iListViewCol, iListViewPos);
                }
                return 0;
           case VK_NEXT:
                iHeight = ListView_GetCountPerPage(hListView);
                ListView_RedrawItems(hListView,iListViewPos-1,iListViewPos+1);
                if (iListViewPos+iHeight < ListView_GetItemCount(hListView))
                {
                  if (ChangeEdit == TRUE){EditChange();}
                  iListViewPos = iListViewPos+iHeight;
                }
                else
                {
                  if (ChangeEdit == TRUE){EditChange();}
                  iListViewPos = ListView_GetItemCount(hListView)-1;
                }
                ListView_EnsureVisible(hListView, iListViewPos, TRUE);
                SetEditControl(iListViewCol, iListViewPos);
                return 0;
           case VK_PRIOR:
                iHeight = ListView_GetCountPerPage(hListView);
                ListView_RedrawItems(hListView,iListViewPos-1,iListViewPos+1);
                if (iListViewPos-iHeight > 0)
                {
                  if (ChangeEdit == TRUE){EditChange();}
                  iListViewPos = iListViewPos-iHeight;
                }
                else
                {
                  if (ChangeEdit == TRUE){EditChange();}
                  iListViewPos = 0;
                }
                ListView_EnsureVisible(hListView, iListViewPos, TRUE);
                SetEditControl(iListViewCol, iListViewPos);
                return 0;
          case VK_TAB:
                //1. Wo bin ich ?
                if (boShift == FALSE)
                {
                  if (strcmp(WriteField, "Artist") == 0)
                  {
                    if (ChangeEdit == TRUE){EditChange();}
                    iListViewCol = ListView_GetColumnWidth(hListView,0)+2;
                  }
                  if (strcmp(WriteField, "Songname") == 0)
                  {
                    if (ChangeEdit == TRUE){EditChange();}
                    iListViewCol = ListView_GetColumnWidth(hListView,0)+ListView_GetColumnWidth(hListView,1)+2;
                  }
                  if (strcmp(WriteField, "Genre") == 0)
                  {
                    if (ChangeEdit == TRUE){EditChange();}
                    iListViewCol = ListView_GetColumnWidth(hListView,0)+ListView_GetColumnWidth(hListView,1)+ListView_GetColumnWidth(hListView,2)+2;
                  }
                  if (strcmp(WriteField, "Year") == 0)
                  {
                    if (iListViewPos < ListView_GetItemCount(hListView)-1)
                    {
                      if (ChangeEdit == TRUE){EditChange();}
                      iListViewCol = 3;
                      iListViewPos++;
                      DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(iListViewPos));
                      ListView_EnsureVisible(hListView, iListViewPos, TRUE);
                      ListView_RedrawItems(hListView,iListViewPos-2,iListViewPos-1);
                    }
                  }
                  SetEditControl(iListViewCol, iListViewPos);
               }
               else
               {
                  if (strcmp(WriteField, "Artist") == 0)
                  {
                    if (iListViewPos > 0)
                    {
                      if (ChangeEdit == TRUE){EditChange();}
                      iListViewCol = ListView_GetColumnWidth(hListView,0)+ListView_GetColumnWidth(hListView,1)+ListView_GetColumnWidth(hListView,2)+2;
                      iListViewPos--;
                      DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(iListViewPos));
                      ListView_EnsureVisible(hListView, iListViewPos, TRUE);
                      ListView_RedrawItems(hListView,iListViewPos-2,iListViewPos-1);
                    }
                  }
                  if (strcmp(WriteField, "Songname") == 0)
                  {
                    if (ChangeEdit == TRUE){EditChange();}
                    iListViewCol = 3;
                  }
                  if (strcmp(WriteField, "Genre") == 0)
                  {
                    if (ChangeEdit == TRUE){EditChange();}
                    iListViewCol = ListView_GetColumnWidth(hListView,0)+2;
                  }
                  if (strcmp(WriteField, "Year") == 0)
                  {
                    if (ChangeEdit == TRUE){EditChange();}
                    iListViewCol = ListView_GetColumnWidth(hListView,0)+ListView_GetColumnWidth(hListView,1)+2;
                  }
                  SetEditControl(iListViewCol, iListViewPos);
               }
               return 0;
          case VK_SHIFT:
               boShift = TRUE;
               return 0;
         }
    case WM_KEYUP:
          switch(wParam)
          {
             case VK_SHIFT:
                  boShift = FALSE;
                  return 0;
         }

    }

 return ::CallWindowProc((WNDPROC)pfnOldEditProc, hEdit, message, wParam, lParam);
}

LRESULT IdEdit::ListViewEvents(UINT message, WPARAM wParam, LPARAM lParam)
{
  LV_HITTESTINFO lv_hit;
  switch (message)
  {
    case WM_LBUTTONDOWN:
         if (ChangeEdit == TRUE){EditChange();}
         lv_hit.pt.x = 2;//LOWORD(lParam);
         lv_hit.pt.y = HIWORD(lParam);
         lv_hit.flags = LVHT_BELOW;
         ListView_HitTest(hListView,&lv_hit);
         DataBase->SetActualDataSet(DataBase->GetFromActiveIndex(lv_hit.iItem));
         iListViewPos = lv_hit.iItem;
         iListViewCol = (LOWORD(lParam));
         SetEditControl(LOWORD(lParam), lv_hit.iItem);
         return 0;
//    case WM_VSCROLL:
//         return 0;


  }
 return ::CallWindowProc((WNDPROC)pfnOldListViewProc, hListView, message, wParam, lParam);
}


LRESULT IdEdit::Events(UINT message, WPARAM wParam, LPARAM lParam)
{
    RECT    rect;
    LPNMHDR pnmh;

    switch (message)
    {
        case WM_COMMAND:
             switch (HIWORD(wParam))
             {
              case EN_CHANGE:
                   ChangeEdit = TRUE;
                   return 0;
             }
             return 0;

        case WM_CREATE:
             DragAcceptFiles(_hwnd, FALSE);
             SetControls();
             pfnOldListViewProc = (FARPROC)::SetWindowLong(hListView, GWL_WNDPROC, (LONG)ListViewProc) ;
             ListView_SetItemCount(hListView, DataBase->ndb_Header.iCount);
             return 0;
       case  WM_HELP:
             WinHelp(_hwnd, HelpPath,HELP_CONTEXT, 80);
             return TRUE ;

        case WM_SIZE:
             GetClientRect(_hwnd, &rect);
             MoveWindow(hListView, 0, 0, rect.right,  rect.bottom, TRUE);
             ::UpdateWindow (_hwnd);
             return 0;

        case WM_NOTIFY:
             pnmh = (LPNMHDR) lParam;
             if (pnmh->hwndFrom == hListView)
             {
               ListViewNotify(lParam);
             }
             return 0;

        case WM_DESTROY:
             if (ChangeListView == TRUE)
             {
               DataBase->ReIndex();
             }
             if (ChangeEdit == TRUE){EditChange();}
             ::SetWindowLong(hListView,GWL_WNDPROC,(LONG)pfnOldListViewProc);
              UnregisterClass("IdEdit", (HINSTANCE)GetWindowLong(_hwnd,GWL_HINSTANCE));
              EnableWindow((HWND)GetWindowLong(_hwnd,GWL_HWNDPARENT), TRUE);
              DestroyWindow(hListView);
              DeleteObject(hFont_Normal);

             _hwnd = NULL;
            return 0;
	  case WM_NCDESTROY:
           delete this;
           return 0;

    }
    return ::DefWindowProc (_hwnd, message, wParam, lParam );
}

//Static Callback Functions
LRESULT CALLBACK IdEdit::EditProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  IdEdit * pObject;
  pObject=(IdEdit*)GetWindowLong((HWND)GetWindowLong(hwnd,GWL_HWNDPARENT), NULL);

  if (pObject) // sicherheitshalber nachfragen....
    return pObject->EditEvents(message,wParam,lParam);
  else
   return(::CallWindowProc((WNDPROC)pObject->pfnOldEditProc, hwnd, message, wParam, lParam));
}



LRESULT CALLBACK IdEdit::ListViewProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  IdEdit * pObject;
  pObject=(IdEdit*)GetWindowLong((HWND)GetWindowLong(hwnd,GWL_HWNDPARENT), NULL);

  if (pObject) // sicherheitshalber nachfragen....
    return pObject->ListViewEvents(message,wParam,lParam);
  else
   return(::CallWindowProc((WNDPROC)pObject->pfnOldListViewProc, hwnd, message, wParam, lParam));
}


LRESULT CALLBACK IdEdit::IdEditProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  IdEdit * pObject;

  if (message==WM_CREATE)
  {
    pObject = (IdEdit*)(((CREATESTRUCT FAR*)lParam)->lpCreateParams);
    SetWindowLong(hwnd,0,(LONG)pObject);

    pObject->_hwnd = hwnd;

  } else { // Alle anderen Messages

   pObject=(IdEdit*)GetWindowLong(hwnd,NULL);

  }
  if (pObject) // sicherheitshalber nachfragen....
    return pObject->Events(message,wParam,lParam);
  else
    return DefWindowProc(hwnd,message,wParam,lParam);

}



